import React, { useState } from "react";
import { Box, Grid } from "@mui/material";
import { defaultSnackBarState } from "../../../utils/common";
import SnackbarAlert from "../../../components/SnackBarMessage/SnackbarAlert";
import ModalComponent from "../../../components/ModalComponent/ModalComponent";
import ErrorGatewayTable from "./ErrorGatewayTable/ErrorGatewayTable";
import AddEditErrorGateway from "./AddEditErrorGateway/AddEditErrorGateway";

const ManageErrorGatewayDetails = () => {
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [selectedRowData, setSelectedRowData] = useState({});
  const [refreshTable, setRefreshTable] = useState(false);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      setSelectedRowData([]);
    }
  };

  const openModal = (type) => {
    setEnableAddForm(type);
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      <ModalComponent style={style} closeModal={closeModal} enableAddForm={enableAddForm}>
        {enableAddForm && enableAddForm === "errormodal" && (
          <AddEditErrorGateway
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
      </ModalComponent>

      <Box px={2} pb={2}>
        <Grid>
          <Box sx={{ mt: "10px" }}>
            <ErrorGatewayTable
              rowData={selectedRowData}
              setSelectedRowData={setSelectedRowData}
              refreshTable={refreshTable}
              setRefreshTable={setRefreshTable}
              showSnackBar={showSnackBar}
              openModal={openModal}
            />
          </Box>
        </Grid>
      </Box>
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default ManageErrorGatewayDetails;

