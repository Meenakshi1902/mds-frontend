import React from 'react'

function ManageRcsGatewayDetails() {
  return (
    <div>
      ManageRcsGatewayDetails
    </div>
  )
}

export default ManageRcsGatewayDetails
