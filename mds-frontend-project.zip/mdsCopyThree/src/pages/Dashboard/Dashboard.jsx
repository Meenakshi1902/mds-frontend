import { useEffect } from "react";
import { useSelector } from "react-redux";
import { postRequest } from "../../helpers/http.helper.js";

const Dashboard = () => {
  // const userInfo = useSelector((state) => state.auth);
  // console.log("userInfo", userInfo);

  // useEffect(() => {
  //   postRequest(
  //     "login",
  //     { username: "admin", password: "admin@123" },
  //     function (res) {
  //       console.log(res);
  //     }
  //   );
  // }, []);
  return <>Dashboard</>;
};

export default Dashboard;
