import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import { object, Schema, string } from "yup";
import {
  getRequest,
  postRequest,
  putRequest,
} from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import { validationRegex } from "../../../../utils/common";
import Switch from "@mui/material/Switch";
import { useSelector } from "react-redux";

const AlertModule = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);

  // console.log("user => ", user);
  const [userSettingData, setUserSettingData] = useState([]);

  const hasFetchedUserSetting = useRef(false);

  const FetchUserSettingData = () => {
    getRequest("user-setting", function (response) {
      // console.log("response => ", response?.data?.data);
      if (!response?.data?.errors && response?.data?.data) {
        setUserSettingData(response?.data?.data);
      } else {
        // Handling error messages
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
        setUserSettingData([]);
      }
    });
  };

  useEffect(() => {
    if (hasFetchedUserSetting.current) return;
    FetchUserSettingData();
    hasFetchedUserSetting.current = true;
  }, []);

  const isEdit = userSettingData && Object.keys(userSettingData).length > 0;

  const initialValues = isEdit
    ? {
        ...userSettingData,
        low_balance: userSettingData.low_balance === 1 ? true : false,
        low_bal_limit: userSettingData.low_bal_limit
          ? Number(userSettingData.low_bal_limit)
          : "",
        login_alert: userSettingData.login_alert === 1 ? true : false,
        login_otp: userSettingData.login_otp === 1 ? true : false,
        is_mobile: userSettingData.is_mobile === 1 ? true : false,
        is_email: userSettingData.is_email === 1 ? true : false,
        is_whatsapp: userSettingData.is_whatsapp === 1 ? true : false,
        daily_usage: userSettingData.daily_usage === 1 ? true : false,
      }
    : {
        low_balance: false,
        low_bal_limit: "",
        login_alert: false,
        login_otp: false,
        is_mobile: false,
        is_email: false,
        is_whatsapp: false,
        daily_usage: false,
      };

  const validationSchema = object().shape({
    low_bal_limit: string().when("low_balance", {
      is: (val) => val === true,
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .matches(/^\d+$/, "Only numeric digits are allowed")
          .required("Low Balance Limit is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    // Custom validation for login_otp checkboxes
    is_mobile: string().when("login_otp", {
      is: (val) => val === true,
      then: (schema) =>
        schema.test(
          "at-least-one-checkbox",
          "At least one option (Mobile, Email, or WhatsApp) must be selected",
          function (value) {
            const { is_mobile, is_email, is_whatsapp } = this.parent;
            return is_mobile || is_email || is_whatsapp;
          }
        ),
      otherwise: (schema) => schema.notRequired(),
    }),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!userSettingData?.user_ID;
    const url = isUpdate ? `user-setting/update` : "user-setting/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        low_bal_limit: Number(payload.low_bal_limit) || 0, // fallback to 0 if empty
        low_balance: payload.low_balance ? 1 : 0,
        login_alert: payload.login_alert ? 1 : 0,
        login_otp: payload.login_otp ? 1 : 0,
        is_mobile: payload.is_mobile ? 1 : 0,
        is_email: payload.is_email ? 1 : 0,
        is_whatsapp: payload.is_whatsapp ? 1 : 0,
        daily_usage: payload.daily_usage ? 1 : 0,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          showSnackBar("success", response.data.message);
          // Update the userSettingData to reflect the new saved state
          // setUserSettingData(payload);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );
  };

  return (
    <Box px={2}>
      <Typography variant="h5" color="primary" sx={{ fontWeight: "semibold" }}>
        Alert Access
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          setFieldError,
          validateField,
        }) => {
          // console.log("form values => ", values);
          // console.log("buttoncndt => ", dirty, isValid, errors);

          // Helper function to validate checkbox selection
          const validateCheckboxSelection = (currentValues) => {
            if (currentValues.login_otp) {
              const hasSelection =
                currentValues.is_mobile ||
                currentValues.is_email ||
                currentValues.is_whatsapp;
              if (!hasSelection) {
                setFieldError(
                  "is_mobile",
                  "At least one option (Mobile, Email, or WhatsApp) must be selected"
                );
              } else {
                setFieldError("is_mobile", undefined);
              }
            } else {
              setFieldError("is_mobile", undefined);
            }
          };

          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid display={"flex"} gap={6}>
                  <Grid
                    size={{ xs: 12, sm: 8, md: 4 }}
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    <Typography
                      sx={{
                        fontSize: "14px",
                        fontWeight: "600",
                        color: "grey",
                      }}
                    >
                      Low Balance
                    </Typography>
                    <Switch
                      id="low_balance"
                      name="low_balance"
                      label="Low Balance"
                      checked={values.low_balance}
                      onChange={(e) => {
                        // setFieldValue("low_balance", false);
                        const isChecked = e.target.checked;
                        setFieldValue("low_balance", isChecked);

                        // Use setTimeout to smooth the transition
                        if (!isChecked) {
                          setTimeout(() => {
                            setFieldValue("low_bal_limit", "");
                            // setFieldValue("mobile", "");
                          }, 150); // Small delay for smooth transition
                        }
                      }}
                      slotProps={{ "aria-label": "controlled" }}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 6 }} sx={{ pl: 2 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="low_bal_limit"
                      id="low_bal_limit"
                      label="Limit *"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={!values?.low_balance}
                      style={{
                        transition: "opacity 0.3s ease-in-out",
                        opacity: values?.low_balance ? 1 : 0.6,
                      }}
                    />
                  </Grid>
                </Grid>
              </Grid>

              <Grid
                size={{ xs: 12, sm: 8, md: 4 }}
                sx={{ display: "flex", alignItems: "center" }}
              >
                <Typography
                  sx={{
                    fontSize: "14px",
                    fontWeight: "600",
                    color: "grey",
                  }}
                >
                  Login Alert
                </Typography>
                <Switch
                  id="login_alert"
                  name="login_alert"
                  label="Login Alert"
                  checked={values.login_alert}
                  onChange={(e) =>
                    setFieldValue("login_alert", e.target.checked)
                  }
                  sx={{ ml: 1 }}
                  slotProps={{ "aria-label": "controlled" }}
                />
              </Grid>

              <Grid
                size={{ xs: 12, sm: 8, md: 4 }}
                sx={{ display: "flex", alignItems: "center", gap: "12px" }}
              >
                <Typography
                  sx={{
                    fontSize: "14px",
                    fontWeight: "600",
                    color: "grey",
                  }}
                >
                  Login OTP
                </Typography>
                <Switch
                  id="login_otp"
                  name="login_otp"
                  label="Login Otp"
                  checked={values.login_otp}
                  onChange={(e) => {
                    const isChecked = e.target.checked;
                    setFieldValue("login_otp", isChecked);

                    if (isChecked) {
                      // Set default values when switch is turned on
                      setFieldValue("is_mobile", true);
                      setFieldValue("is_email", true);
                      setFieldValue("is_whatsapp", false);
                      // Clear any validation errors since we have selections
                      setFieldError("is_mobile", undefined);
                    } else {
                      // Clear all checkboxes when switch is turned off
                      setFieldValue("is_mobile", false);
                      setFieldValue("is_email", false);
                      setFieldValue("is_whatsapp", false);
                      // Clear any validation errors
                      setFieldError("is_mobile", undefined);
                    }
                  }}
                  slotProps={{ "aria-label": "controlled" }}
                />

                {/* Conditionally show checkboxes only when login_otp is true */}
                {values.login_otp && (
                  <Grid
                    size={{ xs: 12, sm: 8, md: 4 }}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      transition:
                        "opacity 0.3s ease-in-out, transform 0.3s ease-in-out",
                      opacity: values.login_otp ? 1 : 0,
                      transform: values.login_otp
                        ? "translateX(0)"
                        : "translateX(-10px)",
                    }}
                  >
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="is_mobile"
                          id="is_mobile"
                          checked={values?.is_mobile}
                          onChange={(e) => {
                            const newValue = e.target.checked;
                            setFieldValue("is_mobile", newValue);

                            // Validate after state change
                            setTimeout(() => {
                              validateCheckboxSelection({
                                ...values,
                                is_mobile: newValue,
                              });
                            }, 0);
                          }}
                        />
                      }
                      label="Mobile"
                      labelPlacement="end"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="is_email"
                          id="is_email"
                          checked={values?.is_email}
                          onChange={(e) => {
                            const newValue = e.target.checked;
                            setFieldValue("is_email", newValue);

                            // Validate after state change
                            setTimeout(() => {
                              validateCheckboxSelection({
                                ...values,
                                is_email: newValue,
                              });
                            }, 0);
                          }}
                        />
                      }
                      label="Email"
                      labelPlacement="end"
                    />
                    <FormControlLabel
                      control={
                        <Checkbox
                          name="is_whatsapp"
                          id="is_whatsapp"
                          checked={values?.is_whatsapp}
                          onChange={(e) => {
                            const newValue = e.target.checked;
                            setFieldValue("is_whatsapp", newValue);

                            // Validate after state change
                            setTimeout(() => {
                              validateCheckboxSelection({
                                ...values,
                                is_whatsapp: newValue,
                              });
                            }, 0);
                          }}
                        />
                      }
                      label="WhatsApp"
                      labelPlacement="end"
                    />
                  </Grid>
                )}
              </Grid>

              {/* Show validation error for checkboxes */}
              {values.login_otp && errors.is_mobile && (
                <Grid size={{ xs: 12 }}>
                  <Typography
                    color="error"
                    variant="caption"
                    sx={{
                      marginLeft: "16px",
                      transition: "opacity 0.3s ease-in-out",
                      opacity: errors.is_mobile ? 1 : 0,
                    }}
                  >
                    {errors.is_mobile}
                  </Typography>
                </Grid>
              )}

              <Grid
                size={{ xs: 12, sm: 8, md: 4 }}
                sx={{ display: "flex", alignItems: "center" }}
              >
                <Typography
                  sx={{
                    fontSize: "14px",
                    fontWeight: "600",
                    color: "grey",
                  }}
                >
                  Daily Usage
                </Typography>
                <Switch
                  id="daily_usage"
                  name="daily_usage"
                  label="Daily Usage"
                  checked={values.daily_usage}
                  onChange={(e) =>
                    setFieldValue("daily_usage", e.target.checked)
                  }
                  inputProps={{ "aria-label": "controlled" }}
                />
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AlertModule;
