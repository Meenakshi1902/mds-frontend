import React, { useEffect, useRef, useState } from "react";
import APIKeyTMIDForm from "./APIKeyTMIDForm/APIKeyTMIDForm";
import TMIDForm from "./TMIDForm/TMIDForm";
import { getRequest } from "../../../../helpers/http.helper";

function APIKeyTMID({ closeModal, showSnackBar }) {
  const [apiKeyData, setApiKeyData] = useState([]);
  const hasFetchedApiKeyData = useRef(false);
  const FetchApiKeyData = () => {
    getRequest("user-profile", function (response) {
      // console.log("response => ", response?.data?.data);
      if (!response?.data?.errors && response?.data?.data) {
        setApiKeyData(response?.data?.data);
      } else {
        // Handling error messages
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
        setApiKeyData([]);
      }
    });
  };

  useEffect(() => {
    if (hasFetchedApiKeyData.current) return;
    FetchApiKeyData();
    hasFetchedApiKeyData.current = true;
  }, []);
  return (
    <>
      <APIKeyTMIDForm
        closeModal={closeModal}
        showSnackBar={showSnackBar}
        apiKeyData={apiKeyData}
        FetchApiKeyData={FetchApiKeyData}
      />
      <TMIDForm
        closeModal={closeModal}
        showSnackBar={showSnackBar}
        apiKeyData={apiKeyData}
        FetchApiKeyData={FetchApiKeyData}
      />
    </>
  );
}

export default APIKeyTMID;
