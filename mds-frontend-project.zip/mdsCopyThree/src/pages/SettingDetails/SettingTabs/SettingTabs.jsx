import React from "react";
import { Tabs, Tab, Box } from "@mui/material";
import AlertModule from "../SettingTabs/AlertModule/AlertModule";
import ChangePassword from "../SettingTabs/ChangePassword/ChangePassword";
import APIKeyTMID from "../SettingTabs/APIKeyTMID/APIKeyTMID";

const SettingTabs = ({ closeModal, showSnackBar }) => {
  const [value, setValue] = React.useState(0);
  const handleChange = (event, newValue) => setValue(newValue);

  const tabData = [
    {
      label: "Alert Module",
      component: (
        <AlertModule closeModal={closeModal} showSnackBar={showSnackBar} />
      ),
    },
    {
      label: "Change Password",
      component: (
        <ChangePassword closeModal={closeModal} showSnackBar={showSnackBar} />
      ),
    },
    {
      label: "API Key & TMID",
      component: (
        <APIKeyTMID closeModal={closeModal} showSnackBar={showSnackBar} />
      ),
    },
  ];

  return (
    <Box sx={{ width: "100%" }}>
      {/* Tabs Header */}
      <Box sx={{ bgcolor: "#ffffff", borderBottom: "1px solid #d3d3d3" }}>
        <Tabs
          value={value}
          onChange={handleChange}
          TabIndicatorProps={{ style: { display: "none" } }}
          sx={{ minHeight: 40, height: 40 }}
        >
          {tabData.map((tab, index) => (
            <Tab
              key={tab.label}
              label={tab.label}
              sx={{
                minHeight: 40,
                height: 40,
                px: 3,
                mx: "2px",
                borderRadius: 0,
                bgcolor: value === index ? "#ffffff" : "#eaf4ff",
                fontSize: 14,
                fontWeight: value === index ? 600 : 400,
                color: "#000",
                textTransform: "none",
                "&:hover": {
                  bgcolor: value === index ? "#ffffff" : "#d7eaff",
                },
              }}
            />
          ))}
        </Tabs>
      </Box>

      {/* Tab Content */}
      <Box sx={{ p: 2 }}>{tabData[value]?.component}</Box>
    </Box>
  );
};

export default SettingTabs;
