import React, { useEffect, useState } from "react";
import { Box, Grid } from "@mui/material";
import { defaultSnackBarState } from "../../utils/common";
import SnackbarAlert from "../../components/SnackBarMessage/SnackbarAlert";
import ModalComponent from "../../components/ModalComponent/ModalComponent";
import { useNavigate } from "react-router";
import SettingTabs from "./SettingTabs/SettingTabs";

const SettingDetails = ({ viewMode = true }) => {
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [openModal, setOpenModal] = useState(viewMode);

  const navigate = useNavigate();

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setOpenModal(false);
      navigate("/dashboard");
    }
  };

  // useEffect(() => {
  //   console.log("ProfileDetails mounted");
  // }, []);

  // const openModal = (type) => {
  //   setEnableAddForm(type);
  // };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      <ModalComponent
        style={style}
        closeModal={closeModal}
        enableAddForm={openModal}
      >
        {openModal && (
          <SettingTabs closeModal={closeModal} showSnackBar={showSnackBar} />
        )}
      </ModalComponent>

      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default SettingDetails;
