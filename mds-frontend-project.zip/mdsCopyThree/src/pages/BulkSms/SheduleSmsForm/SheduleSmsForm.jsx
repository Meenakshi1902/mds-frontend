import React, { useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../helpers/http.helper";
import { validationRegex } from "../../../utils/common";
import PersonIcon from "@mui/icons-material/Person";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import dayjs from "dayjs";
import CustomDatePicker from "../../../components/CustomDatePicker/CustomDatePicker";
import IconTimePickerField from "../../../components/IconTimePickerField/IconTimePickerField";

const SheduleSmsForm = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const [openSheduleDateOne, setOpenSheduleDateOne] = useState(false);
  const [openSheduleDateTwo, setOpenSheduleDateTwo] = useState(false);
  const [openSheduleDateThree, setOpenSheduleDateThree] = useState(false);
  const [openSheduleDateFour, setOpenSheduleDateFour] = useState(false);

  // State for time pickers
  const [timePickersOpen, setTimePickersOpen] = useState({
    scheduleTimeOne: false,
    scheduleTimeTwo: false,
    scheduleTimeThree: false,
    scheduleTimeFour: false,
  });

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        p_name: rowData.p_name || "",
        sheduleDateOne: rowData.sheduleDateOne || "",
        sheduleDateTwo: rowData.sheduleDateTwo || "",
        sheduleDateThree: rowData.sheduleDateThree || "",
        sheduleDateFour: rowData.sheduleDateFour || "",
        scheduleTimeOne: rowData.scheduleTimeOne || "",
        scheduleTimeTwo: rowData.scheduleTimeTwo || "",
        scheduleTimeThree: rowData.scheduleTimeThree || "",
        scheduleTimeFour: rowData.scheduleTimeFour || "",
      }
    : {
        p_name: "",
        sheduleDateOne: "",
        sheduleDateTwo: "",
        sheduleDateThree: "",
        sheduleDateFour: "",
        scheduleTimeOne: "",
        scheduleTimeTwo: "",
        scheduleTimeThree: "",
        scheduleTimeFour: "",
      };

  const validationSchema = object().shape({
    p_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Plan Name is required"),
  });

  // Helper function to format datetime for submission
  const formatDateTime = (date, time) => {
    if (!date) return "";

    const dateStr =
      typeof date === "string" ? date : dayjs(date).format("YYYY-MM-DD");
    const timeStr = time || "12:00";

    return `${dateStr} ${timeStr}:00`;
  };

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate ? `plans/update/${rowData.id}` : "plans/store?";

    const requestFunction = isUpdate ? putRequest : postRequest;

    // Format the datetime fields for submission
    const formattedPayload = {
      ...payload,
      sheduleDateOne: formatDateTime(
        payload.sheduleDateOne,
        payload.scheduleTimeOne
      ),
      sheduleDateTwo: formatDateTime(
        payload.sheduleDateTwo,
        payload.scheduleTimeTwo
      ),
      sheduleDateThree: formatDateTime(
        payload.sheduleDateThree,
        payload.scheduleTimeThree
      ),
      sheduleDateFour: formatDateTime(
        payload.sheduleDateFour,
        payload.scheduleTimeFour
      ),
    };

    // Remove the separate time fields from payload
    delete formattedPayload.scheduleTimeOne;
    delete formattedPayload.scheduleTimeTwo;
    delete formattedPayload.scheduleTimeThree;
    delete formattedPayload.scheduleTimeFour;

    requestFunction(url, formattedPayload, (response) => {
      if (!response?.data?.errors && response?.status === 200) {
        setRefreshTable(true);
        showSnackBar("success", response.data.message);
      } else {
        // Handling error messages
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          // Optionally display errors in a snack bar or UI
          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
      }
    });

    closeModal();
  };

  // Helper function to handle date change and set default time
  const handleDateChange = (fieldName, timeFieldName, value, setFieldValue) => {
    // console.log("date value => ", typeof value);
    setFieldValue(fieldName, value);
    if (!value) {
      setFieldValue(timeFieldName, "");
    }
    // If a date is selected and no time is set, set default time to 12:00
    if (value && !initialValues[timeFieldName]) {
      setFieldValue(timeFieldName, "12:00");
    }
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {/* {isEdit ? "Edit Plan Details" : "Create Plan Details"} */}
        Schedule For Later
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
        }}
      >
        {({
          setFieldValue,
          setFieldTouched,
          setFieldError,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* Schedule 1 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateOne"
                        name="sheduleDateOne"
                        label="Schedule 1 Date"
                        value={
                          values.sheduleDateOne
                            ? dayjs(values.sheduleDateOne)
                            : null
                        }
                        disablePast={true}
                        format="DD-MM-YYYY"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateOne}
                        onClose={() => setOpenSheduleDateOne(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateOne",
                            "scheduleTimeOne",
                            value,
                            setFieldValue
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateOne(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateOne(true);
                            },
                            size: "small",
                            readOnly: true,
                            //   onBlur: handleBlur,
                            error:
                              touched.sheduleDateOne &&
                              Boolean(errors.sheduleDateOne),
                            helperText: touched.sheduleDateOne
                              ? errors.sheduleDateOne
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: "2px" }}>
                    <IconTimePickerField
                      icon={PersonIcon}
                      name="scheduleTimeOne"
                      label="Schedule Time 1"
                      value={values?.scheduleTimeOne}
                      errors={errors}
                      touched={touched}
                      timePickersOpen={timePickersOpen?.scheduleTimeOne}
                      setTimePickersOpen={setTimePickersOpen}
                      setFieldTouched={setFieldTouched}
                      setFieldValue={setFieldValue}
                      setFieldError={setFieldError}
                      values={values}
                      showErrIfTouched={true}
                    />
                  </Grid>
                </Grid>

                {/* Schedule 2 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateTwo"
                        name="sheduleDateTwo"
                        label="Schedule 2 Date"
                        value={
                          values.sheduleDateTwo
                            ? dayjs(values.sheduleDateTwo)
                            : null
                        }
                        disablePast={true}
                        format="DD-MM-YYYY"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateTwo}
                        onClose={() => setOpenSheduleDateTwo(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateTwo",
                            "scheduleTimeTwo",
                            value,
                            setFieldValue
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateTwo(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateTwo(true);
                            },
                            size: "small",
                            readOnly: true,
                            //   onBlur: handleBlur,
                            error:
                              touched.sheduleDateTwo &&
                              Boolean(errors.sheduleDateTwo),
                            helperText: touched.sheduleDateTwo
                              ? errors.sheduleDateTwo
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: "2px" }}>
                    <IconTimePickerField
                      icon={PersonIcon}
                      name="scheduleTimeTwo"
                      label="Schedule Time 2"
                      value={values?.scheduleTimeTwo}
                      errors={errors}
                      touched={touched}
                      timePickersOpen={timePickersOpen?.scheduleTimeTwo}
                      setTimePickersOpen={setTimePickersOpen}
                      setFieldTouched={setFieldTouched}
                      setFieldValue={setFieldValue}
                      setFieldError={setFieldError}
                      values={values}
                      showErrIfTouched={true}
                    />
                  </Grid>
                </Grid>

                {/* Schedule 3 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateThree"
                        name="sheduleDateThree"
                        label="Schedule 3 Date"
                        value={
                          values.sheduleDateThree
                            ? dayjs(values.sheduleDateThree)
                            : null
                        }
                        disablePast={true}
                        format="DD-MM-YYYY"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateThree}
                        onClose={() => setOpenSheduleDateThree(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateThree",
                            "scheduleTimeThree",
                            value,
                            setFieldValue
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateThree(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateThree(true);
                            },
                            size: "small",
                            readOnly: true,
                            //   onBlur: handleBlur,
                            error:
                              touched.sheduleDateThree &&
                              Boolean(errors.sheduleDateThree),
                            helperText: touched.sheduleDateThree
                              ? errors.sheduleDateThree
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>
                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: "2px" }}>
                    <IconTimePickerField
                      icon={PersonIcon}
                      name="scheduleTimeThree"
                      label="Schedule Time 3"
                      value={values?.scheduleTimeThree}
                      errors={errors}
                      touched={touched}
                      timePickersOpen={timePickersOpen?.scheduleTimeThree}
                      setTimePickersOpen={setTimePickersOpen}
                      setFieldTouched={setFieldTouched}
                      setFieldValue={setFieldValue}
                      setFieldError={setFieldError}
                      values={values}
                      showErrIfTouched={true}
                    />
                  </Grid>
                </Grid>

                {/* Schedule 4 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateFour"
                        name="sheduleDateFour"
                        label="Schedule 4 Date"
                        value={
                          values.sheduleDateFour
                            ? dayjs(values.sheduleDateFour)
                            : null
                        }
                        disablePast={true}
                        format="DD-MM-YYYY"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateFour}
                        onClose={() => setOpenSheduleDateFour(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateFour",
                            "scheduleTimeFour",
                            value,
                            setFieldValue
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateFour(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateFour(true);
                            },
                            size: "small",
                            readOnly: true,
                            //   onBlur: handleBlur,
                            error:
                              touched.sheduleDateFour &&
                              Boolean(errors.sheduleDateFour),
                            helperText: touched.sheduleDateFour
                              ? errors.sheduleDateFour
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 6, md: 5 }} sx={{ mt: "2px" }}>
                    <IconTimePickerField
                      icon={PersonIcon}
                      name="scheduleTimeFour"
                      label="Schedule Time 4"
                      value={values?.scheduleTimeFour}
                      errors={errors}
                      touched={touched}
                      timePickersOpen={timePickersOpen?.scheduleTimeFour}
                      setTimePickersOpen={setTimePickersOpen}
                      setFieldTouched={setFieldTouched}
                      setFieldValue={setFieldValue}
                      setFieldError={setFieldError}
                      values={values}
                      showErrIfTouched={true}
                    />
                  </Grid>
                </Grid>
              </Grid>

              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default SheduleSmsForm;
