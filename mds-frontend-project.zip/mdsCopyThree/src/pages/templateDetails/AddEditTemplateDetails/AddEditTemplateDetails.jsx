import React, { use, useEffect, useRef, useState } from "react";
import { FastField, Formik } from "formik";
import {
  Autocomplete,
  Grid,
  Box,
  TextField,
  Button,
  Divider,
  Typography,
  FormHelperText,
  CircularProgress,
  TextareaAutosize,
} from "@mui/material";
import { array, mixed, object, string } from "yup";
import {
  characterType,
  fetchPostDropDownData,
  validationRegex,
} from "../../../utils/common";
import {
  getRequest,
  postRequest,
  putRequest,
} from "../../../helpers/http.helper";
import { useDispatch, useSelector } from "react-redux";
import IconAutocompleteField from "../../../components/IconAutocompleteField/IconAutocompleteField";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import AddIcon from "@mui/icons-material/Add";
import CheckboxInputAutocompleteField from "../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";
import {
  fetchDropDownData,
  resetDropDownData,
} from "../../../features/dropdown/dropDownSlice";

const AddEditTemplateDetails = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const [contentTypeDate, setContentTypeData] = useState([]);
  const [categoryTypeDate, setCategoryTypeDate] = useState([]);
  const [isUserId, setUserId] = useState("");

  const hasFetchedUsersDropdowns = useRef(false);
  const hasFetchedSendersDropdowns = useRef(false);
  // const dispatch = useDispatch();
  // const dropdownData = useSelector(
  //   (state) => state.dropdown.dropdownData || []
  // );
  // const senders = dropdownData?.senderDropdown?.senders;

  const [senders, setSenderData] = useState([]);
  const [usersData, setUsersData] = useState([]);
  // const usersData = dropdownData?.userDropdown?.usersData;

  // const error = useSelector((state) => state.dropdown.error);
  const [senderAutocompleteOpen, setSenderAutocompleteOpen] = useState(false);
  const user = useSelector((state) => state?.auth?.user);
  const shouldIncludeUserId = [2, 3, 4].includes(user?.role_ID);

  // const hasFetchedDropdowns = useRef(false);
  const hasFetchedCategoryType = useRef(false);

  // useEffect(() => {
  //   if (!user?.id || hasFetchedDropdowns.current) return;

  //   const dropdownConfigs = [
  //     {
  //       type: "senderDropdown",
  //       url: "template-details/getSenders",
  //       body: { id: user.id },
  //     },
  //     // Only include userDropdown if role_ID !== 1
  //     ...(user?.role_ID !== 1
  //       ? [
  //           {
  //             type: "userDropdown",
  //             url: "template-details/roleBasedUsers",
  //             body: {},
  //           },
  //         ]
  //       : []),
  //   ];

  //   dropdownConfigs.forEach((config) => {
  //     dispatch(fetchDropDownData(config));
  //   });

  //   hasFetchedDropdowns.current = true;
  // }, [dispatch, user?.id]);

  // for multiple dropdown error handling

  // Fetch userDropdown ONCE when user.id is available
  // useEffect(() => {
  //   if (user?.role_ID === 1) return;

  //   dispatch(
  //     fetchDropDownData({
  //       type: "userDropdown",
  //       url: "template-details/roleBasedUsers",
  //       body: {},
  //     })
  //   );
  // }, [dispatch, user?.id]);

  useEffect(() => {
    if (user?.role_ID === 1 || hasFetchedUsersDropdowns.current) return;
    // FetchedGroupDropDownData();
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);

  // useEffect(() => {
  //   if (!user?.role_ID) return;

  //   const userIdToUse = user?.role_ID === 1 ? user?.id : isUserId;
  //   if (!userIdToUse) return;

  //   dispatch(
  //     fetchDropDownData({
  //       type: "senderDropdown",
  //       url: "template-details/getSenders",
  //       body: { id: userIdToUse },
  //     })
  //   );
  // }, [dispatch, isUserId, user?.role_ID, user?.id]);

  useEffect(() => {
    if (!user?.role_ID || hasFetchedSendersDropdowns.current) return;

    const userIdToUse = user?.role_ID === 1 ? user?.id : isUserId;
    if (!userIdToUse) return;
    // FetchedGroupDropDownData();
    const payload = { id: userIdToUse };
    fetchPostDropDownData(
      `template-details/getSenders`,
      payload,
      setSenderData,
      showSnackBar
    );
    hasFetchedSendersDropdowns.current = true;
  }, [isUserId, user?.role_ID, user?.id]);

  // useEffect(() => {
  //   const keys = Object.keys(error || {});
  //   keys.forEach((key) => {
  //     const err = error[key];

  //     if (typeof err === "string") {
  //       showSnackBar("error", err);
  //     } else if (typeof err === "object" && err !== null) {
  //       Object.entries(err).forEach(([field, messages]) => {
  //         showSnackBar(
  //           "error",
  //           `${field}: ${
  //             Array.isArray(messages) ? messages.join(", ") : messages
  //           }`
  //         );
  //       });
  //     }
  //   });
  // }, [error]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  // Helper function to transform sender_ID data for edit mode
  const transformSenderIdForEdit = (senderIdData) => {
    if (!senderIdData || !Array.isArray(senderIdData)) {
      return [];
    }

    return senderIdData.map((item) => {
      // If it's already an object with id property, return as is
      if (typeof item === "object" && item !== null && item.id) {
        return item;
      }
      // If it's a primitive value, transform it to object format
      return { id: item };
    });
  };

  useEffect(() => {
    if ((!isEdit && !rowData?.user_ID) || hasFetchedSendersDropdowns.current)
      return;

    const payload = { id: rowData.user_ID };
    fetchPostDropDownData(
      "template-details/getSenders",
      payload,
      setSenderData,
      showSnackBar
    );
    hasFetchedSendersDropdowns.current = true;
  }, [isEdit, rowData?.user_ID]);

  const initialValues = isEdit
    ? {
        ...rowData,
        template_ID: rowData?.template_ID || "",
        template_name: rowData?.template_name || "",
        sender_ID: transformSenderIdForEdit(rowData?.sender_ID),
        content_type_ID: rowData?.content_type_ID || "",
        category_type_ID: rowData?.category_type_ID || "",
        character_type: rowData?.character_type || "",
        template_data: rowData?.template_data || "",
        ...(shouldIncludeUserId && {
          user_ID: rowData.user_ID || "",
        }),
      }
    : {
        template_ID: "",
        template_name: "",
        sender_ID: [],
        content_type_ID: "",
        category_type_ID: "",
        character_type: "",
        template_data: "",
        ...(shouldIncludeUserId && {
          user_ID: "",
        }),
      };

  const validationSchema = object().shape({
    template_ID: string()
      .required("The Template ID field is required")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(
        validationRegex?.digit19Regex,
        "The Template ID must contain exactly 19 digits"
      ),
    template_name: string()
      .min(2, "Must be 2 characters or more ")
      .max(200, "Must be 200 characters or less")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Template name is Required"),
    // Enhanced validation schema for sender_ID with better error handling
    sender_ID: array()
      .of(
        object().shape({
          id: mixed().required("Sender ID is required"),
        })
      )
      .min(1, "At least one sender ID is required")
      .required("Sender ID is required"),
    // user_ID: string().required("User ID is required"),
    user_ID: string().when([], {
      is: () => shouldIncludeUserId,
      then: (schema) => schema.required("User ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    content_type_ID: string().required("Content type is Required"),
    category_type_ID: string().required("Category type is Required"),
    character_type: string().required("Character type is Required"),
    template_data: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Template data is Required"),
  });

  const fetchContentCategoryTypeDropDownData = () => {
    getRequest("template-details/getContentCategoryType", function (response) {
      if (!response?.data?.errors) {
        setContentTypeData(response?.data?.ContentData);
        setCategoryTypeDate(response?.data?.CategoryData);
      } else {
        // Handling error messages
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
        setContentTypeData([]);
        setCategoryTypeDate([]);
      }
    });
  };

  useEffect(() => {
    if (hasFetchedCategoryType.current) return;
    fetchContentCategoryTypeDropDownData();
    hasFetchedCategoryType.current = true;
  }, []);

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `template-details/update/${rowData.id}`
      : "template-details/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        ...(shouldIncludeUserId && {
          user_ID: payload.user_ID || "",
        }),
        ...(user?.role_ID === 1 &&
          user?.id && {
            user_ID: user?.id,
          }),
        sender_ID: payload?.sender_ID?.map((item) => item?.id),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Template Details" : "Create Template Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("formValues => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors);
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="template_name"
                    id="template_name"
                    label="Template Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="template_ID"
                    id="template_ID"
                    label="Template ID *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="content_type_ID"
                    id="content_type_ID"
                    label="Content type *"
                    multiple={false}
                    options={contentTypeDate || []}
                    getOptionLabel={(option) => option?.content_type || ""}
                    value={
                      contentTypeDate?.find(
                        (type) => type?.id === values?.content_type_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("content_type_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="category_type_ID"
                    id="category_type_ID"
                    label="Category type *"
                    multiple={false}
                    options={categoryTypeDate || []}
                    getOptionLabel={(option) => option?.category_type || ""}
                    value={
                      categoryTypeDate?.find(
                        (type) => type?.id === values?.category_type_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("category_type_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <CheckboxInputAutocompleteField
                    icon={PersonIcon}
                    id="sender_ID"
                    name="sender_ID"
                    label="Select Sender ID *"
                    options={senders || []}
                    getOptionLabel={(option) => option?.sender_ID}
                    getOptionValue={(option) => option?.id}
                    getDisplayValue={(option) => option?.sender_ID}
                    value={values?.sender_ID}
                    setFieldValue={setFieldValue}
                    handleBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    autoCompleteOpen={senderAutocompleteOpen}
                    setAutoCompleteOpen={setSenderAutocompleteOpen}
                    disabled={!values?.user_ID && user?.role_ID !== 1}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="character_type"
                    id="character_type"
                    label="Character Type *"
                    multiple={false}
                    options={characterType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      characterType?.find(
                        (type) => type === values?.character_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("character_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      mb: 1,
                    }}
                  >
                    <Typography
                      variant="body1"
                      component="label"
                      htmlFor="template_data"
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      Template data
                      <Typography
                        component="span"
                        sx={{ color: "red", ml: 0.5 }}
                      >
                        *
                      </Typography>
                    </Typography>

                    <Button
                      startIcon={<AddIcon />}
                      onClick={() =>
                        setFieldValue(
                          "template_data",
                          `${values.template_data}{#var#}`
                        )
                      }
                      sx={{
                        textTransform: "none",
                        backgroundColor: "#1976d2",
                        color: "#ffffff",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                        },
                      }}
                      variant="contained"
                      color="primary"
                    >
                      Add Variable
                    </Button>
                  </Box>

                  <TextareaAutosize
                    name="template_data"
                    id="template_data"
                    aria-label="template_data"
                    minRows={3}
                    placeholder="Type Message Here"
                    value={values.template_data}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                  />
                  {errors?.template_data && touched?.template_data && (
                    <FormHelperText error>
                      {errors?.template_data}
                    </FormHelperText>
                  )}
                </Grid>
                {shouldIncludeUserId && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconAutocompleteField
                      icon={PersonIcon}
                      name="user_ID"
                      id="user_ID"
                      label="Select User *"
                      multiple={false}
                      options={usersData || []}
                      getOptionLabel={(option) => option?.username || ""}
                      value={
                        usersData?.find(
                          (type) => type?.id === values?.user_ID
                        ) || null
                      }
                      isOptionEqualToValue={(option, value) =>
                        option?.id === value?.id
                      }
                      onChange={(e, value) => {
                        const userId = value?.id || "";
                        setFieldValue("user_ID", userId);
                        setUserId(userId);

                        if (!userId) {
                          setFieldValue("sender_ID", "");
                          dispatch(
                            resetDropDownData({ type: "senderDropdown" })
                          );
                        }
                      }}
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                )}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditTemplateDetails;
