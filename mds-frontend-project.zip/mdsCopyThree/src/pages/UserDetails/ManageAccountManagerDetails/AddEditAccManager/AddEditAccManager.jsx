import React, { useEffect, useMemo, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import { validationRegex } from "../../../../utils/common";

const AddEditAccManager = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const generatePassword = () => {
    const length = 10;
    const charset =
      "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@$!%*?&";
    let password = "";
    for (let i = 1, n = charset.length; i <= length; ++i) {
      password += charset.charAt(Math.floor(Math.random() * n));
    }
    return password;
  };

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = useMemo(() => {
    return isEdit
      ? {
          ...rowData,
          username: rowData?.username || "",
          password: rowData?.password || "",
          full_name: rowData?.full_name || "",
          mobile_no: rowData?.mobile_no || "",
          email: rowData?.email || "",
        }
      : {
          username: "",
          password: generatePassword(),
          full_name: "",
          mobile_no: "",
          email: "",
        };
  }, [rowData]); // Only recompute if rowData changes

  const validationSchema = object().shape({
    username: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Username is Required"),
    password: isEdit
      ? string().notRequired()
      : string()
          .required("Password is Required")
          .when([], {
            is: (value) => typeof value === "string" && value.length <= 10,
            then: (schema) =>
              schema
                .min(8, "Password must be at least 8 characters")
                .max(10, "Password cannot be more than 10 characters")
                .matches(
                  validationRegex?.password,
                  "Password must include letters, numbers, and special characters"
                ),
            otherwise: (schema) =>
              schema.test(
                "is-invalid",
                "Password must be a string and at most 10 characters",
                (val) => typeof val === "string" && val.length <= 10
              ),
          }),
    full_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Full name is Required"),
    // mobile_no: string()
    //   .required("Mobile Number is Required")
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .matches(
    //     /^(\d{10,15})(,\d{10,15}){0,2}$/,
    //     "You can enter up to 3 contact numbers separated by commas"
    //   ),
    mobile_no: string()
      .required("The Contact No is required")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed"),
    email: string()
      .matches(
        validationRegex?.blankSpace,
        validationRegex?.blankSpacesMessage,
        validationRegex?.email
      )
      .required("Email is required"),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `account-manager/update/${rowData.id}`
      : "account-manager/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit
          ? "Edit Account Manager Details"
          : "Add Account Manager Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="username"
                    id="username"
                    label="User Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {isEdit ? null : (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="password"
                      id="password"
                      label="Password *"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                )}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="mobile_no"
                    id="mobile_no"
                    label="Mobile No *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="full_name"
                    id="full_name"
                    label="Full Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="email"
                    id="email"
                    label="Email *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="status"
                    id="status"
                    label="Select Status *"
                    multiple={false}
                    options={Status || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      Status?.find((type) => type === values?.status) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("status", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid> */}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditAccManager;
