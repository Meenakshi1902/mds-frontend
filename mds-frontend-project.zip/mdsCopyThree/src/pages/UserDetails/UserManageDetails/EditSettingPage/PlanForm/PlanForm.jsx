import React, { useEffect, useRef } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../../components/IconInputField/IconInputField";
import { useDispatch, useSelector } from "react-redux";
import { SET_PLANDROPDOWN } from "../../../../../constants/StoreConstants";
import { fetchDropDownData } from "../../../../../features/dropdown/dropDownSlice";
import IconAutocompleteField from "../../../../../components/IconAutocompleteField/IconAutocompleteField";

const PlanForm = ({ userRowData, showSnackBar }) => {
  const hasFetchedDropdowns = useRef(false);
  const dispatch = useDispatch();
  const dropdownData = useSelector(
    (state) => state.dropdown.dropdownData || []
  );

  const planData = dropdownData?.planData?.data;
  const error = useSelector((state) => state.dropdown.error);
  const initialValues = {
    user_ID: userRowData?.id || "",
    plan_ID: "",
  };

  const validationSchema = object().shape({
    plan_ID: string().required("Plan Name is required"),
  });

  useEffect(() => {
    if (hasFetchedDropdowns.current) return;

    const dropdownConfigs = [
      {
        type: SET_PLANDROPDOWN,
        url: "plans",
        body: {
          start: "",
          limit: "",
          search_text: "",
          sorting: "",
          order_by: "",
        },
      },
    ];

    dropdownConfigs.forEach((config) => {
      dispatch(fetchDropDownData(config));
    });

    hasFetchedDropdowns.current = true; // prevent future calls
  }, [dispatch]);

  // for multiple dropdown error handling
  useEffect(() => {
    const keys = Object.keys(error || {});
    keys.forEach((key) => {
      const err = error[key];

      if (typeof err === "string") {
        showSnackBar("error", err);
      } else if (typeof err === "object" && err !== null) {
        Object.entries(err).forEach(([field, messages]) => {
          showSnackBar(
            "error",
            `${field}: ${
              Array.isArray(messages) ? messages.join(", ") : messages
            }`
          );
        });
      }
    });
  }, [error]);

  const handleSubmit = (payload) => {
    postRequest(
      `plan-assign`,
      {
        ...payload,
        user_ID: userRowData?.id || "",
        plan_ID: payload?.plan_ID || "",
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          // setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Typography
                  sx={{ fontWeight: 600, fontSize: "1rem", marginTop: "5px" }}
                >
                  Plan
                </Typography>
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="plan_ID"
                    id="plan_ID"
                    label="Select Plan *"
                    multiple={false}
                    options={planData || []}
                    getOptionLabel={(option) => option?.p_name || ""}
                    value={
                      planData?.find((type) => type?.id === values?.plan_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("plan_ID", value?.id);
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
                <Box display="flex" justifyContent="flex-end">
                  <Button
                    sx={{
                      textTransform: "none",
                      backgroundColor: "#1976d2",
                      color: "#ffffff",
                      boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                      borderRadius: "8px",
                      "&:hover": {
                        backgroundColor: "#1976d2",
                      },
                    }}
                    variant="contained"
                    color="primary"
                    type="submit"
                    onClick={() => handleSubmit(values)}
                    disabled={!dirty || !isValid}
                  >
                    Plan Save
                  </Button>
                  {isSubmitting && <CircularProgress size={24} />}
                </Box>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default PlanForm;
