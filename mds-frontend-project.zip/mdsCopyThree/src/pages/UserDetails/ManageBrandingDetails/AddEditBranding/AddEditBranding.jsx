import React from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  IconButton,
  FormHelperText,
} from "@mui/material";
import { mixed, object, string } from "yup";
import {
  postDocumentRequest,
  postRequest,
  putRequest,
} from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import { validationRegex } from "../../../../utils/common";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

const AddEditBranding = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const isEdit = rowData && Object.keys(rowData).length > 0;

  console.log("values isEdit => ", isEdit);

  const initialValues = isEdit
    ? {
        ...rowData,
        company_name: rowData?.company_name || "",
        website_address: rowData?.website_address || "",
        company_tagline: rowData?.company_tagline || "",
        support_url: rowData?.support_url || "",
        support_mobile: rowData?.support_mobile || "",
        support_email: rowData?.support_email || "",
        company_logo_path: rowData?.company_logo_path || null,
      }
    : {
        company_name: "",
        website_address: "",
        company_tagline: "",
        support_url: "",
        support_mobile: "",
        support_email: "",
        company_logo_path: null,
      };

  const validationSchema = object().shape({
    company_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Company Name is required"),
    website_address: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Website Address is required"),
    company_tagline: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Company Tagline is required"),
    support_url: string()
      .matches(
        validationRegex?.blankSpace,
        validationRegex?.blankSpacesMessage,
        validationRegex.url,
        "Invalid URL format"
      )
      .required("Support URL is required"),
    // support_mobile: string()
    //   .matches(
    //     validationRegex?.blankSpace,
    //     validationRegex?.blankSpacesMessage,
    //     validationRegex?.mobile
    //   )
    //   .required("Support Mobile is required"),
    support_mobile: string()
      .required("The Contact No is required")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed"),
    support_email: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Support Email is required"),
    login_page_description: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Login page description is required"),
    company_logo_path: mixed()
      .required("Only image files (JPG, PNG) are required.")
      .test(
        "fileType",
        "Only image files (JPG, PNG) are allowed.",
        function (value) {
          if (value && value instanceof File) {
            const validTypes = ["image/jpeg", "image/png"];
            return validTypes.includes(value.type);
          }
          return true;
        }
      )
      .test("fileSize", "File size must be less than 2 MB", function (value) {
        if (value && value instanceof File) {
          return value.size <= 2097152;
        }
        return true;
      }),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const sanitizedPayload = { ...payload };
    const url = isUpdate ? `branding/update/${rowData.id}` : "branding/store";

    if (isEdit && typeof sanitizedPayload.company_logo_path === "string") {
      delete sanitizedPayload.company_logo_path;
    }
    // const requestFunction = isUpdate ? postDocumentRequest : postRequest;

    postDocumentRequest(
      url,
      {
        ...sanitizedPayload,
        ...(isEdit && { _method: "PUT" }),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Branding Details" : "Add Branding Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("values => ", values);
          // console.log(
          //   "values.company_logo_path.name => ",
          //   values.company_logo_path?.name
          // );
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="company_name"
                    id="company_name"
                    label="Company Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="company_tagline"
                    id="company_tagline"
                    label="Company Tagline *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="website_address"
                    id="website_address"
                    label="Website Address *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  {values?.company_logo_path === null ? (
                    <Box>
                      <Button
                        name="company_logo_path"
                        id="company_logo_path"
                        variant="outlined"
                        fullWidth
                        startIcon={<CloudUploadIcon />}
                        // onClick={() => documentFileRef.current.click()}
                        onClick={() => {
                          documentFileRef.current.click();
                          // Mark the field as touched when clicking the upload button
                          // setFieldTouched('company_logo_path', true);
                        }}
                        sx={{
                          color: "#181C32",
                          // borderColor: '#181C32',
                          borderColor:
                            errors?.company_logo_path &&
                            touched?.company_logo_path
                              ? "error.main"
                              : "#181C32",
                          "&:hover": {
                            color: "#FFFFFF",
                            backgroundColor: "#A780FF",
                          },
                        }}
                        onBlur={handleBlur}
                      >
                        Upload Company Logo*
                        <VisuallyHiddenInput type="file" />
                      </Button>
                      <input
                        ref={documentFileRef}
                        accept="image/jpeg, image/png"
                        // accept=".doc,.docx,.pdf"
                        type="file"
                        name="company_logo_path"
                        id="company_logo_path"
                        style={{ display: "none" }}
                        // onChange={(e) => setFieldValue('company_logo_path', e.target.files[0])}
                        // onChange={(e) => {
                        //   setFieldValue('company_logo_path', e.target.files[0]);
                        //   setFieldTouched('company_logo_path', true);
                        // }}
                        onChange={(e) => {
                          const file = e.target.files[0];
                          // console.log('file => ', file);
                          const validTypes = ["image/jpeg", "image/png"];
                          const isFileValid = validTypes.includes(file.type);
                          if (file && isFileValid) {
                            setFieldValue("company_logo_path", file);
                            showSnackBar(
                              "success",
                              "Image Uploaded Successfully"
                            );
                            // setFieldTouched('company_logo_path', true);
                          } else if (file.size > 2097152) {
                            // 2 MB limit
                            setFieldError(
                              "company_logo_path",
                              "File size must be less than 2 MB"
                            );
                            e.target.value = ""; // Reset the input
                          } else {
                            setFieldValue("company_logo_path", null);
                            showSnackBar("error", "Invalid File Format");
                          }
                        }}
                        onBlur={handleBlur}
                      />
                      {/* <FormHelperText
                        sx={{
                          color: '#d32f2f',
                          fontweight: 400
                        }}>
                        Supported formats: JPG, PNG
                      </FormHelperText> */}
                      {/* {errors?.company_logo_path && touched?.company_logo_path && (
                        <FormHelperText error>{errors?.company_logo_path}</FormHelperText>
                      )} */}
                    </Box>
                  ) : (
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      {/* <Typography
                        sx={{
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          maxWidth: "fit-content",
                        }}
                      >
                        Uploaded File:&nbsp;&nbsp;
                        {typeof values.company_logo_path === "object"
                          ? values.company_logo_path
                          : rowData?.company_logo_path}
                      </Typography> */}
                      <Typography
                        sx={{
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          maxWidth: "fit-content",
                        }}
                      >
                        Uploaded File:&nbsp;&nbsp;
                        {typeof values.company_logo_path === "object"
                          ? values.company_logo_path?.name
                          : rowData?.company_logo_path}
                      </Typography>

                      <IconButton
                        onClick={() => setFieldValue("company_logo_path", null)}
                      >
                        <CloseIcon />
                      </IconButton>
                    </Box>
                  )}
                  {errors?.company_logo_path && touched?.company_logo_path && (
                    <FormHelperText error>
                      {errors?.company_logo_path}
                    </FormHelperText>
                  )}
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="support_url"
                    id="support_url"
                    label="Support URL *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="support_mobile"
                    id="support_mobile"
                    label="Support Mobile"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="support_email"
                    id="support_email"
                    label="Support Email"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Typography
                    variant="body1"
                    component="label"
                    htmlFor="login_page_description"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    Login Page Description
                    <Typography component="span" sx={{ color: "red", ml: 0.5 }}>
                      *
                    </Typography>
                  </Typography>

                  <TextareaAutosize
                    name="login_page_description"
                    id="login_page_description"
                    aria-label="login_page_description"
                    minRows={3}
                    placeholder="Type Login Page Description"
                    value={values.login_page_description}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                  />
                  {errors?.login_page_description &&
                    touched?.login_page_description && (
                      <FormHelperText error>
                        {errors?.login_page_description}
                      </FormHelperText>
                    )}
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditBranding;
