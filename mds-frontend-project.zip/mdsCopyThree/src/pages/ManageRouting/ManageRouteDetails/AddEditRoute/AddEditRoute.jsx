import React, { useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  DndData,
  senderID,
  Status,
  validationRegex,
} from "../../../../utils/common";
import IconTimePickerField from "../../../../components/IconTimePickerField/IconTimePickerField";
import moment from "moment"; // Make sure moment is imported

const AddEditRoute = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);

  const [timePickersOpen, setTimePickersOpen] = useState({
    start_time: false,
    end_time: false,
  });

  // Keys and labels for the time fields
  // const timeFieldKeys = [
  //   { key: "start_time", label: "Start Time" },
  //   { key: "end_time", label: "End Time" },
  // ];

  // Function to set errors for time fields based on validation rules
  // const setErrorsForTimeFields = (setFieldError, values) => {
  //   // Clear previous errors first
  //   setFieldError("start_time", "");
  //   setFieldError("end_time", "");

  //   for (let i = 0; i < timeFieldKeys.length - 1; i++) {
  //     const currentField = timeFieldKeys[i];
  //     const nextField = timeFieldKeys[i + 1];

  //     if (!values[currentField.key] || !values[nextField.key]) {
  //       continue; // Skip validation if either field is empty
  //     }

  //     const currentFieldTime = moment(values[currentField.key], "HH:mm");
  //     const nextFieldTime = moment(values[nextField.key], "HH:mm");

  //     if (currentFieldTime.isValid() && nextFieldTime.isValid()) {
  //       if (currentFieldTime.isSameOrAfter(nextFieldTime)) {
  //         setFieldError(
  //           currentField.key,
  //           `${currentField.label} should be before ${nextField.label}`
  //         );
  //       }
  //     }
  //   }
  // };

  const isEdit = rowData && Object.keys(rowData).length > 0;
  const initialValues = isEdit
    ? {
        ...rowData,
        route_name: rowData.route_name || "",
        rate: rowData.rate || "",
        start_time: rowData.start_time || "",
        end_time: rowData.end_time || "",
        sender_ID: rowData.sender_ID === 1 ? "Yes" : "No" || "",
        DND_check_ID: rowData.DND_check_ID === 1 ? "Enable" : "Disable" || "",
      }
    : {
        route_name: "",
        rate: "",
        start_time: "",
        end_time: "",
        sender_ID: "",
        DND_check_ID: "",
      };

  const validationSchema = object().shape({
    route_name: string().required("Route Name is required"),
    rate: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(
        validationRegex?.numbersAndDecimalAllowed,
        "Only numbers and up to 2 decimal places are allowed"
      )
      .required("Rate is required"),
    start_time: string().required("Start Time is required"),
    end_time: string().required("End Time is required"),
    sender_ID: string().required("Sender ID is required"),
    DND_check_ID: string().required("DND Check is required"),
  });

  const handleSubmit = (payload) => {
    // Format time values for API
    // const timeForRoute = {
    //   start_time: payload.start_time,
    //   end_time: payload.end_time,
    // };

    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `manage-route/update/${rowData.id}`
      : "manage-route/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        sender_ID: payload?.sender_ID === "Yes" ? 1 : 0,
        DND_check_ID: payload?.DND_check_ID === "Enable" ? 1 : 0,
        // start_time: timeForRoute?.start_time,
        // end_time: timeForRoute?.end_time,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );
  };

  // Function to show error if a field is touched and has an error
  const showErrIfTouched = (key, errors, touched) => {
    return touched[key] && errors[key];
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Manage Route Details" : "Add Manage Route Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { setSubmitting, resetForm }) => {
          setSubmitting(true);
          handleSubmit(values);
          setSubmitting(false);
          resetForm();
        }}
      >
        {({
          setFieldValue,
          setFieldTouched,
          setFieldError,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleSubmit: formikHandleSubmit,
        }) => {
          // console.log("form values => ", values);
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="route_name"
                    id="route_name"
                    label="Route Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconAutocompleteField
                      icon={PersonIcon}
                      name="status"
                      id="status"
                      label="Select Status *"
                      multiple={false}
                      options={Status || []}
                      getOptionLabel={(option) => option || ""}
                      value={
                        Status?.find((type) => type === values?.status) || null
                      }
                      isOptionEqualToValue={(option, value) => option === value}
                      onChange={(e, value) => {
                        setFieldValue("status", value || "");
                      }}
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid> */}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="rate"
                    id="rate"
                    label="Rate *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="DND_check_ID"
                    id="DND_check_ID"
                    label="Select DND Check *"
                    multiple={false}
                    options={DndData || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      DndData?.find((type) => type === values?.DND_check_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("DND_check_ID", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* <Grid container spacing={8}> */}
                {/* Start Time */}
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconTimePickerField
                    icon={PersonIcon}
                    name="start_time"
                    label="Start Time *"
                    value={values?.start_time}
                    errors={errors}
                    touched={touched}
                    timePickersOpen={timePickersOpen?.start_time}
                    setTimePickersOpen={setTimePickersOpen}
                    setFieldTouched={setFieldTouched}
                    setFieldValue={setFieldValue}
                    setFieldError={setFieldError}
                    values={values}
                    // setErrorsForTimeFields={setErrorsForTimeFields}
                    showErrIfTouched={showErrIfTouched}
                  />
                </Grid>

                {/* End Time */}
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconTimePickerField
                    icon={PersonIcon}
                    name="end_time"
                    label="End Time *"
                    value={values?.end_time}
                    errors={errors}
                    touched={touched}
                    timePickersOpen={timePickersOpen?.end_time}
                    setTimePickersOpen={setTimePickersOpen}
                    setFieldTouched={setFieldTouched}
                    setFieldValue={setFieldValue}
                    setFieldError={setFieldError}
                    values={values}
                    // setErrorsForTimeFields={setErrorsForTimeFields}
                    showErrIfTouched={showErrIfTouched}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }} sx={{ mt: 1 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="sender_ID"
                    id="sender_ID"
                    label="Sender ID *"
                    multiple={false}
                    options={senderID || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      senderID?.find((type) => type === values?.sender_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("sender_ID", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
                {/* </Grid> */}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  type="submit"
                  onClick={formikHandleSubmit}
                  disabled={!dirty || !isValid || isSubmitting}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditRoute;
