import {
  Autocomplete,
  Box,
  TextField,
  Checkbox,
  FormHelperText,
} from "@mui/material";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

// Dynamic Checkbox Autocomplete Component with Icon
const CheckboxInputAutocompleteField = ({
  icon: IconComponent,
  name,
  id,
  label,
  options = [],
  getOptionLabel,
  getOptionValue, // Function to get the value/id from option
  getDisplayValue, // Function to get display value from option
  value,
  onChange,
  setFieldValue,
  errors,
  touched,
  handleBlur,
  iconBgColor = "#A780FF",
  iconColor = "white",
  openOnFocus = false,
  clearOnBlur = true,
  autoCompleteOpen,
  setAutoCompleteOpen,
  ...autocompleteProps
}) => {
  // Transform the value to match options format for Autocomplete
  const valueArray = Array.isArray(value) ? value : value ? [value] : [];

  const transformedValue = valueArray
    .map((item) => {
      // Handle different data formats
      let itemId;
      if (typeof item === "object" && item !== null) {
        itemId = item.id || getOptionValue(item);
      } else {
        itemId = item;
      }

      return options.find((option) => getOptionValue(option) === itemId);
    })
    .filter(Boolean); // Remove undefined

  // If above code is not working try with below code.

  // const valueArray = Array.isArray(value) ? value : value ? [value] : [];

  // console.log("valueArray => ", valueArray); // [{ id: 54 }, { id: 55 }]

  // const transformedValue = valueArray
  //   .map((item) => {
  //     console.log("item => ", item); // { id: 54 }, { id: 55 }
  //     // Handle different data formats
  //     let itemId;

  //     console.log("typeof item => ", typeof item); // object
  //     if (typeof item === "object" && item !== null) {
  //       console.log("inside typeof item => ", typeof item); // object

  //       itemId = item.id || getOptionValue(item);

  //       console.log("item.id => ", item.id); // 54
  //       console.log("getOptionValue(item) => ", getOptionValue(item)); // 54

  //       console.log("itemId => ", itemId); // 54
  //     } else {
  //       itemId = item;

  //       console.log("itemId else => ", itemId); // not called
  //     }

  //     // Enhanced finding logic with better debugging
  //     const foundOption = options.find((option) => {
  //       const optionValue = getOptionValue(option);

  //       console.log("optionValue => ", optionValue); // 54
  //       console.log(
  //         `Comparing option value: ${optionValue} (type: ${typeof optionValue}) with itemId: ${itemId} (type: ${typeof itemId})`
  //       );  // not called

  //       console.log("optionValue === itemId => ", optionValue === itemId) // not called.

  //       // Try both strict equality and loose equality
  //       return (
  //         optionValue === itemId ||
  //         String(optionValue) === String(itemId) ||
  //         Number(optionValue) === Number(itemId)
  //       );
  //     });

  //     console.log("foundOption => ", foundOption); // undefined
  //     return foundOption;
  //   })
  //   .filter(Boolean); // Remove undefined

  // console.log("transformedValue => ", transformedValue); // []

  const handleChange = (event, newValue, reason) => {
    if (newValue?.length === 0) {
      setFieldValue(name, []);
    } else {
      // Transform selected options to the format needed for form values
      const selectedValues = newValue?.map((option) => {
        return getOptionValue
          ? { id: getOptionValue(option) }
          : { id: option?.id };
      });

      setFieldValue(name, selectedValues);
    }

    // Close autocomplete when removing an option
    if (reason === "removeOption" && setAutoCompleteOpen) {
      setAutoCompleteOpen(false);
    }

    // Call custom onChange if provided
    if (onChange) {
      onChange(event, newValue, reason);
    }
  };

  // Custom onBlur handler to ensure proper validation
  const handleFieldBlur = (event) => {
    // Call the original handleBlur from Formik
    if (handleBlur) {
      handleBlur(event);
    }

    // Also trigger validation by calling setFieldValue with current value
    // This ensures the field is marked as touched and validated
    setFieldValue(name, value, true);
  };

  return (
    <Box>
      <Box
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "flex-start",
        }}
      >
        {/* Icon Section */}
        <Box
          sx={{
            backgroundColor: iconBgColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "8px",
            borderRadius: "4px 0 0 4px",
            border: "1px solid #e0e0e0",
            borderRight: "none",
            height: "40px",
            zIndex: 1,
          }}
        >
          <IconComponent sx={{ color: iconColor, fontSize: "20px" }} />
        </Box>

        {/* Autocomplete Section */}
        <Autocomplete
          id={id}
          name={name}
          options={options}
          getOptionLabel={getOptionLabel}
          fullWidth
          size="small"
          multiple
          openOnFocus={openOnFocus}
          clearOnBlur={clearOnBlur}
          open={autoCompleteOpen}
          onOpen={() => setAutoCompleteOpen && setAutoCompleteOpen(true)}
          onClose={() => setAutoCompleteOpen && setAutoCompleteOpen(false)}
          value={transformedValue}
          onChange={handleChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: "0 4px 4px 0",
              "& fieldset": {
                borderLeft: "none",
              },
            },
          }}
          renderOption={(props, option, { selected }) => {
            const { key, ...optionProps } = props;
            return (
              <li key={key} {...optionProps}>
                <Checkbox
                  icon={icon}
                  checkedIcon={checkedIcon}
                  style={{ marginRight: 8 }}
                  checked={selected}
                />
                {getDisplayValue
                  ? getDisplayValue(option)
                  : getOptionLabel(option)}
              </li>
            );
          }}
          renderInput={(params) => (
            <TextField
              {...params}
              label={label}
              name={name}
              onBlur={handleFieldBlur}
              error={!!errors?.[name] && !!touched?.[name]}
              // helperText={
              //   errors?.[name] && touched?.[name] ? errors?.[name] : ""
              // }
            />
          )}
          {...autocompleteProps}
        />
      </Box>
      {errors?.[name] && touched?.[name] && (
        <FormHelperText error>{errors?.[name]}</FormHelperText>
      )}
    </Box>
  );
};

export default CheckboxInputAutocompleteField;
