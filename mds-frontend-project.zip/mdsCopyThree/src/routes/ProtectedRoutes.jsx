import { Navigate, Outlet } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { login } from "../features/auth/authSlice";
import { selectUser } from "../features/auth/authSelectors";
import Loader from "../components/Loader/Loader";

const ProtectedRoute = () => {
  const dispatch = useDispatch();
  const user = useSelector(selectUser);
  const token = useSelector((state) => state.auth.token);
  const [loading, setLoading] = useState(true); // To handle hydration from localStorage

  useEffect(() => {
    if (!user && !token) {
      const dataFromStorage = localStorage.getItem("authInfo");

      if (dataFromStorage) {
        try {
          const data = JSON.parse(dataFromStorage);
          dispatch(login(data));
        } catch (e) {
          console.error("Failed to parse authInfo from localStorage", e);
        }
      }
    }
    setLoading(false);
  }, [dispatch, user, token]);

  if (loading)
    return (
      <>
        <Loader />
      </>
    );

  if (!user || !token) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
