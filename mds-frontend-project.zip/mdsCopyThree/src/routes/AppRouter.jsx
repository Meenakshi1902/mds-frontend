import React, { lazy } from "react";
import { Routes, Route } from "react-router";
import ProtectedRoute from "./ProtectedRoutes";
import { menuRoutes } from "./menuRoutes";
const Login = lazy(() => import("../pages/Login/Login"));
const ForgotPassword = lazy(() =>
  import("../Auth/ForgotPasswordForm/ForgotPasswordForm")
);
const RegisterForm = lazy(() => import("../Auth/RegisterForm/RegisterForm"));
// const ResetPassword = lazy(() => import("../Auth/ForgotPasswordForm/ResetPassword/ResetPassword"));
const ProtectedLayout = lazy(() => import("../layouts/ProtectedLayout"));

const AppRouter = () => (
  <Routes>
    <Route path="/" element={<Login />} />
    <Route path="/login" element={<Login />} />
    <Route path="/register" element={<RegisterForm />} />
    <Route path="/forgot-password" element={<ForgotPassword />} />
    {/* <Route path="/reset-password/:token" element={<ResetPassword />} /> */}
    <Route element={<ProtectedRoute />}>
      <Route element={<ProtectedLayout />}>
        {menuRoutes.map(({ path, component: Component }, index) => {
          if (!Component) {
            console.warn(`Route at path "${path}" has no component.`);
            return null;
          }
          return <Route key={index} path={path} element={<Component />} />;
        })}
      </Route>
    </Route>
  </Routes>
);

export default AppRouter;
