// redux/slices/dropDownSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { postRequest } from "../../helpers/http.helper"; // Update with your actual API handler

export const fetchDropDownData = createAsyncThunk(
  "dropdown/fetchDropDownData",
  async ({ type, url, body }, { rejectWithValue }) => {
    try {
      return await new Promise((resolve) => {
        postRequest(url, body, (response) => {
          const apiErrors = response?.data?.errors;

          if (!apiErrors) {
            resolve({ type, data: response?.data || [] });
          } else {
            // console.log("type error =>", type);
            // console.log("response =>", apiErrors);

            // Instead of calling reject(), directly return rejectWithValue
            resolve(
              rejectWithValue({
                type,
                errors: apiErrors,
              })
            );
          }
        });
      });
    } catch (error) {
      return rejectWithValue({
        type,
        errors: { general: error.message || "Unknown error" },
      });
    }
  }
);

const dropDownSlice = createSlice({
  name: "dropdown",
  initialState: {
    dropdownData: {}, // dynamic data: { senderDropdown: [...], userDropdown: [...] }
    error: {},
    loading: {},
  },
  reducers: {
    // Reset a specific dropdown by type
    resetDropDownData: (state, action) => {
      const { type } = action.payload;
      if (type) {
        state.dropdownData[type] = [];
        state.error[type] = null;
        state.loading[type] = false;
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDropDownData.pending, (state, action) => {
        const type = action.meta.arg.type;
        state.loading[type] = true;
        state.error[type] = null;
      })
      .addCase(fetchDropDownData.fulfilled, (state, action) => {
        const { type, data } = action.payload;
        state.dropdownData[type] = data;
        state.loading[type] = false;
      })
      .addCase(fetchDropDownData.rejected, (state, action) => {
        const { type, errors } = action.payload;
        state.dropdownData[type] = [];
        state.loading[type] = false;
        state.error[type] = errors;
      });
  },
});

// Export actions and reducer
export const { resetDropDownData } = dropDownSlice.actions;
export default dropDownSlice.reducer;
