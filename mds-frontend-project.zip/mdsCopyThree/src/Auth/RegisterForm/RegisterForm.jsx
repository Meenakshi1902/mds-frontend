import {
  Box,
  Button,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
  //   Checkbox,
  //   FormControlLabel,
} from "@mui/material";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { string, object, ref, boolean } from "yup";
import { useState } from "react";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useNavigate, Link } from "react-router";
import { defaultSnackBarState } from "../../utils/common";
import SnackbarAlert from "../../components/SnackBarMessage/SnackbarAlert";
import LoginRightSideImg from "../../assets/Images/LoginRighSideImg.png";
import { postRequest } from "../../helpers/http.helper";
import mdslogo from "../../assets/logos/mdslogo.png";

const RegisterForm = () => {
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const registerSchema = object().shape({
    username: string()
      .required("Enter Your Username")
      .min(3, "Username must be at least 3 characters")
      .matches(
        /^[a-zA-Z0-9._-]+$/,
        "Username can only contain letters, numbers, dots, underscores, and hyphens"
      ),
    full_name: string()
      .required("Enter Your Full Name")
      .min(2, "Full name must be at least 2 characters"),
    email: string()
      .required("Enter Your Email")
      .email("Enter a valid email address"),
    password: string()
      .required("Enter Your Password")
      .min(8, "Password must be at least 8 characters")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
        "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
      ),
    password_confirmation: string()
      .required("Confirm Your Password")
      .oneOf([ref("password")], "Passwords must match"),
    // agreeTerms: boolean().oneOf(
    //   [true],
    //   "You must agree to the terms and conditions"
    // ),
  });

  const initialValue = {
    username: "",
    full_name: "",
    email: "",
    password: "",
    password_confirmation: "",
    agreeTerms: false,
  };

  const navigate = useNavigate();

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type,
      message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 5000);
  };

  const handleBackToLogin = () => {
    navigate("/login");
  };

  const handleRegister = (formData, props) => {
    const payload = {
      username: formData.username,
      full_name: formData.full_name,
      email: formData.email,
      password: formData.password,
      password_confirmation: formData.password_confirmation,
    };

    postRequest("register", payload, function (res) {
      if (res?.data?.error) {
        showSnackBar("error", res?.data?.error);
        props.setSubmitting(false);
        return;
      }

      showSnackBar(
        "success",
        res?.data?.message ||
          "Registration successful! Please login to continue."
      );
      props.resetForm();
      props.setSubmitting(false);

      // Redirect to login after successful registration
      setTimeout(() => {
        navigate("/login");
      }, 2000);
    });
  };

  return (
    <Box
      display="flex"
      height="100vh"
      alignItems="center"
      justifyContent="center"
      sx={{ overflow: "hidden" }}
    >
      {/* Main Content Wrapper */}
      <Box
        display="flex"
        flexDirection="row"
        alignItems="center"
        backgroundColor="#F2F2F2"
      >
        <Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              marginLeft: "95px",
            }}
          >
            <img
              src={mdslogo}
              alt="logo"
              style={{
                maxWidth: "100%",
                height: "40px",
                objectFit: "contain",
              }}
            />
          </Box>

          {/* Login Form */}
          <Box
            maxWidth="500px"
            width="100%"
            sx={{
              bgcolor: "#ffffff",
              borderRadius: 2,
              boxShadow: 2,
              p: 4,
              m: 4,
              display: "flex",
              flexDirection: "column",
              justifyContent: "flex-start", // Important
              height: "310px", // You can adjust this height as needed
              overflowY: "auto",
            }}
          >
            <Formik
              initialValues={initialValue}
              validationSchema={registerSchema}
              onSubmit={handleRegister}
              enableReinitialize
            >
              {(props) => {
                const { isSubmitting, dirty, isValid, errors } = props;
                // console.log("formconditions => ", isSubmitting, dirty, isValid, errors);
                // const { userName, password} = props.values;
                // console.log("userForm => ", userName, password);
                return (
                  <Form style={{ width: "100%" }}>
                    <Typography variant="h6" mb={3} color="primary">
                      Create Account
                    </Typography>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Username*"
                        name="username"
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="username" />}
                        error={
                          Boolean(props.errors.username) &&
                          props.touched.username
                        }
                      />
                    </Box>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Full Name*"
                        name="full_name"
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="full_name" />}
                        error={
                          Boolean(props.errors.full_name) &&
                          props.touched.full_name
                        }
                      />
                    </Box>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Email*"
                        name="email"
                        type="email"
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="email" />}
                        error={
                          Boolean(props.errors.email) && props.touched.email
                        }
                      />
                    </Box>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Password*"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="password" />}
                        error={
                          Boolean(props.errors.password) &&
                          props.touched.password
                        }
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() => setShowPassword(!showPassword)}
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showPassword ? (
                                  <Visibility />
                                ) : (
                                  <VisibilityOff />
                                )}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Confirm Password*"
                        name="password_confirmation"
                        type={showConfirmPassword ? "text" : "password"}
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={
                          <ErrorMessage name="password_confirmation" />
                        }
                        error={
                          Boolean(props.errors.password_confirmation) &&
                          props.touched.password_confirmation
                        }
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() =>
                                  setShowConfirmPassword(!showConfirmPassword)
                                }
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showConfirmPassword ? (
                                  <Visibility />
                                ) : (
                                  <VisibilityOff />
                                )}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>

                    <Button
                      type="submit"
                      variant="contained"
                      fullWidth
                      sx={{
                        bgcolor: "blue",
                        color: "white !important",
                        py: 1.5,
                        "&:hover": {
                          bgcolor: "#5459AC",
                        },
                        borderRadius: 2,
                        boxShadow: 2,
                        mb: 2,
                      }}
                      disabled={!dirty || !isValid || isSubmitting}
                    >
                      {isSubmitting ? "Creating Account..." : "Create Account"}
                    </Button>

                    {snackbarState?.show && (
                      <SnackbarAlert
                        open={snackbarState?.show}
                        message={snackbarState?.message}
                        severity={snackbarState?.type}
                        vertical={snackbarState?.vertical}
                        horizontal={snackbarState?.horizontal}
                      />
                    )}
                  </Form>
                );
              }}
            </Formik>
          </Box>
          <Box sx={{ ml: 12, mt: 4, textAlign: "center" }}>
            <Typography variant="body1" gutterBottom color="primary">
              Already have an account?
            </Typography>

            <Box textAlign="center">
              <Button
                variant="text"
                onClick={handleBackToLogin}
                sx={{
                  color: "primary.main",
                  textTransform: "none",
                  "&:hover": {
                    backgroundColor: "rgba(0, 0, 0, 0.04)",
                  },
                }}
              >
                ← Back to Login
              </Button>
            </Box>

            <Typography variant="body2">
              Read our{" "}
              <Link
                to="/#"
                color="primary"
                style={{ textDecoration: "underline" }}
              >
                Terms
              </Link>{" "}
              and{" "}
              <Link
                to="/#"
                color="primary"
                style={{ textDecoration: "underline" }}
              >
                Conditions
              </Link>
            </Typography>
          </Box>
        </Box>

        {/* Right Side Image */}
        <Box
          flex={1}
          display="flex"
          justifyContent="center"
          alignItems="center"
          sx={{ px: 4, ml: { xs: 0, sm: 6, md: 12 } }} // Adjusts margin-left responsively
        >
          <img
            src={LoginRightSideImg}
            alt="MDS Right Side Image"
            style={{ maxWidth: "100vw", height: "auto" }}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default RegisterForm;
