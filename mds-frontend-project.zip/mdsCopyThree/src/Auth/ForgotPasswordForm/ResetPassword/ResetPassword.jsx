import {
  Box,
  Button,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
} from "@mui/material";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { string, object, ref } from "yup";
import { useState } from "react";
import { Link, useParams } from "react-router";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { defaultSnackBarState } from "../../../utils/common";
import SnackbarAlert from "../../../components/SnackBarMessage/SnackbarAlert";
import LoginRightSideImg from "../../../assets/Images/LoginRighSideImg.png";
import { postRequest } from "../../../helpers/http.helper";
import mdslogo from "../../../assets/logos/mdslogo.png";

const ResetPassword = ({
  email,
  handleBackToLogin,
  //   handleBackToForgotPassword,
}) => {
  //   const { token } = useParams();
  // const token = getTokenFromStorage();

  // console.log("token => ", token);

  // const emailData = getEmailFromStorage();

  //   console.log("emailData => ", emailData);

  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const resetPasswordSchema = object().shape({
    // token: string().required("Enter the reset token from your email"),
    password: string()
      .min(8, "Password must be at least 8 characters")
      .required("Enter your new password"),
    password_confirmation: string()
      .oneOf([ref("password"), null], "Passwords must match")
      .required("Confirm your new password"),
  });

  const initialValue = {
    token: "",
    password: "",
    password_confirmation: "",
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type,
      message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 5000);
  };

  //   const handleBackToLogin = () => {
  //     navigate("/login");
  //   };

  const handleResetPassword = (formData, props) => {
    const payload = {
      email: emailData,
      token: token,
      password: formData.password,
      password_confirmation: formData.password_confirmation,
    };

    postRequest("password/reset", payload, function (res) {
      if (res?.data?.error) {
        showSnackBar("error", res?.data?.error);
        props.setSubmitting(false);
        return;
      }

      showSnackBar(
        "success",
        res?.data?.message || "Password reset successfully"
      );

      // Wait for snackbar to show, then redirect to login
      setTimeout(() => {
        handleBackToLogin();
      }, 2000);

      props.resetForm();
      props.setSubmitting(false);
    });
  };

  return (
    <Box
      display="flex"
      height="100vh"
      alignItems="center"
      justifyContent="center"
      sx={{ overflow: "hidden" }}
    >
      {/* Main Content Wrapper */}
      <Box
        display="flex"
        flexDirection="row"
        alignItems="center"
        backgroundColor="#F2F2F2"
      >
        <Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              marginLeft: "95px",
            }}
          >
            <img
              src={mdslogo}
              alt="logo"
              style={{
                maxWidth: "100%",
                height: "40px",
                objectFit: "contain",
              }}
            />
          </Box>

          {/* Login Form */}
          <Box
            maxWidth="500px"
            width="100%"
            sx={{
              bgcolor: "#ffffff",
              borderRadius: 2,
              boxShadow: 2,
              p: 4,
              m: 4,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
          >
            <Formik
              initialValues={initialValue}
              validationSchema={resetPasswordSchema}
              onSubmit={handleResetPassword}
              enableReinitialize
            >
              {(props) => {
                const { isSubmitting, dirty, isValid, errors } = props;
                // console.log("formconditions => ", isSubmitting, dirty, isValid, errors);
                // const { userName, password} = props.values;
                // console.log("userForm => ", userName, password);
                return (
                  <Form style={{ width: "100%" }}>
                    <Typography variant="h6" mb={2} color="primary">
                      Pending, Plz Don't Test
                    </Typography>
                    <Typography variant="h6" mb={2} color="primary">
                      Reset Password
                    </Typography>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="New Password*"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="password" />}
                        error={
                          Boolean(props.errors.password) &&
                          props.touched.password
                        }
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() => setShowPassword(!showPassword)}
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showPassword ? (
                                  <Visibility />
                                ) : (
                                  <VisibilityOff />
                                )}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>

                    <Box mb={3}>
                      <Field
                        as={TextField}
                        label="Confirm New Password*"
                        name="password_confirmation"
                        type={showConfirmPassword ? "text" : "password"}
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={
                          <ErrorMessage name="password_confirmation" />
                        }
                        error={
                          Boolean(props.errors.password_confirmation) &&
                          props.touched.password_confirmation
                        }
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() =>
                                  setShowConfirmPassword(!showConfirmPassword)
                                }
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showConfirmPassword ? (
                                  <Visibility />
                                ) : (
                                  <VisibilityOff />
                                )}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>

                    <Button
                      type="submit"
                      variant="contained"
                      fullWidth
                      sx={{
                        bgcolor: "blue",
                        color: "white !important",
                        py: 1.5,
                        "&:hover": {
                          bgcolor: "#5459AC",
                        },
                        borderRadius: 2,
                        boxShadow: 2,
                        mb: 2,
                      }}
                      disabled={!dirty || !isValid || isSubmitting}
                    >
                      {isSubmitting ? "Resetting..." : "Reset Password"}
                    </Button>

                    <Box textAlign="center">
                      <Button
                        variant="text"
                        onClick={handleBackToLogin}
                        sx={{
                          color: "primary.main",
                          textTransform: "none",
                          "&:hover": {
                            backgroundColor: "rgba(0, 0, 0, 0.04)",
                          },
                        }}
                      >
                        ← Back to Login
                      </Button>
                    </Box>

                    {snackbarState?.show && (
                      <SnackbarAlert
                        open={snackbarState?.show}
                        message={snackbarState?.message}
                        severity={snackbarState?.type}
                        vertical={snackbarState?.vertical}
                        horizontal={snackbarState?.horizontal}
                      />
                    )}
                  </Form>
                );
              }}
            </Formik>
          </Box>
          <Box sx={{ ml: 12, mt: 4, textAlign: "center" }}>
            <Typography variant="body1" gutterBottom color="primary">
              Don't have an account?
            </Typography>

            <Link
              to="/#"
              style={{
                display: "block",
                marginBottom: 8,
                textDecoration: "underline",
              }}
            >
              Get Started
            </Link>

            <Typography variant="body2">
              Read our{" "}
              <Link
                to="/#"
                color="primary"
                style={{ textDecoration: "underline" }}
              >
                Terms
              </Link>{" "}
              and{" "}
              <Link
                to="/#"
                color="primary"
                style={{ textDecoration: "underline" }}
              >
                Conditions
              </Link>
            </Typography>
          </Box>
        </Box>

        {/* Right Side Image */}
        <Box
          flex={1}
          display="flex"
          justifyContent="center"
          alignItems="center"
          sx={{ px: 4, ml: { xs: 0, sm: 6, md: 12 } }} // Adjusts margin-left responsively
        >
          <img
            src={LoginRightSideImg}
            alt="MDS Right Side Image"
            style={{ maxWidth: "100vw", height: "auto" }}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default ResetPassword;
