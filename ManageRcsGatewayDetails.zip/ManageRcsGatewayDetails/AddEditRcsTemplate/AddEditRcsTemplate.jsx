import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  FormGroup,
  FormControlLabel,
  Checkbox,
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { boolean, object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  fetchGetDropDownData,
  fetchPostDropDownData,
  transformMultipleIdForEdit,
  gatewayType,
  BotType,
  Status,
  validationRegex,
} from "../../../../utils/common";

const AddEditRcsTemplate = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);
  const [usersData, setUsersData] = useState([]);
  console.log(usersData);

  const hasFetchedUserDropdowns = useRef(false);
  const [isUserId, setUserId] = useState("");
  const templateType = ["Simple Text", "Rich Card/Carousel"];
  const [gatewayOptions, setGatewayOptions] = useState([]);

  useEffect(() => {
    if (!user?.id || hasFetchedUserDropdowns.current) return;

    fetchGetDropDownData(
      "rcs-gateway/gatewaysForDropdown",
      setGatewayOptions,
      showSnackBar
    );

    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUserDropdowns.current = true;
  }, [user?.id]);

  const isEdit = rowData && Object.keys(rowData).length > 0;
  //   console.log(rowData);

  const initialValues = isEdit
    ? {
        ...rowData,
        user_ID: rowData?.user_ID || "",
        template_type:
          rowData?.template_type === "simple_txt"
            ? "Simple Text"
            : rowData?.template_type === "rich_card"
            ? "Rich Card/Carousel"
            : "",
        template_name: rowData?.template_name,
        is_variable: false,
        template_text: rowData?.template_text,
        bot_type: rowData?.bot_type,

        gateway_ID: rowData?.gateway_ID || "",
      }
    : {
        user_ID: "",
        template_type: "",
        template_name: "",
        template_text: "",
        bot_type: "",

        gateway_ID: "",
      };
  //   useEffect(() => {
  //     if (!user?.id || !isEdit || !rowData.user_ID || hasFetchedUserDropdowns.current) return;

  //     const payload = {};
  //     fetchPostDropDownData(
  //       `template-details/roleBasedUsers`,
  //       payload,
  //       setUsersData,
  //       showSnackBar
  //     );
  //     hasFetchedUserDropdowns.current = true;
  //   }, [isEdit, rowData.user_ID]);
  const validationSchema = object().shape({
    user_ID: string().required("User ID is required"),
    bot_type: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Bot Type is required"),

    template_type: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Template type is Required"),
    gateway_ID: string().required("Gateway Name is required"),

    is_variable: boolean()
      .oneOf([true], "Please check the Variable box")
      .required("This field is required"),

    template_name: string()
      .min(2, "Must be 2 characters or more ")
      .max(200, "Must be 200 characters or less")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Template name is Required"),
    // password: string()
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .required("Password is required"),

    template_text: string().required("Text is required"),
  });

  const handleSubmit = (payload) => {
    console.log("payload", payload);
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `rcs-template/update/${rowData.id}`
      : "rcs-template/store";

    const requestFunction = isUpdate ? putRequest : postRequest;
    const backendTemplateType =
      payload.template_type === "Simple Text" ? "simple_txt" : "rich_card";

    requestFunction(
      url,
      {
        ...payload,
        user_ID: payload?.user_ID,
        template_type: backendTemplateType,
        bot_type: payload?.bot_type?.toLowerCase() || "",
        is_variable: payload.is_variable ? 1 : 0,

        gateway_ID: payload.gateway_ID,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit RCS Gateway" : "Add RCS Gateway Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();

          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          //   console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="user_ID"
                    id="user_ID"
                    label="Select User *"
                    multiple={false}
                    options={usersData || []}
                    getOptionLabel={(option) => option?.username || ""}
                    value={
                      usersData?.find((type) => type?.id === values?.user_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      console.log("value =>", value);

                      setFieldValue("user_ID", value.id);
                      //   if(isEdit && rowData.user_ID) {
                      //     setFieldValue("user_ID", rowData.user_ID);
                      //   }
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 2.7 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="template_type"
                    id="template_type"
                    label="Template type*"
                    multiple={false}
                    options={templateType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      templateType?.find(
                        (type) => type === values?.template_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("template_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid item xs={12} sm={8} md={4}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={values?.is_variable === "true"}
                        onChange={(e) =>
                          setFieldValue(
                            "is_variable",
                            e.target.checked ? "true" : "false"
                          )
                        }
                        name="is_variable"
                        color="primary"
                        onBlur={handleBlur}
                      />
                    }
                    label="Variable"
                  />
                  {touched.is_variable && errors.is_variable && (
                    <Typography variant="caption" color="error">
                      {errors.is_variable}
                    </Typography>
                  )}
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="template_name"
                    id="template_name"
                    label="Template Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="template_text"
                    id="template_text"
                    label="Template Text *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* Dropdown */}
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="bot_type"
                    id="bot_type"
                    label="Select Bot Type *"
                    multiple={false}
                    options={BotType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      BotType?.find(
                        (type) =>
                          type.toLowerCase() === values?.bot_type?.toLowerCase()
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("bot_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="gateway_ID"
                    id="gateway_ID"
                    label="Select Gateway *"
                    multiple={false}
                    options={gatewayOptions || []}
                    getOptionLabel={(option) => option?.gateway_name || ""}
                    value={
                      gatewayOptions.find(
                        (opt) => opt.id === values.gateway_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("gateway_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditRcsTemplate;
