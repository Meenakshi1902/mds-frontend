import { createTheme } from '@mui/material';

const theme = createTheme({
    palette: {
        primary: {
          main: 'rgb(72 96 207)'
        },
        gray: {
          main: '#FF0000'
        },
        white: {
          main: '#FFFFFF'
        },
        blue: {
          main: '#71b8ff'
        }
      },
});

export default theme;