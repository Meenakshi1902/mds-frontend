import { getRequest, postRequest } from "../helpers/http.helper";

export const removeAuthUserFromStorage = () => {
  window.localStorage.removeItem("authToken");
};

export const validationRegex = {
  digit19Regex: /^\d{19}$/,
  senderIdRegex: /^[A-Za-z0-9]+$/, // letters or numbers only
  onlyLetters: /^[A-Za-z\s]+$/, // only letters accepted
  pincode: /^[0-9][0-9\- ]{0,10}[0-9]$/,
  numbersAndDecimalAllowed: /^\d+(\.\d{1,2})?$/, // Only numbers and up to 2 decimal places are allowed
  specialCharactersNotAllowed: /^[a-zA-Z0-9]*$/, // Special characters are not allowed
  // email: /^((?!\.)[\w\-_.]*[^.])(@\w+)(\.\w+(\.\w+)?[^.\W])$/gm,
  email: /^((?!\.)[\w\-_.]*[^.])(@[\w-]+)(\.\w+(\.\w+)?[^.\W])$/gm, // accepts hyphen now
  mobile: /^(\+\d{1,3}[- ]?)?\d{10,12}$/,
  direct: /^(\+\d{1,3}[- ]?)?\d{8}$/,
  stdcode: /^(?!\s|.*\s$)\d{1,3}$/,
  extension: /^(?!\s|.*\s$)(?!\s*$).+/,
  latitude: /^[-+]?(([1-8]?\d(\.\d+)?)|90(\.0+)?)$/,
  longitude: /^[-+]?((([1-9]?\d|1[0-7]\d)(\.\d+)?)|180(\.0+)?)$/,
  // url: /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi,
  url: /[-a-zA-Z0-9@:%_\+.~#?&//=]{1,256}\.[a-z]{1,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi,
  other: /^(?!\s|.*\s$)(?!\s*$).+/,
  description: /^(?!\s*$).+/,
  blankSpace: /^(?!\s*$).+/,
  blankSpacesMessage: "Input cannot be empty or contain only spaces",
  // filterLimitedAndCorporation: /^(?=.*\b(?:limited|corporation)\b).+$/,
  filterLimitedAndCorporation: /^(?!.*\b(limited|corporation|private)\b).*$/i,
  gstRegex: /^[A-Za-z0-9]{15}$/,
  // blankSpace: /^(?!\s*$).+/,
  // password: /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[^\s]{10,}$/,
  // password: /^(?=.*[A-Za-z])(?=.*\d)(?=.*[^A-Za-z\d])[A-Za-z\d\S]{8,10}$/,
  password: /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]+$/,
};

export const fetchGetDropDownData = (Url, setGetDropDownData, showSnackBar) => {
  getRequest(Url, function (response) {
    if (!response?.data?.errors) {
      const dropDownData = response?.data?.data || response?.data?.Gateways;
      setGetDropDownData(dropDownData);
    } else {
      // Handling error messages
      const errors = response?.data?.errors || {};

      if (typeof errors === "string") {
        showSnackBar("error", errors);
      } else if (typeof errors === "object") {
        const mappedErrors = Object.entries(errors).map(
          ([field, errorMessages]) => {
            return {
              field,
              message: errorMessages.join(", "),
            };
          }
        );

        mappedErrors.forEach(({ field, message }) => {
          showSnackBar("error", `${field}: ${message}`);
        });
      }
      setGetDropDownData([]);
    }
  });
};

export const fetchPostDropDownData = (
  Url,
  payload,
  setPostDropDownData,
  showSnackBar
) => {
  postRequest(Url, payload, function (response) {
    // console.log("response => ", response);
    if (!response?.data?.errors) {
      const dropDownData =
        response?.data?.usersData ||
        response?.data?.senders ||
        response?.data?.data;
      setPostDropDownData(dropDownData);
    } else {
      // Handling error messages
      const errors = response?.data?.errors || {};

      if (typeof errors === "string") {
        showSnackBar("error", errors);
      } else if (typeof errors === "object") {
        const mappedErrors = Object.entries(errors).map(
          ([field, errorMessages]) => {
            return {
              field,
              message: errorMessages.join(", "),
            };
          }
        );

        mappedErrors.forEach(({ field, message }) => {
          showSnackBar("error", `${field}: ${message}`);
        });
      }
      setPostDropDownData([]);
    }
  });
};

export const trimPayloadDeepOptimized = (payload) => {
  if (payload === null || typeof payload !== "object") return payload;

  if (Array.isArray(payload)) {
    for (let i = 0; i < payload.length; i++) {
      payload[i] = trimPayloadDeepOptimized(payload[i]);
    }
    return payload;
  }

  const result = {};
  for (const [key, value] of Object.entries(payload)) {
    result[key] =
      typeof value === "string"
        ? value.trim()
        : trimPayloadDeepOptimized(value);
  }
  return result;
};

export const setTokenToStorage = (token) => {
  window.localStorage.setItem("authToken", token);
};

export const getTokenFromStorage = () => {
  const token = window.localStorage.getItem("authToken");
  return token;
};

export const setEmailToStorage = (email) => {
  window.localStorage.setItem("email", email);
};

export const getEmailFromStorage = () => {
  const email = window.localStorage.getItem("email");
  return email;
};

export const transformMultipleIdForEdit = (Data) => {
  console.log("Data => ", Data);
  if (!Data || !Array.isArray(Data)) {
    return [];
  }

  return Data.map((item) => {
    // If it's already an object with id property, return as is
    if (typeof item === "object" && item !== null && item.id) {
      return item;
    }
    // If it's a primitive value, transform it to object format
    return { id: item };
  });
};

export const defaultSnackBarState = {
  show: false,
  type: "success",
  message: "",
  vertical: "bottom",
  horizontal: "center",
};

export const characterType = ["Text", "unicode"];
export const locateType = ["smsc", "otp"];
export const Status = ["Active", "Inactive"];
export const gatewayType = ["Direct", "In-Direct"];
export const senderID = ["Yes", "No"];
export const DndData = ["Enable", "Disable"];
export const TmtData = ["Direct", "In-Direct"];
export const roleData = [
  { id: "1", label: "User" },
  { id: "2", label: "Reseller" },
  { id: "3", label: "Admin" },
  { id: "4", label: "SuperAdmin" },
];
export const method = ["Numbers", "Groups", "CSV"];
export const messageType = ["Text", "Unicode"];
