import { Box } from "@mui/material";
import { DatePicker } from "@mui/x-date-pickers";

const CustomDatePicker = ({
  icon: IconComponent,
  id,
  name,
  label,
  value,
  format,
  adapter,
  disabled = false,
  sx,
  disablePast = false,
  disableFuture = false,
  open,
  onClose,
  onChange,
  iconBgColor = "#A780FF",
  iconColor = "white",
  slotProps = {},
}) => {
  return (
    <Box>
      <Box
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Box
          sx={{
            backgroundColor: iconBgColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "8px",
            borderRadius: "4px 0 0 4px",
            border: "1px solid #e0e0e0",
            borderRight: "none",
            height: "40px",
          }}
        >
          <IconComponent sx={{ color: iconColor, fontSize: "20px" }} />
        </Box>
        <DatePicker
          id={id}
          name={name}
          label={label}
          value={value}
          format={format}
          adapter={adapter}
          disabled={disabled}
          sx={sx}
          disablePast={disablePast}
          disableFuture={disableFuture}
          open={open}
          onClose={onClose}
          // onChange={onChange}
          onChange={(newValue) => {
            const formattedValue = newValue
              ? newValue?.format("YYYY-MM-DD")
              : "";
            onChange(formattedValue);
          }}
          slotProps={{
            openPickerButton: {
              tabIndex: -1,
              disabled: true,
            },
            actionBar: {
              actions: ["clear"],
            },
            textField: {
              ...(slotProps.textField || {}),
              name,
              id,
              onClick: disabled ? null : slotProps?.textField?.onClick,
              onKeyDown: (e) => {
                if (slotProps?.textField?.onKeyDown) {
                  slotProps?.textField.onKeyDown(e);
                }
                // if (e.code.startsWith('Digit') || e.code === 'Enter') open(true);
                if (e.code === "Backspace") {
                  e.preventDefault();
                  // setFieldValue(name, '');
                  onChange("");
                }
              },

              size: "small",
              readOnly: !value,
              clearable: true,
            },
          }}
        />
      </Box>
    </Box>
  );
};

export default CustomDatePicker;
