import {
  Box,
  Button,
  IconButton,
  InputAdornment,
  TextField,
  Typography,
  Checkbox,
  FormControlLabel,
  // CircularProgress,
} from "@mui/material";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { string, object } from "yup";
import { useState } from "react";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, Link } from "react-router";
import { login } from "../../features/auth/authSlice";
import { defaultSnackBarState } from "../../utils/common";
import SnackbarAlert from "../../components/SnackBarMessage/SnackbarAlert";
import LoginRightSideImg from "../../assets/Images/LoginRighSideImg.png";
import { postRequest } from "../../helpers/http.helper";
import { setTokenToStorage } from "../../utils/common";
import mdslogo from "../../assets/logos/mdslogo.png";
// import ForgotPassword from "./ForgotPassword";
// import ResetPassword from "./ResetPassword";

const Login = () => {
  // const userData = useSelector((state) => state.auth.user);
  // const usertoken = useSelector((state) => state.auth.token);

  // console.log("userData => ", userData);
  // console.log(" userData usertoken => ", usertoken);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [showPassword, setShowPassword] = useState(false);
  // const [currentView, setCurrentView] = useState("login"); // login, forgotPassword, resetPassword
  // const [resetEmail, setResetEmail] = useState("");

  const loginSchema = object().shape({
    userName: string()
      .required("Enter Your Username")
      .test(
        "is-valid-username-or-email",
        "Enter a valid email or username",
        (value) =>
          !!value &&
          (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ||
            /^[a-zA-Z0-9._-]{3,}$/.test(value))
      ),
    password: string().required("Enter Your Password"),
  });

  const initialValue = {
    userName: "",
    password: "",
    rememberMe: false,
  };

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const showSnackBar = (type, message) => {
    // console.log("type => ", type, message);
    setSnackbarState({
      show: true,
      type,
      message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 5000);
  };

  const handleLogin = (formData, props) => {
    const payload = {
      username: formData.userName,
      password: formData.password,
    };

    postRequest("login", payload, function (res) {
      if (res?.data?.error) {
        showSnackBar("error", res?.data?.error);
        props.setSubmitting(false);
        // props.resetForm();
        return;
      }
      // console.log("res?.data?.token => ", res?.data?.token);
      showSnackBar("success", res?.data?.message);
      setTokenToStorage(res?.data?.token);
      dispatch(login(res?.data));
      // Save user and token to localStorage
      navigate("/dashboard");
      localStorage.setItem("authInfo", JSON.stringify(res?.data));
      props.resetForm();
      props.setSubmitting(false);
    });
  };

  // const handleForgotPasswordClick = () => {
  //   setCurrentView("forgotPassword");
  // };

  // const handleResetPassword = (email) => {
  //   setResetEmail(email);
  //   setCurrentView("resetPassword");
  // };

  // const handleBackToLogin = () => {
  //   setCurrentView("login");
  //   setResetEmail("");
  // };

  // const handleBackToForgotPassword = () => {
  //   setCurrentView("forgotPassword");
  // };

  // // Render different views based on currentView state
  // if (currentView === "forgotPassword") {
  //   return (
  //     <ForgotPassword
  //       onResetPassword={handleResetPassword}
  //       onBackToLogin={handleBackToLogin}
  //     />
  //   );
  // }

  // if (currentView === "resetPassword") {
  //   return (
  //     <ResetPassword
  //       email={resetEmail}
  //       onBackToLogin={handleBackToLogin}
  //       onBackToForgotPassword={handleBackToForgotPassword}
  //     />
  //   );
  // }

  // Default login view
  return (
    <Box
      display="flex"
      height="100vh"
      alignItems="center"
      justifyContent="center"
      sx={{ overflow: "hidden" }}
    >
      {/* Main Content Wrapper */}
      <Box
        display="flex"
        flexDirection="row"
        alignItems="center"
        backgroundColor="#F2F2F2"
      >
        <Box>
          {/* Logo */}
          {/* <Typography variant="h5" mb={2} textAlign="center">
            Logo Name
          </Typography> */}
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              marginLeft: "95px",
            }}
          >
            <img
              src={mdslogo}
              alt="logo"
              style={{
                maxWidth: "100%",
                height: "40px",
                objectFit: "contain",
              }}
            />
          </Box>

          {/* Login Form */}
          <Box
            maxWidth="500px"
            width="100%"
            sx={{
              bgcolor: "#ffffff",
              borderRadius: 2,
              boxShadow: 2,
              p: 4,
              m: 4,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
          >
            <Formik
              initialValues={initialValue}
              validationSchema={loginSchema}
              onSubmit={handleLogin}
              enableReinitialize
            >
              {(props) => {
                const { isSubmitting, dirty, isValid, errors } = props;
                // console.log("formconditions => ", isSubmitting, dirty, isValid, errors);
                // const { userName, password} = props.values;
                // console.log("userForm => ", userName, password);
                return (
                  <Form style={{ width: "100%" }}>
                    <Typography variant="h6" mb={3} color="primary">
                      Account Login
                    </Typography>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="UserName*"
                        name="userName"
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="userName" />}
                        error={
                          Boolean(props.errors.userName) &&
                          props.touched.userName
                        }
                      />
                    </Box>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Password*"
                        name="password"
                        type={showPassword ? "text" : "password"}
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="password" />}
                        error={
                          Boolean(props.errors.password) &&
                          props.touched.password
                        }
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <IconButton
                                onClick={() => setShowPassword(!showPassword)}
                                onMouseDown={(e) => e.preventDefault()}
                              >
                                {showPassword ? (
                                  <Visibility />
                                ) : (
                                  <VisibilityOff />
                                )}
                              </IconButton>
                            </InputAdornment>
                          ),
                        }}
                      />
                    </Box>

                    <Box
                      display="flex"
                      justifyContent="space-between"
                      alignItems="center"
                      mb={2}
                    >
                      <FormControlLabel
                        control={
                          <Field
                            as={Checkbox}
                            name="rememberMe"
                            color="primary"
                          />
                        }
                        label="Remember me"
                      />
                      <Button
                        variant="text"
                        onClick={() => navigate("/forgot-password")}
                        sx={{
                          textTransform: "none",
                          color: "primary.main",
                          "&:hover": {
                            backgroundColor: "rgba(0, 0, 0, 0.04)",
                          },
                        }}
                      >
                        Forgot Password?
                      </Button>
                    </Box>

                    <Button
                      type="submit"
                      variant="contained"
                      fullWidth
                      sx={{
                        bgcolor: "blue",
                        color: "white !important",
                        py: 1.5,
                        "&:hover": {
                          bgcolor: "#5459AC",
                        },
                        borderRadius: 2,
                        boxShadow: 2,
                      }}
                      disabled={!dirty || !isValid}
                    >
                      Log in
                    </Button>
                    {/* {isSubmitting && <CircularProgress size={24} />} */}

                    {snackbarState?.show && (
                      <SnackbarAlert
                        open={snackbarState?.show}
                        message={snackbarState?.message}
                        severity={snackbarState?.type}
                        vertical={snackbarState?.vertical}
                        horizontal={snackbarState?.horizontal}
                      />
                    )}
                  </Form>
                );
              }}
            </Formik>
          </Box>
          <Box sx={{ ml: 12, mt: 4, textAlign: "center" }}>
            <Typography variant="body1" gutterBottom color="primary">
              Don't have an account?
            </Typography>

            {/* Get Started Button */}
            <Button
              onClick={() => navigate("/register")}
              style={{
                display: "block",
                marginBottom: 8,
                marginLeft: 64,
                textDecoration: "underline",
                textTransform: "none", // Prevent uppercase
              }}
            >
              Get Started
            </Button>

            <Typography variant="body2">
              Read our{" "}
              <Link
                to="/#"
                color="primary"
                style={{ textDecoration: "underline" }}
              >
                Terms
              </Link>{" "}
              and{" "}
              <Link
                to="/#"
                color="primary"
                style={{ textDecoration: "underline" }}
              >
                Conditions
              </Link>
            </Typography>
          </Box>
        </Box>

        {/* Right Side Image */}
        <Box
          flex={1}
          display="flex"
          justifyContent="center"
          alignItems="center"
          sx={{ px: 4, ml: { xs: 0, sm: 6, md: 12 } }} // Adjusts margin-left responsively
        >
          <img
            src={LoginRightSideImg}
            alt="MDS Right Side Image"
            style={{ maxWidth: "100vw", height: "auto" }}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default Login;
