import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { fetchPostDropDownData, validationRegex } from "../../../utils/common";
import { postRequest, putRequest } from "../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../components/IconAutocompleteField/IconAutocompleteField";

const AddEditSenderDetails = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const [usersData, setUsersData] = useState([]);
  const hasFetchedUsersDropdowns = useRef(false);

  const user = useSelector((state) => state?.auth?.user);

  const shouldIncludeUserId = [2, 3, 4].includes(user?.role_ID);

  useEffect(() => {
    if (user?.role_ID === 1 || hasFetchedUsersDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        ...(shouldIncludeUserId && {
          user_ID: rowData.user_ID || "",
        }),
        sender_ID: rowData.sender_ID || "",
        principle_entity_ID: rowData.principle_entity_ID || "",
        header_ID: rowData.header_ID || "",
        description: rowData.description || "",
      }
    : {
        ...(shouldIncludeUserId && {
          user_ID: "",
        }),
        sender_ID: "",
        principle_entity_ID: "",
        header_ID: "",
        description: "",
      };

  const validationSchema = object().shape({
    sender_ID: string()
      .max(6, "The sender ID field must not be greater than 6 characters")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(validationRegex?.onlyLetters, "sender must contain only letters")
      .required("sender is required"),
    principle_entity_ID: string()
      .required("The principle entity ID field is required")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(
        validationRegex?.digit19Regex,
        "The PEID must contain exactly 19 digits"
      ),

    header_ID: string()
      .matches(/^\d{19}$/, "The header ID must contain exactly 19 digits")
      .required("header is required"),

    description: string()
      .typeError("The description field must be a string")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("description is required"),
    // user_ID: string().required("User ID is required"),
    user_ID: string().when([], {
      is: () => shouldIncludeUserId,
      then: (schema) => schema.required("User ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
  });

  const handleSubmit = (payload) => {
    // console.log("rowdata inside => ", rowData);
    // console.log("payload => ", payload);

    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `sender-details/update/${rowData.id}`
      : "sender-details/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        ...(shouldIncludeUserId && {
          user_ID: payload.user_ID || user?.id,
        }),

        ...(user?.role_ID === 1 &&
          user?.id && {
            user_ID: user?.id,
          }),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Sender Details" : "Create Sender Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="sender_ID"
                    id="sender_ID"
                    label="Sender ID/ Header Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="principle_entity_ID"
                    id="principle_entity_ID"
                    label="principle entity ID (PE ID) *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="header_ID"
                    id="header_ID"
                    label="header ID *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="description"
                    id="description"
                    label="Description *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {shouldIncludeUserId && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconAutocompleteField
                      icon={PersonIcon}
                      name="user_ID"
                      id="user_ID"
                      label="Select User *"
                      multiple={false}
                      options={usersData || []}
                      getOptionLabel={(option) => option?.username || ""}
                      value={
                        usersData?.find(
                          (type) => type?.id === values?.user_ID
                        ) || null
                      }
                      isOptionEqualToValue={(option, value) =>
                        option?.id === value?.id
                      }
                      onChange={(e, value) => {
                        setFieldValue("user_ID", value?.id || "");
                      }}
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                )}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditSenderDetails;
