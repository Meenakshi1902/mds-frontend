import React from "react";
import { Formik } from "formik";
import {
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import * as Yup from "yup";
import { validationRegex } from "../../../../utils/common";
import { useNavigate } from "react-router";

const ChangePassword = ({
  setRefreshTable,
  // rowData,
  showSnackBar,
  closeModal,
}) => {
  const navigate = useNavigate();
  // const isEdit = rowData && Object.keys(rowData).length > 0;

  // const initialValues = isEdit
  //   ? {
  //       ...rowData,
  //       current_password: 200,
  //       new_password: "admin@123",
  //       confirm_new_password: "admin@123",
  //     }
  //   : {
  //       current_password: "",
  //       new_password: "",
  //       confirm_new_password: "",
  //     };
  const initialValues = {
    current_password: "",
    new_password: "",
    confirm_new_password: "",
  };

  const validationSchema = Yup.object().shape({
    //   p_name: string()
    //     .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //     .required("Plan Name is required"),
    current_password: Yup.string().required("Current Password is required"),
    new_password: Yup.string()
      .required("New Password is required")
      .min(8, "Password must be at least 8 characters")
      .max(10, "Password cannot be more than 10 characters"),
    confirm_new_password: Yup.string()
      .required("Confirm Password is required")
      .oneOf([Yup.ref("new_password"), null], "Passwords must match"),
  });

  const handleSubmit = (payload, resetForm) => {
    //   const isUpdate = !!rowData?.id;
    //   const url = isUpdate ? `plans/update/${rowData.id}` : "plans/store?";

    //   const requestFunction = isUpdate ? putRequest : postRequest;

    putRequest(
      `user-setting/updatePassword`,
      {
        ...payload,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          // setRefreshTable(true);
          showSnackBar("success", response.data.message);
          resetForm();
          navigate("/login");
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography
        variant="h5"
        sx={{ fontWeight: "semibold", fontSize: "1rem", color: "green" }}
      >
        {/* {isEdit ? "Edit Plan Details" : "Create Plan Details"} */}
        *Note: The length of a password should be no more than ten characters.
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          resetForm,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "1rem",
                  width: "300px",
                }}
              >
                <Box>
                  <IconInputField
                    icon={PersonIcon}
                    name="current_password"
                    id="current_password"
                    label="Old Password *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Box>

                <Box>
                  <IconInputField
                    icon={PersonIcon}
                    name="new_password"
                    id="new_password"
                    label="New Password *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Box>

                <Box>
                  <IconInputField
                    icon={PersonIcon}
                    name="confirm_new_password"
                    id="confirm_new_password"
                    label="Re-Enter Password *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Box>
              </Box>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values, resetForm)}
                  disabled={!dirty || !isValid}
                >
                  Update
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default ChangePassword;
