import React from 'react'

function ManageVoiceGatewayDetails() {
  return (
    <div>
      ManageVoiceGatewayDetails
    </div>
  )
}

export default ManageVoiceGatewayDetails
