import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  FormHelperText,
  IconButton,
} from "@mui/material";
import { array, mixed, object, string } from "yup";
import { validationRegex } from "../../../utils/common";
import {
  getRequest,
  postRequest,
  putRequest,
} from "../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import CheckboxInputAutocompleteField from "../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

const GroupWithContacts = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const [groupAutocompleteOpen, setGroupAutocompleteOpen] = useState(false);
  const documentFileRef = React.useRef();
  const hasFetchedGroupName = useRef(false);
  const [groupUserData, setGroupUserData] = useState([]);

  const user = useSelector((state) => state?.auth?.user);

  // console.log("user => ", user?.id);

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        // user_ID: rowData.user_ID || "",
        group_ID: rowData.group_ID || "",
        fileAttachment: null,
      }
    : {
        group_ID: "",
        fileAttachment: null,
      };

  const validationSchema = object().shape({
    group_ID: array()
      .of(
        object({
          id: mixed().required("group ID is required"),
        })
      )
      // .min(1, "Select at least one Sender ID")
      .required("Sender ID is required"),

    fileAttachment: mixed()
      .required("Only csv format files are allowed to import")
      .test(
        "fileType",
        "Only csv format files are allowed to import",
        function (value) {
          if (value && value instanceof File) {
            const validTypes = ["text/csv"];
            return validTypes.includes(value.type);
          }
          return true;
        }
      )
      .test("fileSize", "File size must be less than 2 MB", function (value) {
        if (value && value instanceof File) {
          return value.size <= 2097152;
        }
        return true;
      }),
  });

  const fetchGroupNameDropDownData = () => {
    // setIsLoading(true);
    getRequest("contact-details/getGroupForUser", function (response) {
      // console.log("response", response?.data?.data);
      if (!response?.data?.errors) {
        setGroupUserData(response?.data?.data);
      } else {
        // Handling error messages
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          // Optionally display errors in a snack bar or UI
          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
        setGroupUserData([]);
      }
    });
  };

  useEffect(() => {
    if (hasFetchedGroupName.current) return;
    fetchGroupNameDropDownData();
    hasFetchedGroupName.current = true;
  }, []);

  const handleSubmit = (payload) => {
    // console.log("rowdata inside => ", rowData);
    // console.log("payload => ", payload);

    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `sender-details/update/${rowData.id}`
      : "sender-details/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        user_ID: user?.id || rowData.user_ID,
        // sender_ID: rowData?.sender_ID, // Only add if needed
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {/* {isEdit ? "Edit Group With Contacts" : "Create New Group With Contacts"} */}
        In Progress, plz Don't Test
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }} mt={3}>
                  <CheckboxInputAutocompleteField
                    icon={PersonIcon}
                    id="group_ID"
                    name="group_ID"
                    label="Select Group *"
                    options={groupUserData || []}
                    getOptionLabel={(option) => option?.group_name}
                    getOptionValue={(option) => option?.id} // How to get the ID value
                    getDisplayValue={(option) => option?.group_name} // What to display in checkbox list
                    value={values?.group_ID}
                    setFieldValue={setFieldValue}
                    handleBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    autoCompleteOpen={groupAutocompleteOpen}
                    setAutoCompleteOpen={setGroupAutocompleteOpen}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Typography>Import Numbers :</Typography>
                  {values?.fileAttachment === null ? (
                    <Box>
                      <Button
                        name="fileAttachment"
                        id="fileAttachment"
                        variant="outlined"
                        fullWidth
                        startIcon={<CloudUploadIcon />}
                        // onClick={() => documentFileRef.current.click()}
                        onClick={() => {
                          documentFileRef.current.click();
                          // Mark the field as touched when clicking the upload button
                          // setFieldTouched('fileAttachment', true);
                        }}
                        sx={{
                          color: "#181C32",
                          // borderColor: '#181C32',
                          borderColor:
                            errors?.fileAttachment && touched?.fileAttachment
                              ? "error.main"
                              : "#181C32",
                          "&:hover": {
                            color: "#FFFFFF",
                            backgroundColor: "#A780FF",
                          },
                        }}
                        onBlur={handleBlur}
                      >
                        Upload File*
                        <VisuallyHiddenInput type="file" />
                      </Button>
                      <input
                        ref={documentFileRef}
                        accept="text/csv"
                        // accept=".doc,.docx,.pdf"
                        type="file"
                        name="fileAttachment"
                        id="fileAttachment"
                        style={{ display: "none" }}
                        // onChange={(e) => setFieldValue('fileAttachment', e.target.files[0])}
                        // onChange={(e) => {
                        //   setFieldValue('fileAttachment', e.target.files[0]);
                        //   setFieldTouched('fileAttachment', true);
                        // }}
                        onChange={(e) => {
                          const file = e.target.files[0];
                          // console.log('file => ', file);
                          //   const validTypes = ["image/jpeg", "image/png"];
                          const validTypes = ["text/csv"];
                          const isFileValid =
                            validTypes.includes(file.type) ||
                            file.name.endsWith(".csv");
                          if (file && isFileValid) {
                            setFieldValue("fileAttachment", file);
                            showSnackBar(
                              "success",
                              "File Uploaded Successfully"
                            );
                            // setFieldTouched('fileAttachment', true);
                          } else if (file.size > 2097152) {
                            // 2 MB limit
                            setFieldError(
                              "fileAttachment",
                              "File size must be less than 2 MB"
                            );
                            e.target.value = ""; // Reset the input
                          } else {
                            setFieldValue("fileAttachment", null);
                            showSnackBar("error", "Invalid File Format");
                          }
                        }}
                        onBlur={handleBlur}
                      />
                      {/* <FormHelperText
                        sx={{
                          color: '#d32f2f',
                          fontweight: 400
                        }}>
                        Supported formats: JPG, PNG
                      </FormHelperText> */}
                      {/* {errors?.fileAttachment && touched?.fileAttachment && (
                        <FormHelperText error>{errors?.fileAttachment}</FormHelperText>
                      )} */}
                    </Box>
                  ) : (
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <Typography
                        sx={{
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          maxWidth: "fit-content",
                        }}
                      >
                        Uploaded File:&nbsp;&nbsp;
                        {typeof values.fileAttachment == "object"
                          ? values.fileAttachment.name
                          : rowData?.fileAttachmentName}
                      </Typography>
                      <IconButton
                        onClick={() => setFieldValue("fileAttachment", null)}
                      >
                        <CloseIcon />
                      </IconButton>
                    </Box>
                  )}
                  {errors?.fileAttachment && touched?.fileAttachment && (
                    <FormHelperText error>
                      {errors?.fileAttachment}
                    </FormHelperText>
                  )}
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={isSubmitting || !dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default GroupWithContacts;
