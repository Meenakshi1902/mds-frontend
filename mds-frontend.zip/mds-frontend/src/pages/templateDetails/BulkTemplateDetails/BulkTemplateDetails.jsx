import React from 'react'

function BulkTemplateDetails() {
  return (
    <div>
      BulkTemplateDetails
    </div>
  )
}

export default BulkTemplateDetails
