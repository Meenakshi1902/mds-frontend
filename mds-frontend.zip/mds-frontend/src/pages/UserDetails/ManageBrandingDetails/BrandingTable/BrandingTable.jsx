import React, { useEffect, useMemo, useState } from "react";
import EditIcon from "@mui/icons-material/Edit";
import AddIcon from "@mui/icons-material/Add";
import { deleteRequest, postRequest } from "../../../../helpers/http.helper";
import Table from "../../../../components/Table/Table";
import moment from "moment";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from "@mui/material";

const BrandingTable = ({
  openModal,
  setSelectedRowData,
  refreshTable,
  setRefreshTable,
  rowData,
  showSnackBar,
}) => {
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [rowCount, setRowCount] = useState(0);
  const [rowSelection, setRowSelection] = useState({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [debouncedGlobalFilter, setDebouncedGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [isDelete, setIsDelete] = useState(false);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });

  const handleDeleteClick = (row) => {
    setIsDelete(true);
    setSelectedRowData(row);
  };

  const handleClose = () => {
    setIsDelete(false);
    setSelectedRowData([]);
  };

  const deleteRecord = () => {
    // Make the API request
    deleteRequest(`branding/delete/${rowData?.id}`, {}, (res) => {
      if (res?.data?.errors) {
        showSnackBar("error", res?.data?.errors);
      } else {
        showSnackBar("success", res?.data?.message);
      }
      // Refresh table and close the modal
      handleClose();
      setRefreshTable(true);
    });
  };

  const fetchData = () => {
    setIsLoading(true);
    postRequest(
      "branding",
      {
        start: pagination.pageIndex * pagination.pageSize + 1,
        limit: pagination.pageSize,
        search_text: globalFilter || "",
        sorting: sorting.length > 0 ? sorting?.[0]?.id : "created_at",
        order_by:
          sorting.length > 0 ? (sorting?.[0]?.desc ? "desc" : "asc") : "desc",
      },
      function (response) {
        if (!response?.data?.errors && response?.data?.data) {
          setData(response?.data?.data);
          setRowCount(response?.data?.total_count || 0);
          setIsLoading(false);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
          setData([]);
          setRowCount(response?.data?.total_count || 0);
          setIsLoading(false);
        }
      }
    );
  };

  const columns = useMemo(() => [
    {
      accessorKey: "SRNO",
      header: "Sr No.",
      size: 100,
      enableSorting: false,
      Cell: ({ cell }) => {
        return <>{cell.row.index + 1}</>;
      },
    },
    {
      accessorKey: "company_name",
      header: "Company Name",
      size: 100,
    },
    {
      accessorKey: "company_tagline",
      header: "Tagline",
      size: 100,
    },
    {
      accessorKey: "website_address",
      header: "Website Address",
      size: 100,
    },
    {
      accessorKey: "support_url",
      header: "Support URL",
      size: 100,
    },
    {
      accessorKey: "support_mobile",
      header: "Support Mobile",
      size: 100,
    },
    {
      accessorKey: "support_email",
      header: "Support E-maill",
      size: 100,
    },
    {
      accessorKey: "login_page_description",
      header: "Login Page Desc",
      size: 100,
    },
    {
      accessorKey: "isActive",
      header: "Status",
      size: 100,
      Cell: ({ row }) => {
        const status = row?.original?.isActive;

        if (status === true || status === 1) {
          return "Active";
        } else if (status === false || status === 0) {
          return "Inactive";
        } else {
          return "-";
        }
      },
    },
    // {
    //   accessorKey: "created_at",
    //   header: "Create Date",
    //   size: 100,
    //   Cell: ({ row }) => {
    //     return (
    //       <>
    //         {row?.original?.created_at
    //           ? moment(row?.original?.created_at?.split("T")[0]).format(
    //               "DD/MM/YYYY"
    //             )
    //           : null}
    //       </>
    //     );
    //   },
    // },
  ]);

  useEffect(() => {
    fetchData();
  }, [pagination.pageIndex, pagination.pageSize, sorting, globalFilter]);

  useEffect(() => {
    if (refreshTable) {
      fetchData();
      setRefreshTable(false);
    }
  }, [refreshTable]);

  const toolbarButtons = [
    {
      variant: "customcreate",
      sx: {
        textTransform: "none",
        backgroundColor: "#1976d2",
        color: "#ffffff",
        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
        borderRadius: "8px",
        "&:hover": {
          backgroundColor: "#4DA8DA",
        },
      },
      color: "primary",
      startIcon: <AddIcon />,
      onClick: () => openModal("brandingmodal"),
      label: "Add Branding",
    },
  ];

  const rowActionItems = [
    {
      icon: <EditIcon />,
      label: "Edit",
      onClick: (row) => {
        setSelectedRowData(row);
        openModal("brandingmodal");
      },
    },
    {
      icon: <DeleteIcon />,
      label: "Delete",
      onClick: (row) => {
        handleDeleteClick(row);
      },
    },
  ];

  useEffect(() => {
    const handler = setTimeout(() => {
      setGlobalFilter(debouncedGlobalFilter);
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [debouncedGlobalFilter]);

  const states = {
    enableRowSelection: false,
    manualSorting: true,
    // enableRowActions: !viewMode,
    manualFiltering: true,
  };

  return (
    <>
      <Table
        columns={columns}
        data={data}
        isLoading={isLoading}
        rowSelection={rowSelection}
        setRowSelection={setRowSelection}
        globalFilter={debouncedGlobalFilter}
        setGlobalFilter={setDebouncedGlobalFilter}
        sorting={sorting}
        setSorting={setSorting}
        pagination={pagination}
        setPagination={setPagination}
        rowCount={rowCount}
        // toolbarButtons={!viewMode && toolbarButtons}
        toolbarButtons={toolbarButtons}
        rowActionItems={rowActionItems}
        states={states}
      />

      <Dialog
        open={isDelete}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" sx={{ fontWeight: "bold" }}>
          <DeleteIcon sx={{ position: "relative", top: "4px" }} />
          Delete
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to delete this record?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button variant="customhover" color="gray" onClick={handleClose}>
            Discard
          </Button>
          <Button
            variant="customwarning"
            color="#eb071e"
            onClick={deleteRecord}
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default BrandingTable;
