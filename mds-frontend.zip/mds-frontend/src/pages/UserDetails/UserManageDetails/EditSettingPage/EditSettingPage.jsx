import React, { useState } from "react";
import { Box, Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../../../utils/common";
import SnackbarAlert from "../../../../components/SnackBarMessage/SnackbarAlert";
import PlanForm from "../EditSettingPage/PlanForm/PlanForm";
import AddCutOffForm from "../EditSettingPage/AddCutOffForm/AddCutOffForm";
import EditCutOffForm from "../EditSettingPage/EditCutOffForm/EditCutOffForm";
import CutOffDetailsTable from "../EditSettingPage/CutOffDetailsTable/CutOffDetailsTable";
import ModalComponent from "../../../../components/ModalComponent/ModalComponent";

const EditSettingPage = ({ rowData }) => {
  // console.log("UserData From useR Table => ", rowData);
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [selectedCutOffRowData, setSelectedCutOffRowData] = useState({});
  const [refreshCutOffTable, setRefreshCutOffTable] = useState(false);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      setSelectedCutOffRowData([]);
    }
  };

  const openModal = (type) => {
    setEnableAddForm(type);
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "top",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      <Box
        sx={{
          maxHeight: "100vh",
          overflowY: "auto",
          px: 2,
          py: 2,
        }}
      >
        <Typography sx={{ fontSize: "1.5rem", fontWeight: "bold" }}>
          Settings
        </Typography>
        <PlanForm
          userRowData={rowData}
          showSnackBar={showSnackBar}
          setRefreshCutOffTable={setRefreshCutOffTable}
        />

        <AddCutOffForm
          userRowData={rowData}
          showSnackBar={showSnackBar}
          setRefreshCutOffTable={setRefreshCutOffTable}
        />

        <ModalComponent
          style={style}
          closeModal={closeModal}
          enableAddForm={enableAddForm}
        >
          {enableAddForm && enableAddForm === "cutoffmodal" && (
            <EditCutOffForm
              selectedCutOffRowData={selectedCutOffRowData}
              showSnackBar={showSnackBar}
              closeModal={closeModal}
              setRefreshCutOffTable={setRefreshCutOffTable}
              userRowData={rowData}
            />
          )}
        </ModalComponent>

        <Box px={2} pb={2}>
          {snackbarState?.show && (
            <SnackbarAlert
              open={snackbarState?.show}
              message={snackbarState?.message}
              severity={snackbarState?.type}
              vertical={snackbarState?.vertical}
              horizontal={snackbarState?.horizontal}
            />
          )}
          <Grid>
            <Box sx={{ mt: "10px" }}>
              <CutOffDetailsTable
                selectedCutOffRowData={selectedCutOffRowData}
                setSelectedCutOffRowData={setSelectedCutOffRowData}
                openModal={openModal}
                showSnackBar={showSnackBar}
                refreshCutOffTable={refreshCutOffTable}
                setRefreshCutOffTable={setRefreshCutOffTable}
              />
            </Box>
          </Grid>
        </Box>
      </Box>
    </>
  );
};

export default EditSettingPage;
