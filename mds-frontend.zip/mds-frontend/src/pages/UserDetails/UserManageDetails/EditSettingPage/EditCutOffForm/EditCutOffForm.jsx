import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { putRequest } from "../../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../../components/IconInputField/IconInputField";
import {
  fetchPostDropDownData,
  validationRegex,
} from "../../../../../utils/common";
import IconAutocompleteField from "../../../../../components/IconAutocompleteField/IconAutocompleteField";
import { useSelector } from "react-redux";

const EditCutOffForm = ({
  userRowData,
  selectedCutOffRowData,
  showSnackBar,
  closeModal,
  setRefreshCutOffTable,
}) => {
  // console.log(
  //   "selectedCutOffRowData?.cutoff_route_ID => ",
  //   selectedCutOffRowData?.cutoff_route_ID
  // );
  const user = useSelector((state) => state?.auth?.user);
  const [userAssignRouteDropdown, setUserAssignRouteDropdown] = useState([]);
  const hasFetchedRoutesDropdowns = useRef(false);

  const initialValues = {
    ...selectedCutOffRowData,
    cutoff_route_ID: selectedCutOffRowData?.cutoff_route_ID || "",
    throughput: selectedCutOffRowData?.throughput || "",
    min_cut_value: selectedCutOffRowData?.min_cut_value || "",
  };

  const validationSchema = object().shape({
    cutoff_route_ID: string().required("Cutoff Route ID is required"),
    throughput: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Throughput is required"),
    // min_cut_value: string()
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .required("Min Cut Value is required"),
    min_cut_value: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Min Cut Value is required")
      .test("min-cut-check", "Min Cut Value must be at least 1000", (value) => {
        if (!value) return false;
        const num = Number(value);
        return !isNaN(num) && num >= 1000;
      }),
  });

  useEffect(() => {
    if (!user?.id || hasFetchedRoutesDropdowns.current) return;
    const payload = {
      user_id: userRowData?.id || "",
    };
    fetchPostDropDownData(
      `user-assigned-routes`,
      payload,
      setUserAssignRouteDropdown,
      showSnackBar
    );
    hasFetchedRoutesDropdowns.current = true;
  }, [user?.id]);

  const handleSubmit = (payload) => {
    putRequest(
      `cutoff-details/update/${selectedCutOffRowData.id}`,
      {
        ...payload,
        user_ID: String(userRowData?.id) || "",
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshCutOffTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">Edit Cut Off Details</Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="cutoff_route_ID"
                    id="cutoff_route_ID"
                    label="Select Route *"
                    multiple={false}
                    options={userAssignRouteDropdown || []}
                    getOptionLabel={(option) => option?.route_name || ""}
                    value={
                      userAssignRouteDropdown?.find(
                        (type) => type?.id === values?.cutoff_route_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("cutoff_route_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="route_ID"
                    id="route_ID"
                    label="Cutt-Off Status *"
                    multiple={false}
                    options={routeDropdown || []}
                    getOptionLabel={(option) => option?.route_name || ""}
                    value={
                      routeDropdown?.find(
                        (type) => type?.id === values?.route_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("route_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid> */}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="throughput"
                    id="throughput"
                    label="Cutting Throughput *"
                    placeholder={"eg. 50-60"}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="min_cut_value"
                    id="min_cut_value"
                    label="Cutting Min Value *"
                    placeholder={"eg. 1000"}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default EditCutOffForm;
