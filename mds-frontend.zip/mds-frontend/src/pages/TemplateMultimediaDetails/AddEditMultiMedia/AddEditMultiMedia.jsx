import React, { use, useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  IconButton,
  CircularProgress,
  Switch,
  TextareaAutosize,
  FormHelperText,
} from "@mui/material";
import PersonIcon from "@mui/icons-material/Person";
// import { mixed, object, string } from "yup";
import { postDocumentRequest } from "../../../helpers/http.helper";
import { useSelector } from "react-redux";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import IconAutocompleteField from "../../../components/IconAutocompleteField/IconAutocompleteField";
import { fetchPostDropDownData, validationRegex } from "../../../utils/common";
import * as Yup from "yup";

const AddEditMultiMedia = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const [usersData, setUsersData] = useState([]);
  const [templateDropdown, setTemplateDropdown] = useState([]);
  const [senders, setSenders] = useState([]);
  const [userAssignRouteDropdown, setUserAssignRouteDropdown] = useState([]);
  const hasFetchedUsersDropdowns = useRef(false);
  const hasFetchedTemplatesDropdowns = useRef(false);
  const hasFetchedSendersDropdowns = useRef(false);
  const hasFetchedRoutesDropdowns = useRef(false);

  const [isSenderId, setSenderId] = useState("");
  const [isUserId, setUserId] = useState("");

  const user = useSelector((state) => state?.auth?.user);
  const shouldIncludeUserId = [2, 3, 4].includes(user?.role_ID);

  useEffect(() => {
    if (user?.role_ID === 1 || hasFetchedUsersDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (!isSenderId || hasFetchedTemplatesDropdowns.current) return;
    // FetchedGroupDropDownData();
    const payload = { sender_ID: isSenderId || "" };
    fetchPostDropDownData(
      `fetch-template-details`,
      payload,
      setTemplateDropdown,
      showSnackBar
    );
    hasFetchedTemplatesDropdowns.current = true;
  }, [isSenderId]);

  useEffect(() => {
    if (!user?.role_ID || hasFetchedSendersDropdowns.current) return;

    const userIdToUse = user?.role_ID === 1 ? user?.id : isUserId;
    if (!userIdToUse) return;

    const payload = { id: userIdToUse };
    fetchPostDropDownData(
      `template-details/getSenders`,
      payload,
      setSenders,
      showSnackBar
    );
    hasFetchedSendersDropdowns.current = true;
  }, [isUserId, user?.role_ID, user?.id]);

  useEffect(() => {
    if (!user?.id || hasFetchedRoutesDropdowns.current) return;
    const payload = { user_id: user?.id };
    fetchPostDropDownData(
      `user-assigned-routes`,
      payload,
      setUserAssignRouteDropdown,
      showSnackBar
    );
    hasFetchedRoutesDropdowns.current = true;
  }, [user?.id]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        file: rowData?.file || null,
        get_response: rowData.get_response === 1 ? true : false,
        sender_ID: rowData?.sender_ID || "",
        ...(shouldIncludeUserId && {
          user_ID: rowData.user_ID || "",
        }),
        route_ID: rowData?.route_ID || "",
        template_ID: rowData?.template_ID || "",
        sms_api: rowData.sms_api === 1 ? true : false,
        client_api: rowData?.client_api || "",
      }
    : {
        file: null,
        get_response: false,
        ...(shouldIncludeUserId && {
          user_ID: "",
        }),
        sender_ID: "",
        route_ID: "",
        template_ID: "",
        sms_api: false,
        client_api: "",
      };

  // Dynamic validation schema based on form state
  // const getValidationSchema = (values) => {
  //   let validationSchema = {
  //     file: mixed(),
  //     get_response: mixed(),
  //     sms_api: mixed(),
  //     sender_ID: string(),
  //     route_ID: string(),
  //     template_ID: string(),
  //     client_api: string(),
  //   };

  //   // validationSchema.file = mixed()
  //   //   .required("Only image files (JPG, PNG) are required.")
  //   //   .test(
  //   //     "fileType",
  //   //     "Only image files (JPG, PNG) are allowed.",
  //   //     function (value) {
  //   //       if (value && value instanceof File) {
  //   //         const validTypes = ["image/jpeg", "image/png"];
  //   //         return validTypes.includes(value.type);
  //   //       }
  //   //       return true;
  //   //     }
  //   //   )
  //   //   .test("fileSize", "File size must be less than 2 MB", function (value) {
  //   //     if (value && value instanceof File) {
  //   //       return value.size <= 2097152;
  //   //     }
  //   //     return true;
  //   //   });

  //   validationSchema.file = mixed()
  //     .required("Only image files (JPG, PNG) are required.")
  //     .test(
  //       "fileType",
  //       "Only image files (JPG, PNG) are allowed.",
  //       function (value) {
  //         if (value && value instanceof File) {
  //           const validTypes = ["image/jpeg", "image/png"];
  //           return validTypes.includes(value.type);
  //         }
  //         return true;
  //       }
  //     )
  //     .test("fileSize", "File size must be less than 2 MB", function (value) {
  //       if (value && value instanceof File) {
  //         return value.size <= 2097152;
  //       }
  //       return true;
  //     });

  //   validationSchema.sender_ID = string().when("get_response", {
  //     is: (val) => val === true,
  //     then: (schema) => schema.required("Sender is required"),
  //     otherwise: (schema) => schema.notRequired(),
  //   });

  //   // if (values?.get_response) {
  //   //   validationSchema.sender_ID = string().required("Sender ID is required");
  //   //   validationSchema.route_ID = string().required("Route ID is required");
  //   //   validationSchema.template_ID = string().required(
  //   //     "Template ID is required"
  //   //   );
  //   // }

  //   if (values?.sms_api) {
  //     validationSchema.client_api = string()
  //       .matches(
  //         validationRegex?.blankSpace,
  //         validationRegex?.blankSpacesMessage
  //       )
  //       .required("Client API is required");
  //   }

  //   return object().shape(validationSchema);
  // };

  const validationSchema = Yup.object().shape({
    file: Yup.mixed()
      .required("Only audio files (MP3, WAV) are required.")
      .test(
        "fileType",
        "Only audio files (MP3, WAV) are allowed.",
        function (value) {
          if (value && value instanceof File) {
            const validTypes = ["audio/mpeg", "audio/wav"];
            return validTypes.includes(value.type);
          }
          return true;
        }
      )
      .test("fileSize", "File size must be less than 2 MB", function (value) {
        if (value && value instanceof File) {
          return value.size <= 2097152;
        }
        return true;
      }),

    get_response: Yup.boolean(), // include this if not already in initialValues

    user_ID: Yup.string().when("get_response", {
      is: (val) => val === true && shouldIncludeUserId,
      then: (schema) => schema.required("User ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    sender_ID: Yup.string().when("get_response", {
      is: (val) => val === true,
      then: (schema) => schema.required("Sender is required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    route_ID: Yup.string().when("get_response", {
      is: (val) => val === true,
      then: (schema) => schema.required("Route is required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    template_ID: Yup.string().when("get_response", {
      is: (val) => val === true,
      then: (schema) => schema.required("Template is required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    sms_api: Yup.boolean(), // include this if not already in initialValues

    client_api: Yup.string().when("sms_api", {
      is: (val) => val === true,
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .required("Client API is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
  });

  const handleSubmit = (payload) => {
    // console.log("payload => ", payload);
    const isUpdate = !!rowData?.id;
    const sanitizedPayload = { ...payload };
    const url = isUpdate
      ? `multimedia/update/${rowData.id}`
      : "multimedia/store";

    if (isEdit && typeof sanitizedPayload.file === "string") {
      delete sanitizedPayload.file;
    }

    // const requestFunction = isUpdate ? putRequest : postRequest;

    postDocumentRequest(
      url,
      {
        ...sanitizedPayload,
        user_ID: isEdit ? sanitizedPayload?.user_ID : user?.id,
        get_response: sanitizedPayload.get_response ? 1 : 0,
        sms_api: sanitizedPayload.sms_api ? 1 : 0,
        ...(shouldIncludeUserId && {
          user_ID: sanitizedPayload.user_ID || "",
        }),
        ...(user?.role_ID === 1 &&
          user?.id && {
            user_ID: user?.id || "",
          }),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          // console.log("response => ", response);
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          const errors = response?.data?.errors || {};
          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => ({
                field,
                message: errorMessages.join(", "),
              })
            );
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );
    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit MultiMedia Details" : "Add MultiMedia Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("form values => ", values);
          // console.log("buttoncndn => ", isValid, dirty, touched, errors);
          // Handle conditional logic for switches - mutual exclusivity
          const handleGetResponseChange = (checked) => {
            setFieldValue("get_response", checked);
            if (checked) {
              // Auto set sms_api to false and clear its fields
              setFieldValue("sms_api", false);
              setFieldValue("client_api", "");
            } else {
              // Clear get_response related fields when turned off
              setFieldValue("user_ID", "");
              setFieldValue("sender_ID", "");
              setFieldValue("route_ID", "");
              setFieldValue("template_ID", "");
              setSenderId("");
            }
          };

          const handleSmsApiChange = (checked) => {
            setFieldValue("sms_api", checked);
            if (checked) {
              // Auto set get_response to false and clear its fields
              setFieldValue("get_response", false);
              setFieldValue("user_ID", "");
              setFieldValue("sender_ID", "");
              setFieldValue("route_ID", "");
              setFieldValue("template_ID", "");
              setSenderId("");
            } else {
              // Clear sms_api related fields when turned off
              setFieldValue("client_api", "");
            }
          };

          return (
            <>
              {/* Top three fields - always visible */}
              <Grid
                container
                rowSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* File Upload */}
                <Grid size={{ xs: 12, sm: 4, md: 4 }}>
                  <Box sx={{ display: "flex", flexDirection: "column" }}>
                    <Typography sx={{ mb: 1 }}>File Upload *:</Typography>
                    {values?.file === null ? (
                      <Box>
                        <Button
                          name="file"
                          variant="outlined"
                          fullWidth
                          startIcon={<CloudUploadIcon />}
                          onClick={() => documentFileRef.current.click()}
                          sx={{
                            color: "#181C32",
                            borderColor:
                              errors?.file && touched?.file
                                ? "error.main"
                                : "#181C32",
                            "&:hover": {
                              color: "#FFFFFF",
                              backgroundColor: "#A780FF",
                            },
                          }}
                          onBlur={handleBlur}
                        >
                          Upload Audio File
                          <VisuallyHiddenInput type="file" />
                        </Button>
                        <input
                          ref={documentFileRef}
                          accept=".mp3, .wav"
                          type="file"
                          name="file"
                          style={{ display: "none" }}
                          onChange={(e) => {
                            const file = e.target.files[0];
                            const validTypes = ["audio/mpeg", "audio/wav"];
                            const isFileValid = validTypes.includes(file?.type);
                            if (file && isFileValid && file.size <= 2097152) {
                              setFieldValue("file", file);
                              showSnackBar(
                                "success",
                                "Audio Uploaded Successfully"
                              );
                            } else if (file?.size > 2097152) {
                              showSnackBar(
                                "error",
                                "File size must be less than 2 MB"
                              );
                              e.target.value = "";
                            } else {
                              setFieldValue("file", null);
                              showSnackBar("error", "Invalid Audio Format");
                            }
                          }}
                        />
                      </Box>
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <Typography
                          sx={{
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            maxWidth: "fit-content",
                          }}
                        >
                          Uploaded File:{" "}
                          {typeof values.file === "object"
                            ? values.file?.name
                            : rowData?.file}
                        </Typography>
                        <IconButton onClick={() => setFieldValue("file", null)}>
                          <CloseIcon />
                        </IconButton>
                      </Box>
                    )}
                    {errors?.file && touched?.file && (
                      <FormHelperText error>{errors?.file}</FormHelperText>
                    )}
                  </Box>
                </Grid>

                {/* Auto Response Switch */}
                <Grid size={{ xs: 12, sm: 4, md: 4 }} mt={3}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Typography
                      sx={{
                        fontSize: "14px",
                        fontWeight: "600",
                        color: "grey",
                      }}
                    >
                      Auto Response
                    </Typography>
                    <Switch
                      checked={values.get_response}
                      onChange={(e) =>
                        handleGetResponseChange(e.target.checked)
                      }
                      sx={{ ml: 1 }}
                    />
                  </Box>
                </Grid>

                {/* SMS API Switch */}
                <Grid size={{ xs: 12, sm: 4, md: 4 }} mt={3}>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Typography
                      sx={{
                        fontSize: "14px",
                        fontWeight: "600",
                        color: "grey",
                      }}
                    >
                      SMS API
                    </Typography>
                    <Switch
                      checked={values.sms_api}
                      onChange={(e) => handleSmsApiChange(e.target.checked)}
                      sx={{ ml: 1 }}
                    />
                  </Box>
                </Grid>

                {/* Conditional fields for get_response */}
                {values.get_response && (
                  <>
                    {shouldIncludeUserId && (
                      <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                        <IconAutocompleteField
                          icon={PersonIcon}
                          name="user_ID"
                          id="user_ID"
                          label="Select User *"
                          multiple={false}
                          options={usersData || []}
                          getOptionLabel={(option) => option?.username || ""}
                          value={
                            usersData?.find(
                              (type) => type?.id === values?.user_ID
                            ) || null
                          }
                          isOptionEqualToValue={(option, value) =>
                            option?.id === value?.id
                          }
                          onChange={(e, value) => {
                            setFieldValue("sender_ID", "");

                            const userId = value?.id || "";
                            if (userId) {
                              setFieldValue("user_ID", userId);
                              setUserId(userId);
                            } else {
                              setFieldValue("sender_ID", "");
                              setFieldValue("template_ID", "");
                            }
                          }}
                          errors={errors}
                          touched={touched}
                          handleBlur={handleBlur}
                        />
                      </Grid>
                    )}
                    <Grid size={{ xs: 12, sm: 4, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="sender_ID"
                        id="sender_ID"
                        label="Select Sender ID *"
                        multiple={false}
                        options={senders || []}
                        getOptionLabel={(option) => option?.sender_ID || ""}
                        value={
                          senders?.find(
                            (type) => type?.id === values?.sender_ID
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) => {
                          setFieldValue("sender_ID", value?.id || "");
                          setSenderId(value?.id || "");
                          if (!value?.id) {
                            setFieldValue("template_ID", "");
                          }
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                        disabled={!values?.user_ID && user?.role_ID !== 1}
                      />
                    </Grid>

                    <Grid size={{ xs: 12, sm: 4, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="template_ID"
                        id="template_ID"
                        label="Template ID *"
                        multiple={false}
                        options={templateDropdown || []}
                        getOptionLabel={(option) => option?.template_ID || ""}
                        value={
                          templateDropdown?.find(
                            (type) => type?.id === values?.template_ID
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) =>
                          setFieldValue("template_ID", value?.id || "")
                        }
                        disabled={!values?.sender_ID}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Grid>

                    <Grid size={{ xs: 12, sm: 4, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="route_ID"
                        id="route_ID"
                        label="Select Route *"
                        multiple={false}
                        options={userAssignRouteDropdown || []}
                        getOptionLabel={(option) => option?.route_name || ""}
                        value={
                          userAssignRouteDropdown?.find(
                            (type) => type?.id === values?.route_ID
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) =>
                          setFieldValue("route_ID", value?.id || "")
                        }
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Grid>
                  </>
                )}

                {/* Conditional field for sms_api */}
                {values.sms_api && (
                  <Grid size={{ xs: 12, sm: 8, md: 8 }}>
                    <Typography
                      variant="body1"
                      component="label"
                      htmlFor="client_api"
                    >
                      API
                      <Typography
                        component="span"
                        sx={{ color: "red", ml: 0.5 }}
                      >
                        *
                      </Typography>
                    </Typography>
                    <TextareaAutosize
                      name="client_api"
                      id="client_api"
                      minRows={3}
                      placeholder="Enter API details"
                      value={values.client_api}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      style={{
                        width: "100%",
                        maxWidth: "800px",
                        height: "auto",
                        padding: "8px",
                        marginTop: "8px",
                      }}
                    />
                    {errors?.client_api && touched?.client_api && (
                      <FormHelperText error>
                        {errors?.client_api}
                      </FormHelperText>
                    )}
                  </Grid>
                )}
              </Grid>

              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />

              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditMultiMedia;
