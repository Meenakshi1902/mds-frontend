import React, { useState } from "react";
import { Box, Grid } from "@mui/material";
import { defaultSnackBarState } from "../../utils/common";
import SnackbarAlert from "../../components/SnackBarMessage/SnackbarAlert";
import AddBulkSmsForm from "./AddBulkSmsForm/AddBulkSmsForm";
import ModalComponent from "../../components/ModalComponent/ModalComponent";
import TrackingUrlForm from "./TrackingUrlForm/TrackingUrlForm";
import AddEditSenderDetails from "../SenderDetails/AddEditSenderDetails/AddEditSenderDetails";
import AddEditTemplateDetails from "../templateDetails/AddEditTemplateDetails/AddEditTemplateDetails";
import SheduleSmsForm from "./SheduleSmsForm/SheduleSmsForm";
import { useSelector } from "react-redux";

const BulkSms = () => {
  const user = useSelector((state) => state?.auth?.user);
  // console.log("user => ", user);
  const [enableAddForm, setEnableAddForm] = useState(null);
  // console.log("enableAddForm => ", enableAddForm);
  // const [enableTrackingUrl, setEnableTrackingUrl] = useState(false);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [selectedRowData, setSelectedRowData] = useState({});
  const [refreshTable, setRefreshTable] = useState(false);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      // setEnableTrackingUrl(true);
      setSelectedRowData([]);
    }
  };

  // const openModal = (type) => {
  //   setEnableAddForm(type);
  // };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      <AddBulkSmsForm
        rowData={selectedRowData}
        setSelectedRowData={setSelectedRowData}
        closeModal={closeModal}
        showSnackBar={showSnackBar}
        setRefreshTable={setRefreshTable}
        setEnableAddForm={setEnableAddForm}
        // enableTrackingUrl={enableTrackingUrl}
      />

      <ModalComponent
        style={style}
        closeModal={closeModal}
        enableAddForm={enableAddForm}
      >
        {enableAddForm && enableAddForm === "trackingUrlModal" && (
          <TrackingUrlForm
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
        {enableAddForm && enableAddForm === "sendModal" && (
          <AddEditSenderDetails
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
        {enableAddForm && enableAddForm === "temModal" && (
          <AddEditTemplateDetails
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
        {enableAddForm && enableAddForm === "sheduleSmsModal" && (
          <SheduleSmsForm
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
      </ModalComponent>

      {/* <Box px={2} pb={2}>
        <Grid>
          <Box sx={{ mt: "10px" }}>
            <ManagePlanTable
              rowData={selectedRowData}
              setSelectedRowData={setSelectedRowData}
              refreshTable={refreshTable}
              setRefreshTable={setRefreshTable}
              showSnackBar={showSnackBar}
              openModal={openModal}
            />
          </Box>
        </Grid>
      </Box> */}
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default BulkSms;
