import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  FormHelperText,
  Switch,
  IconButton,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { array, boolean, mixed, object, string } from "yup";
import {
  fetchGetDropDownData,
  fetchPostDropDownData,
  messageType,
  method,
  transformMultipleIdForEdit,
  validationRegex,
} from "../../../utils/common";
import { postRequest } from "../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../components/IconAutocompleteField/IconAutocompleteField";
import CheckboxInputAutocompleteField from "../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

const AddBulkSmsForm = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
  setEnableAddForm,
}) => {
  const [charCount, setCharCount] = useState(0);
  const [smsCount, setSmsCount] = useState(0);

  // console.log("smsCount => ", smsCount);

  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const user = useSelector((state) => state?.auth?.user);

  // const dispatch = useDispatch();
  const hasFetchedRoutes = useRef(false);
  const hasFetchedSender = useRef(false);
  const hasFetchedGroup = useRef(false);

  const [groupAutocompleteOpen, setGroupAutocompleteOpen] = useState(false);

  const [RoutesData, setRoutesData] = useState([]);
  // console.log("RoutesData => ", RoutesData);
  //   console.log("RoutesData => ", RoutesData);
  const [senderData, setSenderData] = useState([]);
  // console.log("senderData => ", senderData);
  const [senderID, setSenderID] = useState("");

  const [groupUserData, setGroupUserData] = useState([]);
  // console.log("groupUserData => ", groupUserData);
  const [templateData, setTemplateData] = useState([]);

  //   const isEdit = rowData && Object.keys(rowData).length > 0;

  //   const initialValues = isEdit
  //     ? {
  //         ...rowData,
  //         // ...(shouldIncludeUserId && {
  //         //   user_ID: rowData.user_ID || "",
  //         // }),
  //         route_name: rowData.route_name || "",
  //         senderid: rowData.senderid || "",
  //         template_ID: rowData.template_ID || "",
  //         method: rowData.method || "", // message format dropdown.
  //         numbers: rowData.numbers || "", // for numbers method
  //         group_IDs: transformMultipleIdForEdit(rowData?.group_IDs), // for group method
  //         csv_file: rowData.csv_file || "", // if message format dropdown. > select > csv option
  //         campaign_name: rowData.campaign_name || "",
  //         message_type: rowData.message_type || "",
  //         // unicode_type: rowData.unicode_type || "",   // message type option send to option in payload with this parameter.
  //         // original_url: rowData.original_url || "",  // this will used for Tracking URl for url and upload file for both use same parameter.
  //       }
  //     : {
  //         // ...(shouldIncludeUserId && {
  //         //   user_ID: "",
  //         // }),
  //         route_name: "",
  //         senderid: "",
  //         template_ID: "",
  //         method: rowData.method || "", // message format dropdown.
  //         numbers: "", // for numbers method
  //         group_IDs: [], // for group method
  //         csv_file: rowData.csv_file || "", // if message format dropdown. > select > csv option
  //         campaign_name: rowData.campaign_name || "",
  //         message_type: rowData.message_type || "",
  //         // unicode_type: rowData.unicode_type || "", // message type option send to option in payload with this parameter.
  //         // original_url: rowData.original_url || "",  // this will used for Tracking URl for url and upload file for both use same parameter.
  //       };

  const initialValues = {
    route_name: "",
    senderid: "",
    template_ID: "",
    message: "",
    method: method[0], // message format dropdown.
    numbers: "", // for numbers method
    group_IDs: [], // for group method
    csv_file: null, // if message format dropdown. > select > csv option
    campaign_name: "",
    message_type: messageType[0],
    // unicode_type: "", // message type option send to option in payload with this parameter.
    tracking_url: false,
    original_url: "", // this will used for Tracking URl for url and upload file for both use same parameter.
  };

  const validationSchema = object().shape({
    route_name: string().required("Route Name is required"),
    senderid: string().required("Sender ID is required"),
    template_ID: string().required("Template is required"),
    message: string().required("Message is required"),
    method: string().required("Message Format is required"),
    // numbers: string().when("method", {
    //   is: "Numbers",
    //   then: (schema) => schema.required("Numbers is required"),
    //   otherwise: (schema) => schema.notRequired(),
    // }),
    numbers: string()
      .required("Numbers are required")
      .test(
        "valid-numbers",
        "All numbers must be at least 8 digits and Enter Numbers separated by comma or press enter",
        (value) => {
          if (!value) return false;

          const numberRegex = /^\d{8,}$/;
          return value
            .split(/[\n,]+/) // split by newline or comma
            .map((num) => num.trim()) // remove surrounding spaces
            .filter((num) => num.length > 0) // skip empty entries
            .every((num) => numberRegex.test(num)); // check each number
        }
      ),
    // group_IDs: array()
    //   .of(
    //     object().shape({
    //       id: mixed().required("Group ID is required"),
    //     })
    //   )
    //   .min(1, "At least one Group ID is required")
    //   .required("Group ID is required"),
    group_IDs: array().when("method", {
      is: "Groups",
      then: (schema) =>
        schema
          .of(
            object().shape({
              id: mixed().required("Group ID is required"),
            })
          )
          .min(1, "At least one Group ID is required")
          .required("Group ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    // csv_file: mixed()
    //   .required("Only image files (CSV, XLSX, or TXT files) are required.")
    //   .test(
    //     "fileType",
    //     "Only CSV, XLSX, or TXT files are allowed.",
    //     function (value) {
    //       if (value && value instanceof File) {
    //         const validTypes = [
    //           "text/csv",
    //           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    //           "text/plain",
    //         ];
    //         return validTypes.includes(value.type);
    //       }
    //       return true;
    //     }
    //   )
    //   .test("fileSize", "File size must be less than 2 MB", function (value) {
    //     if (value && value instanceof File) {
    //       return value.size <= 2097152;
    //     }
    //     return true;
    //   }),
    csv_file: mixed().when("method", {
      is: "CSV",
      then: (schema) =>
        schema
          .required("CSV file is required")
          .test(
            "fileType",
            "Only CSV, XLSX, or TXT files are allowed.",
            function (value) {
              if (value && value instanceof File) {
                const validTypes = [
                  "text/csv",
                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  "text/plain",
                ];
                return validTypes.includes(value.type);
              }
              return true;
            }
          )
          .test(
            "fileSize",
            "File size must be less than 2 MB",
            function (value) {
              if (value && value instanceof File) {
                return value.size <= 2 * 1024 * 1024; // 2MB
              }
              return true;
            }
          ),
      otherwise: (schema) => schema.notRequired(),
    }),
    campaign_name: string().required("Campaign Name is required"),
    message_type: string().required("Message Type is required"),
    // tracking_url: string().required("Tracking URL is required"),
    // tracking_url: boolean().oneOf([true], "Tracking must be enabled."),
  });

  const handleSubmit = (payload) => {
    // console.log("rowdata inside => ", rowData);
    // console.log("payload => ", payload);

    // const isUpdate = !!rowData?.id;
    // const url = isUpdate
    //   ? `sender-details/update/${rowData.id}`
    //   : "sender-details/store";

    // const requestFunction = isUpdate ? putRequest : postRequest;

    postRequest(
      `send-messages`,
      {
        ...payload,
        // ...(shouldIncludeUserId && {
        //   user_ID: payload.user_ID || "",
        // }),

        // ...(user?.role_ID === 1 &&
        //   user?.id && {
        //     user_ID: user?.id,
        //   }),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  // const fetchRoutesDropDownData = () => {
  //   getRequest("fetch-routes", function (response) {
  //     if (!response?.data?.errors) {
  //       setRoutesData(response?.data?.data);
  //     } else {
  //       // Handling error messages
  //       const errors = response?.data?.errors || {};

  //       if (typeof errors === "string") {
  //         showSnackBar("error", errors);
  //       } else if (typeof errors === "object") {
  //         const mappedErrors = Object.entries(errors).map(
  //           ([field, errorMessages]) => {
  //             return {
  //               field,
  //               message: errorMessages.join(", "),
  //             };
  //           }
  //         );

  //         mappedErrors.forEach(({ field, message }) => {
  //           showSnackBar("error", `${field}: ${message}`);
  //         });
  //       }
  //       setRoutesData([]);
  //     }
  //   });
  // };

  useEffect(() => {
    if (hasFetchedRoutes.current) return;
    // fetchRoutesDropDownData();
    fetchGetDropDownData(`fetch-routes`, setRoutesData, showSnackBar);
    hasFetchedRoutes.current = true;
  }, []);

  // const fetchSendersDropDownData = () => {
  //   getRequest("fetch-sender-id", function (response) {
  //     if (!response?.data?.errors) {
  //       setSenderData(response?.data?.data);
  //     } else {
  //       // Handling error messages
  //       const errors = response?.data?.errors || {};

  //       if (typeof errors === "string") {
  //         showSnackBar("error", errors);
  //       } else if (typeof errors === "object") {
  //         const mappedErrors = Object.entries(errors).map(
  //           ([field, errorMessages]) => {
  //             return {
  //               field,
  //               message: errorMessages.join(", "),
  //             };
  //           }
  //         );

  //         mappedErrors.forEach(({ field, message }) => {
  //           showSnackBar("error", `${field}: ${message}`);
  //         });
  //       }
  //       setSenderData([]);
  //     }
  //   });
  // };

  useEffect(() => {
    if (hasFetchedSender.current) return;
    // fetchSendersDropDownData();
    fetchGetDropDownData(`fetch-sender-id`, setSenderData, showSnackBar);
    hasFetchedSender.current = true;
  }, []);

  // const FetchedGroupDropDownData = () => {
  //   getRequest("fetch-group-details", function (response) {
  //     if (!response?.data?.errors) {
  //       setGroupUserData(response?.data?.data);
  //     } else {
  //       // Handling error messages
  //       const errors = response?.data?.errors || {};

  //       if (typeof errors === "string") {
  //         showSnackBar("error", errors);
  //       } else if (typeof errors === "object") {
  //         const mappedErrors = Object.entries(errors).map(
  //           ([field, errorMessages]) => {
  //             return {
  //               field,
  //               message: errorMessages.join(", "),
  //             };
  //           }
  //         );

  //         mappedErrors.forEach(({ field, message }) => {
  //           showSnackBar("error", `${field}: ${message}`);
  //         });
  //       }
  //       setGroupUserData([]);
  //     }
  //   });
  // };

  useEffect(() => {
    if (hasFetchedGroup.current) return;
    // FetchedGroupDropDownData();
    fetchGetDropDownData(`fetch-group-details`, setGroupUserData, showSnackBar);
    hasFetchedGroup.current = true;
  }, []);

  useEffect(() => {
    if (!senderID) return;
    // FetchedGroupDropDownData();
    const payload = { sender_ID: senderID };
    fetchPostDropDownData(
      `fetch-template-details`,
      payload,
      setTemplateData,
      showSnackBar
    );
  }, [senderID]);

  const getValidMobileNumbersCount = (input) => {
    if (!input) return 0;

    const mobileRegex = /^\d{8,}$/;

    return input
      .split(/[\n,]+/) // split on newline OR comma
      .map((num) => num.trim()) // remove extra spaces
      .filter((num) => mobileRegex.test(num)).length; // validate
  };

  // console.log("getValidMobileNumbersCount => ", getValidMobileNumbersCount);

  // Function to calculate character count and SMS count
  const calculateSMSCounts = (message, messageType) => {
    const messageLength = message.length;
    let smsCount = 0;

    if (messageLength === 0) {
      return { charCount: 0, smsCount: 0 };
    }

    if (messageType === "Unicode") {
      // For Unicode messages: show count only when 70+ chars
      if (messageLength >= 70) {
        // 70-139 = 1 SMS, 140-209 = 2 SMS, etc.
        smsCount = Math.ceil((messageLength - 69) / 70);
      }
    } else {
      // For Text messages: show count only when 160+ chars
      if (messageLength >= 160) {
        // 160-319 = 1 SMS, 320-479 = 2 SMS, etc.
        smsCount = Math.ceil((messageLength - 159) / 160);
      }
    }

    return { charCount: messageLength, smsCount };
  };

  return (
    <Box px={2}>
      {/* <Typography variant="h5">
        {isEdit ? "Edit Sender Details" : "Create Sender Details"}
      </Typography> */}
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("form values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          // Update character and SMS counts whenever message or message_type changes
          useEffect(() => {
            const { charCount: newCharCount, smsCount: newSmsCount } =
              calculateSMSCounts(values.message, values.message_type);
            setCharCount(newCharCount);
            setSmsCount(newSmsCount);
          }, [values.message, values.message_type]);

          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="route_name"
                    id="route_name"
                    label="Select Route *"
                    multiple={false}
                    options={RoutesData || []}
                    getOptionLabel={(option) => option?.route_name || ""}
                    value={
                      RoutesData?.find(
                        (type) => type?.id === values?.route_name
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("route_name", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Box flex={1}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="senderid"
                        id="senderid"
                        label="Select Sender ID *"
                        multiple={false}
                        options={senderData || []}
                        getOptionLabel={(option) => option?.sender_ID || ""}
                        value={
                          senderData?.find(
                            (type) => type?.id === values?.senderid
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) => {
                          setFieldValue("senderid", value?.id || "");
                          if (value?.id) {
                            setSenderID(value?.id);
                          } else {
                            setSenderID("");
                          }
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Box>

                    <Button
                      onClick={() => setEnableAddForm("sendModal")}
                      variant="contained"
                      sx={{
                        backgroundColor: "#1976d2",
                        "&:hover": {
                          backgroundColor: "#4DA8DA",
                        },
                        color: "#ffffff",
                        textTransform: "none",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        minWidth: "40px",
                        height: "40px",
                        padding: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Box flex={1}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="template_ID"
                        id="template_ID"
                        label="Select Template ID *"
                        multiple={false}
                        options={templateData || []}
                        getOptionLabel={(option) => option?.template_name || ""}
                        value={
                          templateData?.find(
                            (type) => type?.id === values?.template_ID
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) => {
                          setFieldValue("template_ID", value?.id || "");
                        }}
                        disabled={!values?.senderid}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Box>

                    <Button
                      onClick={() => setEnableAddForm("temModal")}
                      variant="contained"
                      sx={{
                        backgroundColor: "#1976d2",
                        "&:hover": {
                          backgroundColor: "#4DA8DA",
                        },
                        color: "#ffffff",
                        textTransform: "none",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        minWidth: "40px",
                        height: "40px",
                        padding: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="method"
                    id="method"
                    label="Message Format *"
                    multiple={false}
                    options={method || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      method?.find((type) => type === values?.method) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("method", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* Numbers Field */}
                {values?.method === "Numbers" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        mb: 1,
                      }}
                    >
                      <Typography
                        variant="body1"
                        component="label"
                        htmlFor="numbers"
                        sx={{ display: "flex", alignItems: "center" }}
                      >
                        Numbers
                        <Typography
                          component="span"
                          sx={{ color: "red", ml: 0.5 }}
                        >
                          *
                        </Typography>
                      </Typography>
                    </Box>

                    <TextareaAutosize
                      name="numbers"
                      id="numbers"
                      aria-label="numbers"
                      minRows={3}
                      placeholder="Type Numbers Separated by New Line"
                      value={values.numbers}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      style={{
                        width: "100%",
                        maxWidth: "800px",
                        height: "auto",
                        padding: "8px",
                      }}
                    />
                    {errors?.numbers && touched?.numbers && (
                      <FormHelperText error>{errors?.numbers}</FormHelperText>
                    )}

                    {/* Character and SMS Count Boxes */}
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        gap: 2,
                        mt: 1.5,
                        color: "#1976d2",
                        fontWeight: "bold",
                        fontSize: "14px",
                      }}
                    >
                      <Box
                        sx={{
                          // flex: 1,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: "8px 12px",
                          border: "1px solid #1976d2",
                          borderRadius: "10rem",
                          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                          transition: "all 0.3s ease",
                          "&:hover": {
                            backgroundColor: "#1976d2",
                            color: "#fff",
                          },
                        }}
                      >
                        <Typography variant="body2">
                          No's : {getValidMobileNumbersCount(values.numbers)}
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                )}

                {/* Group ID Field */}
                {values?.method === "Groups" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <CheckboxInputAutocompleteField
                      icon={PersonIcon}
                      id="group_IDs"
                      name="group_IDs"
                      label="Select Groups: *"
                      options={groupUserData || []}
                      getOptionLabel={(option) => option?.group_name}
                      getOptionValue={(option) => option?.id} // How to get the ID value
                      getDisplayValue={(option) => option?.group_name} // What to display in checkbox list
                      value={values?.group_IDs}
                      setFieldValue={setFieldValue}
                      handleBlur={handleBlur}
                      errors={errors}
                      touched={touched}
                      autoCompleteOpen={groupAutocompleteOpen}
                      setAutoCompleteOpen={setGroupAutocompleteOpen}
                    />
                  </Grid>
                )}

                {/* Upload File Field */}
                {values?.method === "CSV" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    {values?.csv_file === null ? (
                      <Box>
                        <Button
                          name="csv_file"
                          id="csv_file"
                          variant="outlined"
                          fullWidth
                          startIcon={<CloudUploadIcon />}
                          // onClick={() => documentFileRef.current.click()}
                          onClick={() => {
                            documentFileRef.current.click();
                            // Mark the field as touched when clicking the upload button
                            // setFieldTouched('csv_file', true);
                          }}
                          sx={{
                            color: "#1976d2",
                            borderColor:
                              errors?.csv_file && touched?.csv_file
                                ? "error.main"
                                : "#1976d2",
                            borderRadius: "10rem",
                            "&:hover": {
                              color: "#FFFFFF",
                              backgroundColor: "#1976d2",
                            },
                          }}
                          onBlur={handleBlur}
                        >
                          Upload File *
                          <VisuallyHiddenInput type="file" />
                        </Button>
                        <input
                          ref={documentFileRef}
                          accept=".csv, .xlsx, .txt"
                          // accept=".doc,.docx,.pdf"
                          type="file"
                          name="csv_file"
                          id="csv_file"
                          style={{ display: "none" }}
                          onChange={(e) => {
                            const file = e.target.files[0];
                            // console.log('file => ', file);
                            //   const validTypes = ["image/jpeg", "image/png"];
                            const validTypes = [
                              "text/csv", // .csv
                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
                              "text/plain", // .txt
                            ];
                            const isFileValid = validTypes.includes(file.type);
                            if (file && isFileValid) {
                              setFieldValue("csv_file", file);
                              showSnackBar(
                                "success",
                                "File Uploaded Successfully"
                              );
                              // setFieldTouched('csv_file', true);
                            } else if (file.size > 2097152) {
                              // 2 MB limit
                              setFieldError(
                                "csv_file",
                                "File size must be less than 2 MB"
                              );
                              e.target.value = ""; // Reset the input
                            } else {
                              setFieldValue("csv_file", null);
                              showSnackBar("error", "Invalid File Format");
                            }
                          }}
                          onBlur={handleBlur}
                        />
                      </Box>
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <Typography
                          sx={{
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            maxWidth: "fit-content",
                          }}
                        >
                          Uploaded File:&nbsp;&nbsp;
                          {typeof values.csv_file === "object"
                            ? values.csv_file?.name
                            : rowData?.csv_file}
                        </Typography>

                        <IconButton
                          onClick={() => setFieldValue("csv_file", null)}
                        >
                          <CloseIcon />
                        </IconButton>
                      </Box>
                    )}
                    {errors?.csv_file && touched?.csv_file && (
                      <FormHelperText error>{errors?.csv_file}</FormHelperText>
                    )}
                  </Grid>
                )}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      mb: 1,
                    }}
                  >
                    <Typography
                      variant="body1"
                      component="label"
                      htmlFor="message"
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      Message
                      <Typography
                        component="span"
                        sx={{ color: "red", ml: 0.5 }}
                      >
                        *
                      </Typography>
                    </Typography>
                  </Box>

                  <TextareaAutosize
                    name="message"
                    id="message"
                    aria-label="message"
                    minRows={3}
                    placeholder="Type Message Here"
                    value={values.message}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                    // disabled={true}
                  />
                  {errors?.message && touched?.message && (
                    <FormHelperText error>{errors?.message}</FormHelperText>
                  )}

                  {/* Character and SMS Count Boxes */}
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 2,
                      mt: 1.5,
                      color: "#1976d2",
                      fontWeight: "bold",
                      fontSize: "14px",
                    }}
                  >
                    <Box
                      sx={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "8px 12px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                        },
                      }}
                    >
                      <Typography variant="body2">
                        Characters: {charCount}
                      </Typography>
                    </Box>

                    <Box
                      sx={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "8px 12px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                        },
                      }}
                    >
                      <Typography variant="body2">
                        SMS Count: {smsCount}
                      </Typography>
                    </Box>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="campaign_name"
                    id="campaign_name"
                    label="Campaign Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="message_type"
                    id="message_type"
                    label="Message Type *"
                    multiple={false}
                    disableClearable={true}
                    options={messageType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      messageType?.find(
                        (type) => type === values?.message_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("message_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid
                  size={{ xs: 12, sm: 8, md: 4 }}
                  sx={{ display: "flex", alignItems: "center" }}
                >
                  <Typography
                    sx={{
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "grey",
                    }}
                  >
                    Tracking URL
                  </Typography>
                  <Switch
                    id="tracking_url"
                    name="tracking_url"
                    label="Tracking URL"
                    checked={values.tracking_url}
                    onChange={(e) => {
                      setFieldValue("tracking_url", e.target.checked);
                      if (e.target.checked) {
                        setEnableAddForm("trackingUrlModal");
                      } else {
                        setEnableAddForm(null);
                      }
                    }}
                    sx={{ ml: 1 }}
                    slotProps={{ "aria-label": "controlled" }}
                  />
                </Grid>
                {/* {!values.tracking_url && touched?.tracking_url && (
                  <FormHelperText error>
                    Tracking must be enabled to proceed.
                  </FormHelperText>
                )} */}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2} gap={2}>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Send SMS
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
                <Button
                  variant="outlined"
                  onClick={() => setEnableAddForm("sheduleSmsModal")}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Shedule SMS
                </Button>
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddBulkSmsForm;
