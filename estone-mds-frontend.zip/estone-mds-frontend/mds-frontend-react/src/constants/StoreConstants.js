// Manage routing

export const SET_PLANDETAILS = "planDetails";

export const SET_ROUTEDROPDOWN = "routeDropdown";

export const SET_USERROUTERDROPDOWN = "userRoutesDropdown";
export const SET_ACCMANGDROPDOWN = "accMangDropdown";

export const SET_PLANDROPDOWN = "planData";

export const SET_USERASSIGNROUTEDROPDOWN = "userAssignRouteDropdown";

export const SET_SENDERTEMPDROPDOWN = "senderTempDropdown";

export const SET_TEMPLATEDROPDOWN = "templateDropdown";

export const SET_FETCHTEMPLATEDROPDOWN = "fetchTemplateDropdown";
