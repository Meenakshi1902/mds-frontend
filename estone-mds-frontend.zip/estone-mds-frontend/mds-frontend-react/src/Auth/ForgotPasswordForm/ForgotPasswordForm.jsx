import { Box, Button, TextField, Typography } from "@mui/material";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { string, object } from "yup";
import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { defaultSnackBarState, setEmailToStorage } from "../../utils/common";
import SnackbarAlert from "../../components/SnackBarMessage/SnackbarAlert";
import LoginRightSideImg from "../../assets/Images/LoginRighSideImg.png";
import { postRequest } from "../../helpers/http.helper";
import mdslogo from "../../assets/logos/mdslogo.png";
import ResetPassword from "./ResetPassword/ResetPassword";

const ForgotPassword = () => {
  const [currentView, setCurrentView] = useState("/forgot-password");
  const [resetEmail, setResetEmail] = useState("");

  //   const token = useParams();

  //   console.log("token => ", token);

  //   console.log("resetEmail => ", resetEmail);

  const navigate = useNavigate();

  const handleBackToLogin = () => {
    navigate("/login");
  };

  //   const handleBackToForgotPassword = () => {
  //     navigate("/forgot-password");
  //   }

  // { onResetPassword, onBackToLogin }
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);

  const forgotPasswordSchema = object().shape({
    email: string()
      .email("Enter a valid email address")
      .required("Enter your email address"),
  });

  const initialValue = {
    email: "",
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type,
      message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 5000);
  };

  const handleResetPassword = (email) => {
    setEmailToStorage(email);
    // navigate("/reset-password");
    setResetEmail(email);
    setCurrentView("resetPassword");
  };

  if (currentView === "resetPassword") {
    return (
      <ResetPassword
        email={resetEmail}
        handleBackToLogin={handleBackToLogin}
        // handleBackToForgotPassword={handleBackToForgotPassword}
      />
    );
  }

  const handleForgotPassword = (formData, props) => {
    const payload = {
      email: formData.email,
    };

    postRequest("password/forgot", payload, function (res) {
      if (res?.data?.error) {
        showSnackBar("error", res?.data?.error);
        props.setSubmitting(false);
        return;
      }

      showSnackBar(
        "success",
        res?.data?.message || "Password reset link sent to your email"
      );

      // Wait for snackbar to show, then redirect to reset password
      setTimeout(() => {
        handleResetPassword(formData.email);
      }, 2000);

      props.setSubmitting(false);
    });
  };

  return (
    <Box
      display="flex"
      height="100vh"
      alignItems="center"
      justifyContent="center"
      sx={{ overflow: "hidden" }}
    >
      {/* Main Content Wrapper */}
      <Box
        display="flex"
        flexDirection="row"
        alignItems="center"
        backgroundColor="#F2F2F2"
      >
        <Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              marginLeft: "95px",
            }}
          >
            <img
              src={mdslogo}
              alt="logo"
              style={{
                maxWidth: "100%",
                height: "40px",
                objectFit: "contain",
              }}
            />
          </Box>

          {/* Login Form */}
          <Box
            maxWidth="500px"
            width="100%"
            sx={{
              bgcolor: "#ffffff",
              borderRadius: 2,
              boxShadow: 2,
              p: 4,
              m: 4,
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
            }}
          >
            <Formik
              initialValues={initialValue}
              validationSchema={forgotPasswordSchema}
              onSubmit={handleForgotPassword}
              enableReinitialize
            >
              {(props) => {
                const { isSubmitting, dirty, isValid, errors } = props;
                // console.log("formconditions => ", isSubmitting, dirty, isValid, errors);
                // const { userName, password} = props.values;
                // console.log("userForm => ", userName, password);
                return (
                  <Form style={{ width: "100%" }}>
                    <Typography variant="h6" mb={2} color="primary">
                      Pending, Plz Don't Test
                    </Typography>
                    <Typography variant="h6" mb={2} color="primary">
                      Forgot Password
                    </Typography>

                    <Box mb={2}>
                      <Field
                        as={TextField}
                        label="Email Address *"
                        name="email"
                        type="email"
                        fullWidth
                        variant="outlined"
                        margin="dense"
                        helperText={<ErrorMessage name="email" />}
                        error={
                          Boolean(props.errors.email) && props.touched.email
                        }
                      />
                    </Box>

                    <Button
                      type="submit"
                      variant="contained"
                      fullWidth
                      sx={{
                        bgcolor: "blue",
                        color: "white !important",
                        py: 1.5,
                        "&:hover": {
                          bgcolor: "#5459AC",
                        },
                        borderRadius: 2,
                        boxShadow: 2,
                        mb: 2,
                      }}
                      disabled={!dirty || !isValid || isSubmitting}
                    >
                      {isSubmitting ? "Sending..." : "Send Reset Link"}
                    </Button>

                    <Box textAlign="center">
                      <Button
                        variant="text"
                        onClick={handleBackToLogin}
                        sx={{
                          color: "primary.main",
                          textTransform: "none",
                          "&:hover": {
                            backgroundColor: "rgba(0, 0, 0, 0.04)",
                          },
                        }}
                      >
                        ← Back to Login
                      </Button>
                    </Box>

                    {snackbarState?.show && (
                      <SnackbarAlert
                        open={snackbarState?.show}
                        message={snackbarState?.message}
                        severity={snackbarState?.type}
                        vertical={snackbarState?.vertical}
                        horizontal={snackbarState?.horizontal}
                      />
                    )}
                  </Form>
                );
              }}
            </Formik>
          </Box>
        </Box>

        {/* Right Side Image */}
        <Box
          flex={1}
          display="flex"
          justifyContent="center"
          alignItems="center"
          sx={{ px: 4, ml: { xs: 0, sm: 6, md: 12 } }} // Adjusts margin-left responsively
        >
          <img
            src={LoginRightSideImg}
            alt="MDS Right Side Image"
            style={{ maxWidth: "100vw", height: "auto" }}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default ForgotPassword;
