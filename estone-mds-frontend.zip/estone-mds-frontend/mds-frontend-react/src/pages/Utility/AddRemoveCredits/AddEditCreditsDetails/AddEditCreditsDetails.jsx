import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  FormControlLabel,
  FormHelperText,
  TextareaAutosize,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import {
  UserName,
  CreditType,
  fetchGetDropDownData,
  fetchPostDropDownData,
  Status,
  SelectRoute,
  templateTypeData,
  validationRegex,
} from "../../../../utils/common";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import { useSelector } from "react-redux";

const AddEditCreditsDetails = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);
  const hasFetchedUsersDropdowns = useRef(false);
  const hasFetchedGatewayDropdowns = useRef(false);
  const [usersData, setUsersData] = useState([]);
  const [RcsGatewayData, setRcsGatewayData] = useState([]);

  useEffect(() => {
    if (hasFetchedUsersDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      //   `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (hasFetchedGatewayDropdowns.current) return;
    fetchGetDropDownData(
      //   `rcs-gateway/gatewaysForDropdown`,
      setRcsGatewayData,
      showSnackBar
    );
    hasFetchedGatewayDropdowns.current = true;
  }, [user?.id]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        // user_name: rowData?.user_name || "",
        route_type:
          rowData?.route_type === templateTypeData[0]
            ? SelectRoute[0]
            : SelectRoute[1],
        remark: rowData.remark || "",
        credit_text: rowData?.credit_text || "",
        credit_type:
          CreditType.find(
            (type) => type.toLowerCase() === rowData?.credit_type
          ) || "",
        user_name:
          UserName.find((type) => type.toLowerCase() === rowData?.user_name) ||
          "",
      }
    : {
        // user_name: "",
        route_type: "",
        remark: "",
        credit_text: "",
        user_name: "",
      };

  const validationSchema = object().shape({
    user_name: string().required("User is required"),
    route_type: string().required("Route Type is required"),
    text_remark: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Remark is required"),
    credit_text: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Credit Text is required"),
    credit_type: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Credit Type is required"),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate;
    //   ? `rcs-template/update/${rowData.id}`
    //   : "rcs-template/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        user_name: payload?.user_name || "",
        is_variable: payload?.is_variable === true ? 1 : 0,
        route_type:
          payload?.route_type === SelectRoute[0]
            ? templateTypeData[0]
            : templateTypeData[1],
        credit_type: payload?.credit_type?.toLowerCase() || "",
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2} sx={{ border: "none", outline: "none", boxShadow: "none" }}>
      <Typography variant="h5">
        {isEdit ? "Edit" : "Add / Remove Credit"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          handleSubmit(values);
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 4 }}
              >
                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="p_name"
                    id="p_name"
                    label="Plan Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid> */}

                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="user_ID"
                    id="user_ID"
                    label="Select Username *"
                    multiple={false}
                    options={usersData || []}
                    getOptionLabel={(option) => option?.username || ""}
                    value={
                      usersData?.find((type) => type?.id === values?.user_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("user_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid> */}

                <Grid size={{ xs: 12, sm: 6, md: 6 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="user_name"
                    id="user_name"
                    label="Select Username *"
                    multiple={false}
                    // disableClearable={true}
                    options={UserName || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      UserName?.find((type) => type === values?.user_name) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("user_name", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 6 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="route_type"
                    id="route_type"
                    label="Select Route *"
                    multiple={false}
                    // disableClearable={true}
                    options={SelectRoute || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      SelectRoute?.find(
                        (type) => type === values?.route_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("route_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 6 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="credit_type"
                    id="credit_type"
                    label="Select Credit Type *"
                    multiple={false}
                    // disableClearable={true}
                    options={CreditType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      CreditType?.find(
                        (type) => type === values?.credit_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("credit_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 6 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="credit_text"
                    id="credit_text"
                    label="Credit *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 6 }}>
                  <Typography
                    variant="body1"
                    component="label"
                    htmlFor="text_remark"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    Remarks
                    <Typography component="span" sx={{ color: "red", ml: 0.5 }}>
                      *
                    </Typography>
                  </Typography>

                  <TextareaAutosize
                    name="text_remark"
                    id="text_remark"
                    aria-label="text_remark"
                    minRows={3.5}
                    placeholder="Type remark here."
                    value={values.text_remark}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "90%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "5px",
                    }}
                  />
                  {errors?.text_remark && touched?.text_remark && (
                    <FormHelperText error>{errors?.text_remark}</FormHelperText>
                  )}
                </Grid>

                {isEdit && (
                  <>
                    {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="isActive"
                        id="isActive"
                        label="Select Status"
                        multiple={false}
                        disableClearable={true}
                        options={Status || []}
                        getOptionLabel={(option) => option || ""}
                        value={
                          Status?.find((type) => type === values?.isActive) ||
                          Status[0]
                        }
                        isOptionEqualToValue={(option, value) =>
                          option === value
                        }
                        onChange={(e, value) => {
                          setFieldValue("isActive", value);
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Grid> */}
                  </>
                )}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditCreditsDetails;
