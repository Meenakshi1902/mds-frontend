import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import { useSelector } from "react-redux";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string, mixed } from "yup";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import {
  StatusType,
  fetchPostDropDownData,
  validationRegex,
  UserName,
} from "../../../../utils/common";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";

const AddSingleNumberBlock = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const isEdit = rowData && Object.keys(rowData).length > 0;

  const [activeTab, setActiveTab] = useState("single");

  const [usersData, setUsersData] = useState([]);
  const hasFetchedUsersDropdowns = useRef(false);

  const user = useSelector((state) => state?.auth?.user);

  //const shouldIncludeUserId = true;

  const shouldIncludeUserId = [2, 3, 4].includes(user?.role_ID);

  useEffect(() => {
    if (user?.role_ID === 1 || hasFetchedUsersDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);

  const initialValues = isEdit
    ? {
        ...rowData,
        file: null,
        user_ID: rowData?.user_ID || "",

        // ...(shouldIncludeUserId && {
        //   user_ID: rowData.user_ID || "",
        // }),
      }
    : {
        // ...(shouldIncludeUserId && {
        //   user_ID: "",
        // }),
        user_ID: "",
        status: "",
        mobile_number: "",
        file: null,
      };

  const validationSchema = object().shape({
    user_ID: string().when([], {
      is: () => shouldIncludeUserId,
      then: (schema) => schema.required("User ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    file: mixed()
      .required("File is required")
      .test("fileType", "Only CSV or Excel files are allowed", (value) => {
        if (!value) return false;
        const validTypes = [
          "text/csv",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-excel",
        ];
        return validTypes.includes(value.type);
      })
      .test("fileSize", "File must be less than 2 MB", (value) => {
        if (!value) return false;
        return value.size <= 2 * 1024 * 1024;
      }),

    ...(activeTab === "single"
      ? {
          mobile_number: string()
            .matches(
              validationRegex?.blankSpace,
              validationRegex?.blankSpacesMessage
            )
            .required("Mobile Number is required"),
        }
      : {}),
    status: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Status is required"),
    // username: string()
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .required("User Name is required"),
    // mobile_number: string()
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .required("Mobile Number is required"),
    // status: string()
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .required("Status is required"),

    // user_ID: string().when([], {
    //   is: () => shouldIncludeUserId,
    //   then: (schema) => schema.required("User ID is required"),
    //   otherwise: (schema) => schema.notRequired(),
    // }),
  });

  // const handleUploadFile = (formData, setFieldValue) => {
  //   postDocumentRequest(`upload-file`, formData, (response) => {
  //     if (!response?.data?.errors && response?.status === 200) {
  //       showSnackBar("success", "File uploaded successfully.");

  //       console.log("response file => ", response);
  //       setUploadFileData(response?.data);
  //       setFieldValue("to", response?.data?.to);

  //       const preview = response?.data?.preview;
  //       if (Array.isArray(preview) && preview.length > 1) {
  //         const [headerRow, ...dataRows] = preview;
  //         setColumns(headerRow);
  //         setFileData(dataRows);
  //       } else {
  //         setColumns([]);
  //         setFileData([]);
  //       }
  //     } else {
  //       const errors = response?.data?.errors || {};
  //       if (typeof errors === "string") {
  //         showSnackBar("error", errors);
  //       } else {
  //         Object.entries(errors).forEach(([field, messages]) => {
  //           showSnackBar("error", `${field}: ${messages.join(", ")}`);
  //         });
  //       }
  //     }
  //   });
  // };

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate ? `plans/update/${rowData.id}` : "plans/store?";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        // ...(shouldIncludeUserId && {
        //   user_ID: payload.user_ID || user?.id,
        // }),

        // ...(user?.role_ID === 1 &&
        //   user?.id && {
        //     user_ID: user?.id,
        //   }),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Plan Details" : "Add New List"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />

      <Grid item display="flex" mb={2}>
        <Button
          variant={activeTab === "single" ? "contained" : "outlined"}
          onClick={() => setActiveTab("single")}
          sx={{
            textTransform: "none",
            borderRadius: "4px",
            px: 3,
            py: 1,
            fontSize: "1rem",
            backgroundColor: activeTab === "single" ? "#1976d2" : "transparent",
            color: activeTab === "single" ? "#fff" : "#1976d2",
            border: "none",
            "&:focus": {
              outline: "none",
              boxShadow: "none",
            },
          }}
        >
          Single
        </Button>
        <Button
          variant={activeTab === "multiple" ? "contained" : "outlined"}
          onClick={() => setActiveTab("multiple")}
          sx={{
            textTransform: "none",
            borderRadius: "4px",
            px: 3,
            py: 1,
            fontSize: "1rem",
            backgroundColor:
              activeTab === "multiple" ? "#1976d2" : "transparent",
            color: activeTab === "multiple" ? "#fff" : "#1976d2",
            border: "none",
            "&:focus": {
              outline: "none",
              boxShadow: "none",
            },
            ml: 2,
          }}
        >
          Multiple
        </Button>
      </Grid>
      {/* added by me */}

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          setFieldError,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* {shouldIncludeUserId && (
                  <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                    <IconAutocompleteField
                      icon={PersonIcon}
                      name="user_ID"
                      id="user_ID"
                      label="Select User *"
                      multiple={false}
                      options={usersData || []}
                      getOptionLabel={(option) => option?.username || ""}
                      value={
                        usersData?.find(
                          (type) => type?.id === values?.user_ID
                        ) || null
                      }
                      isOptionEqualToValue={(option, value) =>
                        option?.id === value?.id
                      }
                      onChange={(e, value) => {
                        setFieldValue("user_ID", value?.id || "");
                      }}
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                )} */}

                {shouldIncludeUserId && (
                  <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                    <IconAutocompleteField
                      icon={PersonIcon}
                      name="user_ID"
                      id="user_ID"
                      label="Select User *"
                      multiple={false}
                      options={usersData || []}
                      getOptionLabel={(option) => option?.username || ""}
                      value={
                        usersData?.find(
                          (type) => type?.id === values?.user_ID
                        ) || null
                      }
                      isOptionEqualToValue={(option, value) =>
                        option?.id === value?.id
                      }
                      onChange={(e, value) => {
                        setFieldValue("user_ID", value?.id || "");
                      }}
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                )}

                {activeTab === "single" && (
                  <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="mobile_number"
                      id="mobile_number"
                      label="Mobile Number *"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                )}

                {activeTab === "multiple" && (
                  <Box>
                    <Typography variant="subtitle1" sx={{ mb: 1 }}>
                      Multiple Mobile Numbers:
                    </Typography>

                    <Button
                      variant="outlined"
                      component="label"
                      startIcon={<CloudUploadIcon />}
                      sx={{
                        borderRadius: "10rem",
                        textTransform: "none",
                        height: "40px",
                        width: "350px",
                        color: "#1976d2",
                        borderColor: "#1976d2",
                        "&:hover": {
                          color: "#FFFFFF",
                          backgroundColor: "#1976d2",
                        },
                      }}
                    >
                      Upload CSV File
                      <input
                        type="file"
                        hidden
                        accept=".csv, .xlsx"
                        onChange={(e) => {
                          const file = e.target.files[0];
                          if (file) {
                            setFieldValue("file", file);
                          }
                        }}
                      />
                    </Button>

                    {values.file && (
                      <Typography sx={{ mt: 1 }}>
                        Selected file: {values.file.name}
                      </Typography>
                    )}

                    {errors.file && touched.file && (
                      <Typography color="error" variant="caption">
                        {errors.file}
                      </Typography>
                    )}
                  </Box>
                )}

                <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="status"
                    id="status"
                    label="Select Status"
                    multiple={false}
                    disableClearable={true}
                    options={StatusType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      StatusType?.find((type) => type === values?.status) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("status", value);
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddSingleNumberBlock;
