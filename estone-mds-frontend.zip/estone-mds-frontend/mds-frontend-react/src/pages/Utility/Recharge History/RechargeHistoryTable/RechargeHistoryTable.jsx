import React, { useEffect, useMemo, useState } from "react";
import { deleteRequest, postRequest } from "../../../../helpers/http.helper";
import Table from "../../../../components/Table/Table";
import moment from "moment";
import DeleteIcon from "@mui/icons-material/Delete";
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  IconButton,
} from "@mui/material";
import EditTwoToneIcon from "@mui/icons-material/EditTwoTone";
import DeleteOutlineTwoToneIcon from "@mui/icons-material/DeleteOutlineTwoTone";
import SettingsSuggestOutlinedIcon from "@mui/icons-material/SettingsSuggestOutlined";
import { useSelector } from "react-redux";

const RechargeHistoryTable = ({
  openModal,
  setSelectedRowData,
  refreshTable,
  setRefreshTable,
  rowData,
  showSnackBar,
}) => {
  const user = useSelector((state) => state?.auth?.user);
  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [rowCount, setRowCount] = useState(0);
  const [rowSelection, setRowSelection] = useState({});
  const [globalFilter, setGlobalFilter] = useState("");
  const [debouncedGlobalFilter, setDebouncedGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [isDelete, setIsDelete] = useState(false);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });

  const handleDeleteClick = (row) => {
    setIsDelete(true);
    setSelectedRowData(row);
  };

  const handleClose = () => {
    setIsDelete(false);
    setSelectedRowData([]);
  };

  const deleteRecord = () => {
    // // Make the API request
    // deleteRequest(`users/delete/${rowData?.id}`, {}, (res) => {
    //   if (res?.data?.errors) {
    //     showSnackBar("error", res?.data?.errors);
    //   } else {
    //     showSnackBar("success", res?.data?.message);
    //   }
    //   // Refresh table and close the modal
    //   handleClose();
    //   setRefreshTable(true);
    // });
  };

  const fetchData = () => {
    setIsLoading(false);
  };

  const columns = useMemo(() => [
    {
      accessorKey: "created_at",
      accessorFn: (row) => {
        const rawDate = row?.created_at?.split("T")[0];
        return rawDate ? moment(rawDate).format("DD/MM/YYYY") : "";
      },
      header: "Date",
      size: 100,
      Cell: ({ row }) => {
        return (
          <>
            {row?.original?.created_at
              ? moment(row?.original?.created_at?.split("T")[0]).format(
                  "DD/MM/YYYY"
                )
              : null}
          </>
        );
      },
    },
    {
      accessorKey: "username",
      header: "Username",
      size: 100,
    },
    {
      accessorKey: "r_type",
      header: "Route Type",
      size: 100,
    },
    {
      accessorKey: "c_type",
      header: "Credit Type",
      size: 100,
    },
    // {
    //   accessorKey: "route_IDs",
    //   // accessorFn used to we can text copy and paste on searchinput
    //   accessorFn: (row) =>
    //     row?.route_IDs_List?.map((route) => route?.route_name).join(", ") || "",
    //   header: "Route(Bal)",
    //   size: 100,
    //   sortDescFirst: false,
    //   Cell: ({ row }) => {
    //     const route_IDs_List = row?.original?.route_IDs_List
    //       ?.map((route) => route?.route_name)
    //       .join(", ");
    //     return <>{route_IDs_List}</>;
    //   },
    // },
    {
      accessorKey: "add_bal",
      header: "Added Bal.",
      size: 100,
    },
    {
      accessorKey: "new_bal",
      header: "New Bal.",
      size: 100,
    },
    {
      accessorKey: "remark",
      header: "Remark",
      size: 100,
    },

    // {
    //   accessorKey: "actions",
    //   header: "Action",
    //   size: 150,
    //   enableSorting: false,
    //   Cell: ({ row }) => {
    //     return (
    //       <Box sx={{ display: "flex", gap: "8px", alignItems: "center" }}>
    //         <Button
    //           variant="outlined"
    //           sx={{
    //             minWidth: "36px",
    //             height: "36px",
    //             padding: 0,
    //             // borderColor: "#A780FF",
    //             borderColor: "#1976d2",
    //             color: "#1976d2",
    //             borderRadius: "6px",
    //             "&:hover": {
    //               borderColor: "#1976d2",
    //               backgroundColor: "transparent", // optional: prevent gray hover background
    //             },
    //             "&:focus": {
    //               outline: "none",
    //               borderColor: "#1976d2",
    //             },
    //             "&:active": {
    //               borderColor: "#1976d2",
    //             },
    //           }}
    //           onClick={() => {
    //             setSelectedRowData(row.original);
    //             openModal("usermodal");
    //           }}
    //         >
    //           <EditIcon fontSize="small" />
    //         </Button>

    //         <Button
    //           variant="outlined"
    //           sx={{
    //             minWidth: "36px",
    //             height: "36px",
    //             padding: 0,
    //             borderColor: "#1976d2",
    //             color: "#1976d2",
    //             borderRadius: "6px",
    //             "&:hover": {
    //               borderColor: "#1976d2",
    //               backgroundColor: "transparent",
    //             },
    //             "&:focus": {
    //               outline: "none",
    //               borderColor: "#1976d2",
    //             },
    //             "&:active": {
    //               borderColor: "#1976d2",
    //             },
    //           }}
    //           onClick={() => handleDeleteClick(row.original)}
    //         >
    //           <DeleteIcon fontSize="small" />
    //         </Button>

    //         <Button
    //           variant="outlined"
    //           sx={{
    //             minWidth: "36px",
    //             height: "36px",
    //             padding: 0,
    //             borderColor: "#1976d2",
    //             color: "#1976d2",
    //             borderRadius: "6px",
    //             "&:hover": {
    //               borderColor: "#1976d2",
    //               backgroundColor: "transparent",
    //             },
    //             "&:focus": {
    //               outline: "none",
    //               borderColor: "#1976d2",
    //             },
    //             "&:active": {
    //               borderColor: "#1976d2",
    //             },
    //           }}
    //           // onClick={() => handleDeleteClick(row.original)}
    //           onClick={() => {
    //             setSelectedRowData(row.original);
    //             openModal("settingmodal");
    //           }}
    //         >
    //           <SettingsApplicationsIcon fontSize="small" />
    //         </Button>
    //       </Box>
    //     );
    //   },
    // },
  ]);

  useEffect(() => {
    fetchData();
  }, [pagination.pageIndex, pagination.pageSize, sorting, globalFilter]);

  //   useEffect(() => {
  //     if (refreshTable) {
  //       fetchData();
  //       setRefreshTable(false);
  //     }
  //   }, [refreshTable]);

  // const toolbarButtons = [
  //   {
  //     variant: "customcreate",
  //     sx: {
  //       textTransform: "none",
  //       // backgroundColor: "#1976d2",
  //       backgroundColor: "#2c7be5",
  //       color: "#ffffff",
  //       boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
  //       borderRadius: "8px",
  //       "&:hover": {
  //         backgroundColor: "#4DA8DA",
  //       },
  //     },
  //     color: "primary",
  //     startIcon: <AddIcon />,
  //     onClick: () => openModal("usermodal"),
  //     label: "Add User",
  //   },
  // ];

  const rowActionItems = [
    // {
    //   icon: <EditTwoToneIcon fontSize="small" />,
    //   label: "Edit",
    //   onClick: (row) => {
    //     setSelectedRowData(row);
    //     openModal("usermodal");
    //   },
    // },
    // {
    //   icon: <DeleteOutlineTwoToneIcon fontSize="small" />,
    //   label: "Delete",
    //   onClick: (row) => {
    //     handleDeleteClick(row);
    //   },
    // },
    // {
    //   icon: <SettingsSuggestOutlinedIcon fontSize="small" />,
    //   label: "Setting",
    //   onClick: (row) => {
    //     // handleDeleteClick(row);
    //     setSelectedRowData(row);
    //     openModal("settingmodal");
    //   },
    // },
  ];

  useEffect(() => {
    const handler = setTimeout(() => {
      setGlobalFilter(debouncedGlobalFilter);
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [debouncedGlobalFilter]);

  const states = {
    enableRowSelection: false,
    manualSorting: true, // true if server side sorting
    // enableRowActions: !viewMode,
    manualFiltering: true, // true if server side filtering

    enableRowActions: false, // Set this to false
  };

  return (
    <>
      <Table
        columns={columns}
        data={data}
        isLoading={isLoading}
        rowSelection={rowSelection}
        setRowSelection={setRowSelection}
        globalFilter={debouncedGlobalFilter}
        setGlobalFilter={setDebouncedGlobalFilter}
        sorting={sorting}
        setSorting={setSorting}
        pagination={pagination}
        setPagination={setPagination}
        rowCount={rowCount}
        // toolbarButtons={toolbarButtons}
        rowActionItems={rowActionItems}
        states={states}
      />

      <Dialog
        open={isDelete}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title" sx={{ fontWeight: "bold" }}>
          <DeleteIcon sx={{ position: "relative", top: "4px" }} />
          Delete
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to delete this record?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button variant="customhover" color="gray" onClick={handleClose}>
            Discard
          </Button>
          <Button
            variant="customwarning"
            color="#eb071e"
            onClick={deleteRecord}
          >
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default RechargeHistoryTable;
