import React, { useState } from "react";
import { Box, Button, Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../../../utils/common";
import SnackbarAlert from "../../../../components/SnackBarMessage/SnackbarAlert";
import RechargeHistoryTable from "../RechargeHistoryTable/RechargeHistoryTable";
import SelfRechargeHistoryTable from "../RechargeHistoryTable/SelfRechargeHistoryTable";

const RechargeHistoryDetails = () => {
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [selectedRowData, setSelectedRowData] = useState({});
  const [refreshTable, setRefreshTable] = useState(false);
  const [activeTab, setActiveTab] = useState("others");

  const openModal = (type) => setEnableAddForm(type);

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  return (
    <>
      <Grid
        container
        display="flex"
        justifyContent="space-between"
        flexDirection="row"
        px={2}
        py={2}
      >
        <Grid display="flex" justifyContent="flex-start">
          <Typography
            variant="h5"
            noWrap
            sx={{
              paddingLeft: "15px",
              fontWeight: 700,
            }}
          >
            Recharge History
          </Typography>
        </Grid>

        {/* Right: Tab buttons : others & self */}
        <Grid item display="flex">
          {/* Others Button */}
          <Button
            variant={activeTab === "others" ? "contained" : "outlined"}
            onClick={() => setActiveTab("others")}
            sx={{
              textTransform: "none",
              borderRadius: "4px",
              px: 3,
              py: 1,
              fontSize: "1rem",
              backgroundColor:
                activeTab === "others" ? "#1976d2" : "transparent",
              color: activeTab === "others" ? "#fff" : "#1976d2",
              border: "none",
              "&:focus": {
                outline: "none",
                boxShadow: "none",
              },
            }}
          >
            Others
          </Button>

          {/* Self Button */}
          <Button
            variant={activeTab === "self" ? "contained" : "outlined"}
            onClick={() => setActiveTab("self")}
            sx={{
              textTransform: "none",
              borderRadius: "4px",
              px: 3,
              py: 1,
              fontSize: "1rem",
              backgroundColor: activeTab === "self" ? "#1976d2" : "transparent",
              color: activeTab === "self" ? "#fff" : "#1976d2",
              border: "none",
              "&:focus": {
                outline: "none",
                boxShadow: "none",
              },
            }}
          >
            Self
          </Button>
        </Grid>
      </Grid>

      <Box sx={{ mt: "10px", position: "relative", minHeight: "300px" }}>
        {activeTab === "others" ? (
          <RechargeHistoryTable
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            refreshTable={refreshTable}
            setRefreshTable={setRefreshTable}
            showSnackBar={showSnackBar}
            openModal={openModal}
          />
        ) : (
          <SelfRechargeHistoryTable
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            refreshTable={refreshTable}
            setRefreshTable={setRefreshTable}
            showSnackBar={showSnackBar}
            openModal={openModal}
          />
        )}
      </Box>

      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default RechargeHistoryDetails;
