import React from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  FormHelperText,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import { validationRegex } from "../../../../utils/common";

const AddEditVoiceGateway = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  console.log("rowData => ", rowData);
  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        gateway_name: rowData.gateway_name || "",
        end_point: rowData.end_point || "",
      }
    : {
        gateway_name: "",
        end_point: "",
      };

  const validationSchema = object().shape({
    gateway_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Gateway Name is required"),
    end_point: string()
      .url("Invalid Url Format")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("End Point is required"),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `voice-gateway/update/${rowData.id}`
      : "voice-gateway/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Voice Gateway Details" : "Add Voice Gateway Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          handleChange,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }} sx={{ mt: 0.5 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="gateway_name"
                    id="gateway_name"
                    label="Gateway Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="end_point"
                    id="end_point"
                    label="End Point *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid> */}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Typography
                    variant="body1"
                    component="label"
                    htmlFor="end_point"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    End Point
                    <Typography component="span" sx={{ color: "red", ml: 0.5 }}>
                      *
                    </Typography>
                  </Typography>

                  <TextareaAutosize
                    name="end_point"
                    id="end_point"
                    aria-label="end_point"
                    minRows={3}
                    placeholder="Type End Point"
                    value={values.end_point}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                  />
                  {errors?.end_point && touched?.end_point && (
                    <FormHelperText error>{errors?.end_point}</FormHelperText>
                  )}
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditVoiceGateway;
