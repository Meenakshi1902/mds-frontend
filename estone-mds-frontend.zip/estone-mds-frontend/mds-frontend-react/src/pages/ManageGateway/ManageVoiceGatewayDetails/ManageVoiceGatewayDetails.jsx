import React, { useState } from "react";
import { Box, Button, Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../../utils/common";
import SnackbarAlert from "../../../components/SnackBarMessage/SnackbarAlert";
import ModalComponent from "../../../components/ModalComponent/ModalComponent";
import VoiceGatewayTable from "./VoiceGatewayTable/VoiceGatewayTable";
import AddEditVoiceGateway from "./AddEditVoiceGateway/AddEditVoiceGateway";
import AddIcon from "@mui/icons-material/Add";

const ManageVoiceGatewayDetails = () => {
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [selectedRowData, setSelectedRowData] = useState({});
  const [refreshTable, setRefreshTable] = useState(false);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      setSelectedRowData([]);
    }
  };

  const openModal = (type) => {
    setEnableAddForm(type);
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      {/* Header with title and add button */}
      <Grid
        container
        display="flex"
        justifyContent="space-between"
        flexDirection="row"
      >
        <Grid display="flex" justifyContent="flex-start">
          <Typography
            variant="h5"
            noWrap
            sx={{
              paddingLeft: "15px",
              fontWeight: 700,
            }}
          >
            Voice Gateway Details
          </Typography>
        </Grid>
        <Grid display="flex" justifyContent="flex-end">
          <Button
            variant="contained"
            onClick={() => openModal("voicemodal")}
            startIcon={<AddIcon />}
            sx={{
              textTransform: "none",
              backgroundColor: "#1976d2",
              color: "#ffffff",
              boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
              borderRadius: "8px",
              outline: "none",
              "&:hover": {
                backgroundColor: "#4DA8DA",
                boxShadow: "0px 6px 10px rgba(0, 0, 0, 0.15)",
              },
              "&:focus": {
                outline: "none",
                boxShadow: "none",
              },
              "&:active": {
                outline: "none",
                boxShadow: "none",
              },
            }}
          >
            Add Voice Gateway
          </Button>
        </Grid>
      </Grid>
      <ModalComponent
        style={style}
        closeModal={closeModal}
        enableAddForm={enableAddForm}
      >
        {enableAddForm && enableAddForm === "voicemodal" && (
          <AddEditVoiceGateway
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
      </ModalComponent>

      <Box px={2} pb={2}>
        <Grid>
          <Box sx={{ mt: "10px" }}>
            <VoiceGatewayTable
              rowData={selectedRowData}
              setSelectedRowData={setSelectedRowData}
              refreshTable={refreshTable}
              setRefreshTable={setRefreshTable}
              showSnackBar={showSnackBar}
              openModal={openModal}
            />
          </Box>
        </Grid>
      </Box>
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default ManageVoiceGatewayDetails;
