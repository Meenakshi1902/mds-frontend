import React from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  gatewayType,
  locateType,
  Status,
  validationRegex,
} from "../../../../utils/common";

const AddEditSmsGateway = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        gateway_name: rowData?.gateway_name || "",
        system_type: rowData?.system_type || "",
        username: rowData?.username || "",
        password: rowData?.password || "",
        allowed_smsc_ID: rowData?.allowed_smsc_ID || "",
        locate_ID: rowData?.locate_ID || "",
        host: rowData?.host || "",
        port: rowData?.port || "",
        tx_mode: rowData?.tx_mode || "",
        instances: rowData?.instances || "",
        enquiry_interval: rowData?.enquiry_interval || "",
        charset: rowData?.charset || "",
        source_ton: rowData?.source_ton,
        source_npi: rowData?.source_npi || "",
        destination_ton: rowData?.destination_ton,
        destination_npi: rowData?.destination_npi || "",
        max_pending: rowData?.max_pending || "",
        gateway_type_ID:
          rowData?.gateway_type_ID === 1 ? "Direct" : "In-Direct" || "",
        // isActive: rowData?.isActive === true ? "Active" : "Inactive" || "",
        isActive: rowData.isActive === true ? Status[0] : Status[1],
      }
    : {
        gateway_name: "",
        system_type: "",
        username: "",
        password: "",
        allowed_smsc_ID: "",
        locate_ID: "",
        host: "",
        port: "",
        tx_mode: "",
        instances: "",
        enquiry_interval: "",
        charset: "",
        source_ton: "",
        source_npi: "",
        destination_ton: "",
        destination_npi: "",
        max_pending: "",
        gateway_type_ID: "",
        isActive: Status[0],
      };

  const validationSchema = object().shape({
    gateway_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Gateway Name is required"),
    system_type: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("System Type is required"),
    username: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("UserName is required"),
    // password: string()
    //   .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
    //   .required("Password is required"),
    password: string()
      .required("Password is Required")
      .when([], {
        is: (value) => typeof value === "string" && value.length <= 10,
        then: (schema) =>
          schema
            .min(8, "Password must be at least 8 characters")
            .max(10, "Password cannot be more than 10 characters")
            .matches(
              validationRegex?.password,
              "Password must include letters, numbers, and special characters"
            ),
        otherwise: (schema) =>
          schema.test(
            "is-invalid",
            "Password must be a string and at most 10 characters",
            (val) => typeof val === "string" && val.length <= 10
          ),
      }),
    allowed_smsc_ID: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(
        validationRegex?.alphnumberic,
        "Only alphabetic or numeric characters are allowed"
      )
      .required("Allowed SMSC ID is required"),
    locate_ID: string().required("Locate ID is required"),
    host: string()
      .matches(
        /^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)(?:\.|$)){4}$/,
        "Host must be a valid IP address (e.g. 0.0.0.0"
      )
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Host is required"),

    port: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Port is required"),
    tx_mode: string()
      .matches(
        validationRegex?.onlyLetters,
        "Tx Mode must contain only letters"
      )
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Tx Mode is required"),
    instances: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Instances is required"),
    enquiry_interval: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Enquiry Interval is required"),
    charset: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(
        validationRegex?.onlyLetters,
        "The charset field must only contain letters"
      )
      .required("Charset is required"),
    source_ton: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Source Ton is required"),
    source_npi: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Source Npi is required"),
    destination_ton: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Destination Ton is required"),
    destination_npi: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Destination Npi is required"),
    max_pending: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed")
      .required("Max Pending is required"),
    gateway_type_ID: string().required("Gateway Type ID is required"),
    isActive: string().required("Status is required"),
  });

  const handleSubmit = (payload) => {
    // console.log("payload", payload);
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `sms-gateway/update/${rowData.id}`
      : "sms-gateway/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        user_ID: user?.id || rowData.user_ID,
        gateway_type_ID: payload.gateway_type_ID === "Direct" ? 1 : 0,
        isActive: payload?.isActive === "Active" ? 1 : 0,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit SMS Gateway Details" : "Add SMS Gateway Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="gateway_name"
                    id="gateway_name"
                    label="Gateway Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="system_type"
                    id="system_type"
                    label="System Type *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="username"
                    id="username"
                    label="User Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="password"
                    id="password"
                    label="Password *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="allowed_smsc_ID"
                    id="allowed_smsc_ID"
                    label="Allowed SMSC ID *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                    disabled={isEdit ? true : false}
                  />
                </Grid>

                {/* Dropdown */}
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="locate_ID"
                    id="locate_ID"
                    label="Select Locate *"
                    multiple={false}
                    options={locateType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      locateType?.find((type) => type === values?.locate_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("locate_ID", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="host"
                    id="host"
                    label="Host *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="port"
                    id="port"
                    label="Port *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="tx_mode"
                    id="tx_mode"
                    label="TX Mode *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="instances"
                    id="instances"
                    label="Instances *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="enquiry_interval"
                    id="enquiry_interval"
                    label="Enquiry Interval *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="charset"
                    id="charset"
                    label="Charset *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="source_ton"
                    id="source_ton"
                    label="Source Ton *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="source_npi"
                    id="source_npi"
                    label="Source NPI *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="destination_ton"
                    id="destination_ton"
                    label="Destination Ton *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="destination_npi"
                    id="destination_npi"
                    label="Destination NPI *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="max_pending"
                    id="max_pending"
                    label="Max Pending *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="isActive"
                    id="isActive"
                    label="Select Status"
                    multiple={false}
                    disableClearable={true}
                    options={Status || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      Status?.find((type) => type === values?.isActive) ||
                      Status[0]
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("isActive", value);
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="gateway_type_ID"
                    id="gateway_type_ID"
                    label="Select Gateway *"
                    multiple={false}
                    options={gatewayType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      gatewayType?.find(
                        (type) => type === values?.gateway_type_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("gateway_type_ID", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditSmsGateway;
