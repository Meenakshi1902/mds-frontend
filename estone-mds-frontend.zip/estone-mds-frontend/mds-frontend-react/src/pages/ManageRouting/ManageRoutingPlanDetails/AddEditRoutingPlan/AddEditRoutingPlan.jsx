import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { array, mixed, object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  fetchGetDropDownData,
  fetchPostDropDownData,
  Status,
  transformMultipleIdForEdit,
} from "../../../../utils/common";
import CheckboxInputAutocompleteField from "../../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";

const AddEditRoutingPlan = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);
  const [planDetails, setPlanDetails] = useState([]);
  const [routeDropdown, setRouteDropdown] = useState([]);
  const [smsGatewayData, setSmsGatewayData] = useState([]);
  const hasFetchedPlansDropdowns = useRef(false);
  const hasFetchedManageRoutes = useRef(false);
  const hasFetchedGateway = useRef(false);

  const [gatewayAutocompleteOpen, setGatewayAutocompleteOpen] = useState(false);

  useEffect(() => {
    if (!user?.id || hasFetchedPlansDropdowns.current) return;
    const payload = {
      start: "",
      limit: "",
      search_text: "",
      sorting: "",
      order_by: "",
    };
    fetchPostDropDownData(`plans`, payload, setPlanDetails, showSnackBar);
    hasFetchedPlansDropdowns.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id || hasFetchedManageRoutes.current) return;
    const payload = {
      start: "",
      limit: "",
      search_text: "",
      sorting: "",
      order_by: "",
    };
    fetchPostDropDownData(
      `manage-route`,
      payload,
      setRouteDropdown,
      showSnackBar
    );
    hasFetchedManageRoutes.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id || hasFetchedGateway.current) return;
    fetchGetDropDownData(
      `error-code/gatewaysForDropdown`,
      setSmsGatewayData,
      showSnackBar
    );
    hasFetchedGateway.current = true;
  }, [user?.id]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        plan_ID: rowData?.plan_ID || "",
        route_ID: rowData?.route_ID || "",
        gateway_ID: transformMultipleIdForEdit(rowData?.gateway_ID) || "",
        isActive: rowData.isActive === 1 ? Status[0] : Status[1],
      }
    : {
        plan_ID: "",
        route_ID: "",
        gateway_ID: "",
        isActive: Status[0],
      };

  const validationSchema = object().shape({
    plan_ID: string().required("Plan is required"),
    route_ID: string().required("Route is required"),
    gateway_ID: array()
      .of(
        object().shape({
          id: mixed().required("Gateway ID is required"),
        })
      )
      .min(1, "At least one Gateway ID is required")
      .required("Gateway ID is required"),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `routing-plan/update/${rowData.id}`
      : "routing-plan/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        gateway_ID: payload?.gateway_ID?.map((item) => item?.id),
        isActive: payload?.isActive === "Active" ? 1 : 0,
        traffic_per: 1,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Routing Plan Details" : "Add Routing Plan Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* for this dropdown i think we need to bind api for now i used static */}
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="plan_ID"
                    id="plan_ID"
                    label="Plan Name *"
                    multiple={false}
                    options={planDetails || []}
                    getOptionLabel={(option) => option?.p_name || ""}
                    value={
                      planDetails?.find(
                        (type) => type?.id === values?.plan_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("plan_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="route_ID"
                    id="route_ID"
                    label="Select Route *"
                    multiple={false}
                    options={routeDropdown || []}
                    getOptionLabel={(option) => option?.route_name || ""}
                    value={
                      routeDropdown?.find(
                        (type) => type?.id === values?.route_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("route_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <CheckboxInputAutocompleteField
                    icon={PersonIcon}
                    id="gateway_ID"
                    name="gateway_ID"
                    label="Select Gateway *"
                    options={smsGatewayData || []}
                    getOptionLabel={(option) => option?.gateway_name}
                    getOptionValue={(option) => option?.id} // How to get the ID value
                    getDisplayValue={(option) => option?.gateway_name} // What to display in checkbox list
                    value={values?.gateway_ID}
                    setFieldValue={setFieldValue}
                    handleBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    autoCompleteOpen={gatewayAutocompleteOpen}
                    setAutoCompleteOpen={setGatewayAutocompleteOpen}
                  />
                </Grid>

                {isEdit && (
                  <>
                    <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="isActive"
                        id="isActive"
                        label="Select Status"
                        multiple={false}
                        disableClearable={true}
                        options={Status || []}
                        getOptionLabel={(option) => option || ""}
                        value={
                          Status?.find((type) => type === values?.isActive) ||
                          Status[0]
                        }
                        isOptionEqualToValue={(option, value) =>
                          option === value
                        }
                        onChange={(e, value) => {
                          setFieldValue("isActive", value);
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Grid>
                  </>
                )}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditRoutingPlan;
