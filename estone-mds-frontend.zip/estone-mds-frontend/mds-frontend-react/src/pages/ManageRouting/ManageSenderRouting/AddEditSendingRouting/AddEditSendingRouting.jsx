import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { array, mixed, object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import PersonIcon from "@mui/icons-material/Person";
import CheckboxInputAutocompleteField from "../../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";
import {
  fetchGetDropDownData,
  fetchPostDropDownData,
  Status,
  transformMultipleIdForEdit,
} from "../../../../utils/common";

const AddEditSendingRouting = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const user = useSelector((state) => state?.auth?.user);
  const [usersData, setUsersData] = useState([]);
  const [senders, setSenders] = useState([]);
  const [smsGatewayData, setSmsGatewayData] = useState([]);
  const hasFetchedUserDropdowns = useRef(false);
  const hasFetchedSendersDropdowns = useRef(false);
  const hasFetchedGateway = useRef(false);
  const [gatewayAutocompleteOpen, setGatewayAutocompleteOpen] = useState(false);
  const [isUserId, setUserId] = useState("");

  useEffect(() => {
    if (!user?.id || hasFetchedUserDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUserDropdowns.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (!isUserId) return;
    const payload = { id: isUserId || "" };
    fetchPostDropDownData(
      `template-details/getSenders`,
      payload,
      setSenders,
      showSnackBar
    );
  }, [isUserId]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        sender_ID: rowData?.sender_ID || "",
        user_ID: rowData?.user_ID || "",
        gateway_ID: transformMultipleIdForEdit(rowData?.gateway_ID) || "",
        isActive: rowData.isActive === 1 ? Status[0] : Status[1],
      }
    : {
        sender_ID: "",
        user_ID: "",
        gateway_ID: "",
        isActive: Status[0],
      };

  useEffect(() => {
    if ((!isEdit && !rowData?.user_ID) || hasFetchedSendersDropdowns.current)
      return;

    const payload = { id: rowData.user_ID };
    fetchPostDropDownData(
      "template-details/getSenders",
      payload,
      setSenders,
      showSnackBar
    );
    hasFetchedSendersDropdowns.current = true;
  }, [isEdit, rowData?.user_ID]);

  const validationSchema = object().shape({
    sender_ID: string().required("Sender ID is required"),
    // sender_ID: string().when("user_ID", {
    //   is: (user_ID) => !!user_ID, // If user_ID has value
    //   then: string().required("Sender ID is required"),
    //   otherwise: string().required("Please select sender id."),
    // }),
    gateway_ID: array()
      .of(
        object().shape({
          id: mixed().required("Gateway ID is required"),
        })
      )
      .min(1, "At least one Gateway ID is required")
      .required("Gateway ID is required"),
    user_ID: string().required("User ID is required"),
  });

  useEffect(() => {
    if (!user?.id || hasFetchedGateway.current) return;
    fetchGetDropDownData(
      `error-code/gatewaysForDropdown`,
      setSmsGatewayData,
      showSnackBar
    );
    hasFetchedGateway.current = true;
  }, [user?.id]);

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `sender-routing/update/${rowData.id}`
      : "sender-routing/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        gateway_ID: payload?.gateway_ID?.map((item) => item?.id),
        isActive: payload?.isActive === "Active" ? 1 : 0,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
          closeModal();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Sender Routing Details" : "Add Sender Routing Details"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("formValues => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="user_ID"
                    id="user_ID"
                    label="Select User *"
                    multiple={false}
                    options={usersData || []}
                    getOptionLabel={(option) => option?.username || ""}
                    value={
                      usersData?.find((type) => type?.id === values?.user_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("sender_ID", "");

                      const userId = value?.id || "";
                      if (userId) {
                        setFieldValue("user_ID", userId);
                        setUserId(userId);
                      } else {
                        setFieldValue("sender_ID", "");
                      }
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="sender_ID"
                    id="sender_ID"
                    label="Select Sender ID *"
                    multiple={false}
                    options={senders || []}
                    getOptionLabel={(option) => option?.sender_ID || ""}
                    value={
                      senders?.find((type) => type?.id === values?.sender_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("sender_ID", value?.id || "");
                    }}
                    disabled={values?.user_ID ? false : true}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <CheckboxInputAutocompleteField
                    icon={PersonIcon}
                    id="gateway_ID"
                    name="gateway_ID"
                    label="Select Gateway *"
                    options={smsGatewayData || []}
                    getOptionLabel={(option) => option?.gateway_name}
                    getOptionValue={(option) => option?.id} // How to get the ID value
                    getDisplayValue={(option) => option?.gateway_name} // What to display in checkbox list
                    value={values?.gateway_ID}
                    setFieldValue={setFieldValue}
                    handleBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    autoCompleteOpen={gatewayAutocompleteOpen}
                    setAutoCompleteOpen={setGatewayAutocompleteOpen}
                  />
                </Grid>

                {isEdit && (
                  <>
                    <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="isActive"
                        id="isActive"
                        label="Select Status"
                        multiple={false}
                        disableClearable={true}
                        options={Status || []}
                        getOptionLabel={(option) => option || ""}
                        value={
                          Status?.find((type) => type === values?.isActive) ||
                          Status[0]
                        }
                        isOptionEqualToValue={(option, value) =>
                          option === value
                        }
                        onChange={(e, value) => {
                          setFieldValue("isActive", value);
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Grid>
                  </>
                )}

                {/* Multiple Select */}
                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <CheckboxInputAutocompleteField
                    icon={PersonIcon}
                    id="gateway_ID"
                    name="gateway_ID"
                    label="Select Gateway *"
                    options={smsGatewayData || []}
                    getOptionLabel={(option) => option?.gateway_name}
                    getOptionValue={(option) => option?.id} // How to get the ID value
                    getDisplayValue={(option) => option?.gateway_name} // What to display in checkbox list
                    value={values?.gateway_ID}
                    setFieldValue={setFieldValue}
                    handleBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    autoCompleteOpen={gatewayAutocompleteOpen}
                    setAutoCompleteOpen={setGatewayAutocompleteOpen}
                  />
                </Grid> */}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditSendingRouting;
