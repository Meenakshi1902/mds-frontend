import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import {
  getRequest,
  postRequest,
  putRequest,
} from "../../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../../components/IconInputField/IconInputField";
import AddIcon from "@mui/icons-material/Add";

const APIKeyTMIDForm = ({
  setRefreshTable,
  // rowData,
  showSnackBar,
  closeModal,
  apiKeyData,
  FetchApiKeyData,
}) => {
  // const [apiKeyData, setApiKeyData] = useState([]);
  // const hasFetchedApiKeyData = useRef(false);

  const generateApiKey = () => {
    const characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    const length = 12;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(
        Math.floor(Math.random() * characters.length)
      );
    }
    return result;
  };

  // const [apiKeyData, setApiKeyData] = useState([]);
  // const hasFetchedApiKeyData = useRef(false);
  // const FetchApiKeyData = () => {
  //   getRequest("user-profile", function (response) {
  //     console.log("response => ", response?.data?.data);
  //     if (!response?.data?.errors && response?.data?.data) {
  //       setApiKeyData(response?.data?.data);
  //     } else {
  //       // Handling error messages
  //       const errors = response?.data?.errors || {};

  //       if (typeof errors === "string") {
  //         showSnackBar("error", errors);
  //       } else if (typeof errors === "object") {
  //         const mappedErrors = Object.entries(errors).map(
  //           ([field, errorMessages]) => {
  //             return {
  //               field,
  //               message: errorMessages.join(", "),
  //             };
  //           }
  //         );

  //         mappedErrors.forEach(({ field, message }) => {
  //           showSnackBar("error", `${field}: ${message}`);
  //         });
  //       }
  //       setApiKeyData([]);
  //     }
  //   });
  // };

  // useEffect(() => {
  //   if (hasFetchedApiKeyData.current) return;
  //   FetchApiKeyData();
  //   hasFetchedApiKeyData.current = true;
  // }, []);

  // const initialValues = {
  //   api_key: generateApiKey() || apiKeyData?.api_key,
  // };

  const initialValues = apiKeyData
    ? {
        api_key: apiKeyData?.api_key || "",
      }
    : {
        // api_key: generateApiKey(),
        api_key: "",
      };
  const validationSchema = object().shape({
    api_key: string().notRequired(),
  });

  const handleSubmit = (payload, setFieldValue) => {
    setFieldValue("api_key", payload.api_key);
    // setKeyData(payload.api_key);

    putRequest(
      `user-setting/updateApiKey`,
      {
        ...payload,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          // setRefreshTable(true);
          showSnackBar("success", response.data.message);
          FetchApiKeyData();
          // resetForm();
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    // closeModal();
  };

  return (
    <Box px={2}>
      {/* <Typography variant="h5">
        {isEdit ? "Edit Plan Details" : "Create Plan Details"}
      </Typography> */}
      {/* <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} /> */}
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Box display="flex" alignItems="center" gap={2}>
                {/* Fixed width input field */}
                <Box width="300px">
                  <IconInputField
                    icon={PersonIcon}
                    name="api_key"
                    id="api_key"
                    label="Api key"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                    disabled={true}
                  />
                </Box>

                {/* Generate Button */}
                <Button
                  startIcon={<AddIcon />}
                  onClick={() => setFieldValue("api_key", generateApiKey())}
                  sx={{
                    textTransform: "none",
                    backgroundColor: "#1976d2",
                    color: "#ffffff",
                    boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                    borderRadius: "8px",
                    "&:hover": {
                      backgroundColor: "#4DA8DA",
                    },
                  }}
                  variant="contained"
                  color="primary"
                >
                  Generate
                </Button>

                {/* Update Button + Loader */}
                <Box display="flex" alignItems="center" gap={1}>
                  <Button
                    sx={{
                      textTransform: "none",
                      backgroundColor: "#1976d2",
                      color: "#ffffff",
                      boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                      borderRadius: "8px",
                      "&:hover": {
                        backgroundColor: "#4DA8DA",
                      },
                    }}
                    variant="contained"
                    color="primary"
                    type="submit"
                    onClick={() => handleSubmit(values, setFieldValue)}
                    disabled={values?.api_key ? false : true}
                  >
                    Update
                  </Button>
                  {isSubmitting && <CircularProgress size={24} />}
                </Box>
              </Box>
              {/* <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box> */}
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default APIKeyTMIDForm;
