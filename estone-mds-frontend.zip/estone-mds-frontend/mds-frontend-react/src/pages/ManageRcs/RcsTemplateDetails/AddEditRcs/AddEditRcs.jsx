import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  FormControlLabel,
  Checkbox,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest, putRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import {
  botType,
  fetchGetDropDownData,
  fetchPostDropDownData,
  Status,
  templateType,
  templateTypeData,
  validationRegex,
} from "../../../../utils/common";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import { useSelector } from "react-redux";

const AddEditRcs = ({ setRefreshTable, rowData, showSnackBar, closeModal }) => {
  const user = useSelector((state) => state?.auth?.user);
  const hasFetchedUsersDropdowns = useRef(false);
  const hasFetchedGatewayDropdowns = useRef(false);
  const [usersData, setUsersData] = useState([]);
  const [RcsGatewayData, setRcsGatewayData] = useState([]);

  useEffect(() => {
    if (hasFetchedUsersDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (hasFetchedGatewayDropdowns.current) return;
    fetchGetDropDownData(
      `rcs-gateway/gatewaysForDropdown`,
      setRcsGatewayData,
      showSnackBar
    );
    hasFetchedGatewayDropdowns.current = true;
  }, [user?.id]);

  const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = isEdit
    ? {
        ...rowData,
        user_ID: rowData?.user_ID || "",
        template_type:
          rowData?.template_type === templateTypeData[0]
            ? templateType[0]
            : templateType[1],
        is_variable: rowData?.is_variable === 1 ? true : false,
        template_name: rowData?.template_name || "",
        template_text: rowData?.template_text || "",
        bot_type:
          botType.find((type) => type.toLowerCase() === rowData?.bot_type) ||
          "",
        gateway_ID: rowData?.gateway_ID || "",
        isActive: rowData?.isActive === 1 ? Status[0] : Status[1],
      }
    : {
        user_ID: "",
        template_type: "",
        is_variable: false,
        template_name: "",
        template_text: "",
        bot_type: "",
        gateway_ID: "",
      };

  const validationSchema = object().shape({
    user_ID: string().required("User is required"),
    template_type: string().required("Template Type is required"),
    is_variable: string().notRequired(),
    template_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Template Name is required"),
    template_text: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Template Text is required"),
    bot_type: string().required("Bot Type is required"),
    gateway_ID: string().required("Gateway is required"),
  });

  const handleSubmit = (payload) => {
    const isUpdate = !!rowData?.id;
    const url = isUpdate
      ? `rcs-template/update/${rowData.id}`
      : "rcs-template/store";

    const requestFunction = isUpdate ? putRequest : postRequest;

    requestFunction(
      url,
      {
        ...payload,
        user_ID: payload?.user_ID || "",
        is_variable: payload?.is_variable === true ? 1 : 0,
        template_type:
          payload?.template_type === templateType[0]
            ? templateTypeData[0]
            : templateTypeData[1],
        bot_type: payload?.bot_type?.toLowerCase() || "",
        isActive: payload?.isActive === Status[0] ? 1 : 0,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {isEdit ? "Edit Rcs Template" : "Add Rcs Template"}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="p_name"
                    id="p_name"
                    label="Plan Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid> */}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="user_ID"
                    id="user_ID"
                    label="Select User *"
                    multiple={false}
                    options={usersData || []}
                    getOptionLabel={(option) => option?.username || ""}
                    value={
                      usersData?.find((type) => type?.id === values?.user_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("user_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 2.5 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="template_type"
                    id="template_type"
                    label="Template Type *"
                    multiple={false}
                    // disableClearable={true}
                    options={templateType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      templateType?.find(
                        (type) => type === values?.template_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("template_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 1.2 }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="is_variable"
                        id="is_variable"
                        checked={values?.is_variable}
                        onChange={(e) => {
                          const newValue = e.target.checked;
                          setFieldValue("is_variable", newValue);

                          // Validate after state change
                          // setTimeout(() => {
                          //   validateCheckboxSelection({
                          //     ...values,
                          //     is_mobile: newValue,
                          //   });
                          // }, 0);
                        }}
                      />
                    }
                    label="Variable"
                    labelPlacement="end"
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 6, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="template_name"
                    id="template_name"
                    label="Template Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="template_text"
                    id="template_text"
                    label="Template Text *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 3.7 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="bot_type"
                    id="bot_type"
                    label="Select Bot Type *"
                    multiple={false}
                    // disableClearable={true}
                    options={botType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      botType?.find((type) => type === values?.bot_type) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("bot_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="gateway_ID"
                    id="gateway_ID"
                    label="Select Gateway *"
                    multiple={false}
                    options={RcsGatewayData || []}
                    getOptionLabel={(option) => option?.gateway_name || ""}
                    value={
                      RcsGatewayData?.find(
                        (type) => type?.id === values?.gateway_ID
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("gateway_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {isEdit && (
                  <>
                    <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="isActive"
                        id="isActive"
                        label="Select Status"
                        multiple={false}
                        disableClearable={true}
                        options={Status || []}
                        getOptionLabel={(option) => option || ""}
                        value={
                          Status?.find((type) => type === values?.isActive) ||
                          Status[0]
                        }
                        isOptionEqualToValue={(option, value) =>
                          option === value
                        }
                        onChange={(e, value) => {
                          setFieldValue("isActive", value);
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Grid>
                  </>
                )}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddEditRcs;
