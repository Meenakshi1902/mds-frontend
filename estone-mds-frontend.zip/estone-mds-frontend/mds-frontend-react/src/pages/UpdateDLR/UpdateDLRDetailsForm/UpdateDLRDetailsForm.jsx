import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import { useSelector } from "react-redux";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import { postRequest } from "../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  Status,
  validationRegex,
  fetchPostDropDownData,
  UsernameDLR,
  from_status,
  FromError,
} from "../../../utils/common";

const UpdateDLRDetailsForm = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
}) => {
  const [usersData, setUsersData] = useState([]);
  const hasFetchedUsersDropdowns = useRef(false);

  const user = useSelector((state) => state?.auth?.user);

  //const shouldIncludeUserId = true;

  const shouldIncludeUserId = [2, 3, 4].includes(user?.role_ID);

  useEffect(() => {
    if (user?.role_ID === 1 || hasFetchedUsersDropdowns.current) return;
    const payload = {};
    fetchPostDropDownData(
      `template-details/roleBasedUsers`,
      payload,
      setUsersData,
      showSnackBar
    );
    hasFetchedUsersDropdowns.current = true;
  }, [user?.id]);
  // const isEdit = rowData && Object.keys(rowData).length > 0;

  const initialValues = {
    user_ID: rowData?.user_ID || "",
    campaign: rowData?.campaign || "",
    rows: rowData?.rows || "",
    from_status: rowData?.from_status || "",
    to_status: rowData?.to_status || "",
    from_error: rowData?.from_error || "",
    to_error: rowData?.to_error || "",
  };

  const validationSchema = object().shape({
    user_ID: string().when([], {
      is: () => shouldIncludeUserId,
      then: (schema) => schema.required("User ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    campaign: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Campaign ID is required"),

    rows: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Rows is required"),

    from_status: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Select an option"),

    to_status: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Status is required"),

    from_error: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Select any option"),

    to_error: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .required("Error code is required"),
  });

  const handleSubmit = (payload) => {
    // const isUpdate = !!rowData?.id;
    const url = `plans/update/${rowData?.id || ""}`; // Always update

    const requestFunction = postRequest; // Always POST for update

    requestFunction(
      url,
      {
        ...payload,
        isActive: payload?.isActive === Status[0] ? 1 : 0,
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          const errors = response?.data?.errors || {};
          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            Object.entries(errors).forEach(([field, messages]) => {
              showSnackBar("error", `${field}: ${messages.join(", ")}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />

      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values) => {
          handleSubmit(values);
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => (
          <>
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              // container
              // spacing={4} // cleaner than rowSpacing + columnSpacing unless you want different values
              // sx={{
              //   backgroundColor: "#FAFAFA", // optional: light background to pop it out
              //   borderRadius: "8px", // optional: rounded corners
              //   padding: 3, // space inside grid
              //   boxShadow: "0 8px 24px rgba(0,0,0,0.12)", // optional: subtle shadow
              //   maxWidth: "1000px", // 👈 set your desired width here
              //   mx: "auto", // centers it horizontally
              // }}
            >
              {shouldIncludeUserId && (
                <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="user_ID"
                    id="user_ID"
                    label="Select User *"
                    multiple={false}
                    options={usersData || []}
                    getOptionLabel={(option) => option?.username || ""}
                    value={
                      usersData?.find((type) => type?.id === values?.user_ID) ||
                      null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.id === value?.id
                    }
                    onChange={(e, value) => {
                      setFieldValue("user_ID", value?.id || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              )}
              <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                <IconAutocompleteField
                  icon={PersonIcon}
                  name="campaign"
                  id="campaign"
                  label="Select Campaign ID*"
                  multiple={false}
                  disableClearable={true}
                  options={UsernameDLR || []}
                  getOptionLabel={(option) => option || ""}
                  value={
                    UsernameDLR?.find((type) => type === values?.campaign) ||
                    null
                  }
                  isOptionEqualToValue={(option, value) => option === value}
                  onChange={(e, value) => {
                    setFieldValue("campaign", value);
                  }}
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                <IconInputField
                  icon={PersonIcon}
                  name="rows"
                  id="rows"
                  label="Rows to update *"
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                <IconAutocompleteField
                  icon={PersonIcon}
                  name="from_status"
                  id="from_status"
                  label="From Status"
                  multiple={false}
                  disableClearable={true}
                  options={from_status || []}
                  getOptionLabel={(option) => option || ""}
                  // value={
                  //   Status?.find((type) => type === values?.isActive) ||
                  //   Status[0]
                  // }
                  // isOptionEqualToValue={(option, value) => option === value}
                  // onChange={(e, value) => {
                  //   setFieldValue("isActive", value);
                  // }}
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                <IconInputField
                  icon={PersonIcon}
                  name="to_status"
                  id="to_status"
                  label="To Status *"
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                />
              </Grid>

              <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                <IconAutocompleteField
                  icon={PersonIcon}
                  name="from_error"
                  id="from_error"
                  label="From error code"
                  multiple={false}
                  disableClearable={true}
                  options={FromError || []}
                  getOptionLabel={(option) => option || ""}
                  // value={
                  //   Status?.find((type) => type === values?.isActive) ||
                  //   Status[0]
                  // }
                  // isOptionEqualToValue={(option, value) => option === value}
                  // onChange={(e, value) => {
                  //   setFieldValue("isActive", value);
                  // }}
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 8, md: 6 }}>
                <IconInputField
                  icon={PersonIcon}
                  name="to_error"
                  id="to_error"
                  label="To Error *"
                  errors={errors}
                  touched={touched}
                  handleBlur={handleBlur}
                />
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#1976d2", // MUI primary blue or use your own hex
                    color: "#FFFFFF", // text color white for contrast
                    backgroundColor: "#1976d2", // same blue inside
                    mr: 2,
                    mt: 3,
                    "&:hover": {
                      borderColor: "#1565c0", // darker blue on hover
                      backgroundColor: "#1565c0",
                    },
                  }}
                >
                  Upload
                </Button>
              </Grid>
            </Grid>
          </>
        )}
      </Formik>
    </Box>
  );
};

export default UpdateDLRDetailsForm;
