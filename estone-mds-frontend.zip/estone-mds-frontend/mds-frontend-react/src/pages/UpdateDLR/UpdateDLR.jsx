import React, { useState } from "react";
import { Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../utils/common";
import SnackbarAlert from "../../components/SnackBarMessage/SnackbarAlert";
import UpdateDLRDetailsForm from "./UpdateDLRDetailsForm/UpdateDLRDetailsForm";

const UpdateDLR = () => {
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  return (
    <>
      <Typography
        variant="h5"
        sx={{
          fontWeight: 700,
        }}
      >
        Update DLR
      </Typography>

      {/* Inline Form */}
      <UpdateDLRDetailsForm showSnackBar={showSnackBar} />

      {/* Snackbar */}
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default UpdateDLR;
