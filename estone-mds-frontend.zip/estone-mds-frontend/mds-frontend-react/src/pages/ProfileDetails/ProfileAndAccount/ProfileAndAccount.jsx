import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  IconButton,
  Avatar,
} from "@mui/material";
import { mixed, object, string } from "yup";
import {
  getRequest,
  postDocumentRequest,
  putRequest,
} from "../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import { validationRegex } from "../../../utils/common";
import { Add as AddIcon } from "@mui/icons-material";
import { useUser } from "../../../context/UserContext/UserContext";

const ProfileAndAccount = ({ showSnackBar, closeModal }) => {
  const { setUserProfile } = useUser();
  const hasFetchedUserDetails = useRef(false);
  const profilePicInputRef = useRef();
  const [profileData, setProfileData] = useState(null);
  // const [refreshTable, setRefreshTable] = useState(false);

  // console.log("profileData => ", profileData);
  // console.log("type of profileData?.profile_pic => ", typeof profileData?.profile_pic);

  const initialValues = profileData
    ? {
        ...profileData,
        username: profileData?.username || "",
        full_name: profileData?.full_name || "",
        mobile_no: profileData?.mobile_no || "",
        email: profileData?.email || "",
        company_name: profileData?.company_name || "",
        city: profileData?.city || "",
        pincode: profileData?.pincode || "",
        profile_pic: profileData?.profile_pic || null, // Ensure this holds the string path or null
      }
    : {
        username: "",
        full_name: "",
        mobile_no: "",
        email: "",
        company_name: "",
        city: "",
        pincode: "",
        profile_pic: null,
      };

  const validationSchema = object().shape({
    username: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .notRequired(),
    full_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .notRequired(),
    mobile_no: string()
      .notRequired()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(
        /^(\d{10,15})(,\d{10,15}){0,2}$/,
        "You can enter up to 3 contact numbers separated by commas"
      ),
    email: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(validationRegex?.email, "Invalid email format") // Moved email regex here
      .notRequired(),
    company_name: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .notRequired(),
    city: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .notRequired(),
    pincode: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(validationRegex?.pincode, "Invalid pincode format") // Moved pincode regex here
      .notRequired(),
    profile_pic: mixed()
      .notRequired()
      .test(
        "fileType",
        "Only image files (JPG, PNG, WebP) are allowed.", // Clarified message
        function (value) {
          if (value && value instanceof File) {
            const validTypes = [
              "image/jpeg",
              "image/jpg",
              "image/webp",
              "image/png",
            ];
            return validTypes.includes(value.type);
          }
          // If it's a string (existing URL), it's valid.
          return true;
        }
      )
      .test("fileSize", "File size must be less than 2 MB", function (value) {
        if (value && value instanceof File) {
          return value.size <= 2097152;
        }
        // If it's a string (existing URL), it's valid.
        return true;
      }),
  });

  const fetchUserDetails = () => {
    getRequest("user-profile", function (response) {
      if (!response?.data?.errors && response?.status === 200) {
        setProfileData(response?.data?.data);
        setUserProfile(response?.data?.data); // Update context
      } else {
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          mappedErrors.forEach(({ message }) => {
            showSnackBar("error", message);
          });
        }
        setProfileData(null);
        setUserProfile({});
      }
    });
  };

  useEffect(() => {
    if (hasFetchedUserDetails.current) return;
    fetchUserDetails();
    hasFetchedUserDetails.current = true;
  }, []);

  const handleSubmit = (payload) => {
    putRequest(
      "user-profile/update",
      {
        ...payload,
        _method: "PUT",
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          // setRefreshTable(true); // You might want to use this state to trigger something else
          showSnackBar("success", response.data.message);
          fetchUserDetails(); // Re-fetch details to ensure latest data is shown
        } else {
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            mappedErrors.forEach(({ message }) => {
              showSnackBar("error", message);
            });
          }
        }
      }
    );

    // closeModal(); // Consider if you want to close the modal immediately or after successful save
  };

  const handleImageUpload = (file, setFieldValue) => {
    const formData = new FormData();
    formData.append("profile_pic", file);

    postDocumentRequest(
      "user-profile/update-profile-pic",
      formData,
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          showSnackBar("success", response.data.message);
          console.log("uploadimage response?.data => ", response?.data);

          // IMPORTANT: Re-fetch the user details to get the new, permanent image URL
          // This will trigger a re-render and getProfileImageSrc will use the updated profileData
          fetchUserDetails();

          // Do NOT set Formik's profile_pic to the File object here after the upload request.
          // The fetchUserDetails will update `profileData`, and `Formik` will reinitialize `initialValues`
          // with the correct string path from `profileData`.
          // The immediate preview logic in `getProfileImageSrc` (using `values.profile_pic instanceof File`)
          // will handle the initial display.
        } else {
          const errors = response?.data?.errors || {};
          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => ({
                field,
                message: errorMessages.join(", "),
              })
            );
            mappedErrors.forEach(({ message }) => {
              showSnackBar("error", message);
            });
          }
        }
      }
    );
  };

  const getProfileImageSrc = (values) => {
    // Priority 1: If a new file is selected in Formik, show its immediate preview
    if (values?.profile_pic instanceof File) {
      return URL.createObjectURL(values.profile_pic);
    }

    // Priority 2: If profileData has a profile_pic string (from API), use it
    // This is the source of truth after successful API calls
    if (
      profileData?.profile_pic &&
      typeof profileData.profile_pic === "string"
    ) {
      const baseUrl =
        import.meta.env.VITE_APP_PUBLIC_API_URL || "http://localhost:5173/";
      // Check if the profile_pic is already a full URL
      return profileData.profile_pic.startsWith("http")
        ? profileData.profile_pic
        : `${baseUrl}${profileData.profile_pic}`;
    }

    return null; // No image available
  };

  return (
    <Box px={2}>
      <Typography variant="h5">Profile And Account Details</Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      {profileData !== null ? (
        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          enableReinitialize
          onSubmit={(values, { resetForm }) => {
            // The actual submission logic is in handleSubmit, this is just for Formik's onSubmit prop
            // resetForm(); // Don't reset here, handleSubmit will deal with state updates
          }}
        >
          {({
            setFieldValue,
            errors,
            touched,
            values,
            dirty,
            isValid,
            handleBlur,
            isSubmitting,
          }) => {
            const profileImageSrc = getProfileImageSrc(values);

            return (
              <>
                {/* Profile Picture Section */}
                <Box display="flex" justifyContent="center" mb={4}>
                  <Box position="relative">
                    <Avatar
                      src={profileImageSrc || ""} // Ensure src is not null or undefined
                      id="profile_pic"
                      name="profile_pic"
                      sx={{
                        width: 120,
                        height: 120,
                        fontSize: "48px",
                        backgroundColor: "#6B7280",
                        cursor: "pointer",
                        "&:hover": {
                          opacity: 0.8,
                        },
                      }}
                      onClick={() => profilePicInputRef.current?.click()}
                    >
                      {!profileImageSrc && (
                        <PersonIcon sx={{ fontSize: "60px" }} />
                      )}
                    </Avatar>

                    <IconButton
                      onClick={() => profilePicInputRef.current?.click()}
                      sx={{
                        position: "absolute",
                        bottom: -5,
                        right: -5,
                        backgroundColor: "#4A90E2",
                        color: "white",
                        width: 32,
                        height: 32,
                        "&:hover": {
                          backgroundColor: "#357ABD",
                        },
                      }}
                    >
                      <AddIcon fontSize="small" />
                    </IconButton>

                    <input
                      ref={profilePicInputRef}
                      type="file"
                      id="profile_pic"
                      name="profile_pic"
                      accept="image/jpeg,image/jpg,image/png,image/webp"
                      style={{ display: "none" }}
                      onChange={(e) => {
                        const file = e.target.files[0];
                        if (file) {
                          const validTypes = [
                            "image/jpeg",
                            "image/jpg",
                            "image/webp",
                            "image/png",
                          ];
                          if (validTypes.includes(file.type)) {
                            if (file.size <= 2097152) {
                              // 2MB
                              // Set the file in Formik for immediate preview
                              setFieldValue("profile_pic", file);
                              // Then upload the file
                              handleImageUpload(file, setFieldValue);
                            } else {
                              showSnackBar(
                                "error",
                                "File size must be less than 2 MB"
                              );
                            }
                          } else {
                            showSnackBar(
                              "error",
                              "Only JPG, PNG, and WebP files are allowed"
                            );
                          }
                        }
                        e.target.value = ""; // Reset the input value to allow selecting the same file again
                      }}
                    />
                  </Box>
                </Box>
                <Grid
                  container
                  rowSpacing={2}
                  cellSpacing={2}
                  columnSpacing={{ xs: 1, sm: 2, md: 2 }}
                >
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="username"
                      id="username"
                      label="User Name"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={true}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="full_name"
                      id="full_name"
                      label="Full Name"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="mobile_no"
                      id="mobile_no"
                      label="Mobile No"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="email"
                      id="email"
                      label="Email"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="company_name"
                      id="company_name"
                      label="Company Name"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="city"
                      id="city"
                      label="City"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="pincode"
                      id="pincode"
                      label="Pin Code"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                    />
                  </Grid>
                </Grid>
                <Divider
                  sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
                />
                <Box display="flex" justifyContent="flex-end" mt={2}>
                  <Button
                    variant="outlined"
                    onClick={closeModal}
                    sx={{
                      borderColor: "#FED16A",
                      color: "#FED16A",
                      mr: 2,
                      "&:hover": {
                        borderColor: "#FED16A",
                        backgroundColor: "#FFF5D9",
                      },
                    }}
                  >
                    Close
                  </Button>
                  <Button
                    variant="outlined"
                    sx={{
                      borderColor: "#7F55B1",
                      color: "#7F55B1",
                      "&:hover": {
                        borderColor: "#7F55B1",
                        backgroundColor: "#EEE6FA",
                      },
                    }}
                    type="button" // Change to type="button" since onSubmit is not calling directly
                    onClick={() => handleSubmit(values)}
                    disabled={!dirty || !isValid}
                  >
                    Save
                  </Button>
                  {isSubmitting && <CircularProgress size={24} />}
                </Box>
              </>
            );
          }}
        </Formik>
      ) : (
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          height="200px"
        >
          <CircularProgress />
        </Box>
      )}
    </Box>
  );
};

export default ProfileAndAccount;
