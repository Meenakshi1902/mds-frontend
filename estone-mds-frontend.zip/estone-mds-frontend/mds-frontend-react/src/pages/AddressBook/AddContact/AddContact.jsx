import React, { useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { array, mixed, object, string } from "yup";
import { fetchGetDropDownData, validationRegex } from "../../../utils/common";
import { getRequest, postRequest } from "../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../components/IconInputField/IconInputField";
import CheckboxInputAutocompleteField from "../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";

const AddContact = ({ setRefreshTable, rowData, showSnackBar, closeModal }) => {
  const [groupAutocompleteOpen, setGroupAutocompleteOpen] = useState(false);
  const hasFetchedGroupName = useRef(false);
  const [groupUserData, setGroupUserData] = useState([]);

  const user = useSelector((state) => state?.auth?.user);

  const initialValues = {
    user_ID: user?.id || "",
    group_ID: [],
    contact_name: "",
    contact_no: "",
  };

  const validationSchema = object().shape({
    group_ID: array()
      .of(
        object({
          id: mixed().required("Group ID is required"),
        })
      )
      .min(1, "Select at least one Group ID")
      .required("Group ID is required"),
    personName: string()
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .notRequired(),
    contact_no: string()
      .required("The Contact Number is required")
      .matches(validationRegex?.blankSpace, validationRegex?.blankSpacesMessage)
      .matches(/^\d+$/, "Only numeric digits are allowed"),
  });

  useEffect(() => {
    if (hasFetchedGroupName.current) return;
    fetchGetDropDownData(
      `contact-details/getGroupForUser`,
      setGroupUserData,
      showSnackBar
    );
    hasFetchedGroupName.current = true;
  }, []);

  const handleSubmit = (payload) => {
    postRequest(
      "contact-details/store",
      {
        ...payload,
        user_ID: user?.id || rowData.user_ID,
        group_ID: payload.group_ID.map((item) => item.id),
      },
      (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          setRefreshTable(true);
          showSnackBar("success", response.data.message);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            // Optionally display errors in a snack bar or UI
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      }
    );

    closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        Add Contact Details
        {/* {isEdit ? "Edit Sender Details" : "Create Sender Details"} */}
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
        }) => {
          // console.log("values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <CheckboxInputAutocompleteField
                    icon={PersonIcon}
                    id="group_ID"
                    name="group_ID"
                    label="Select Group Name: *"
                    options={groupUserData || []}
                    getOptionLabel={(option) => option?.group_name}
                    getOptionValue={(option) => option?.id} // How to get the ID value
                    getDisplayValue={(option) => option?.group_name} // What to display in checkbox list
                    value={values?.group_ID}
                    setFieldValue={setFieldValue}
                    handleBlur={handleBlur}
                    errors={errors}
                    touched={touched}
                    autoCompleteOpen={groupAutocompleteOpen}
                    setAutoCompleteOpen={setGroupAutocompleteOpen}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="contact_name"
                    id="contact_name"
                    label="Contact Name"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="contact_no"
                    id="contact_no"
                    label="Contact Number *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddContact;
