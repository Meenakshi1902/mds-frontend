import React, { useEffect, useMemo, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  FormHelperText,
  Switch,
  IconButton,
  Container,
  TableContainer,
  Table,
  TableHead,
  TableCell,
  Paper,
  TableRow,
  TableBody,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { array, boolean, mixed, object, string } from "yup";
import {
  fetchGetDropDownData,
  fetchPostDropDownData,
  messageType,
} from "../../../../utils/common";
import {
  postDocumentRequest,
  postRequest,
} from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import DynamicTable from "../../../../components/DynamicTable/DynamicTable";

const AddDynamicSmsForm = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
  setEnableAddForm,
  setPreviewData,
  originalUrlData,
  isTrackingEnabled,
  setIsTrackingEnabled,
  bulkSmsData,
  setBulkSmsData,
}) => {
  const [charCount, setCharCount] = useState(0);
  const [smsCount, setSmsCount] = useState(0);

  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const user = useSelector((state) => state?.auth?.user);

  // const dispatch = useDispatch();
  const hasFetchedRoutes = useRef(false);
  const hasFetchedSender = useRef(false);
  const messageRef = useRef(null);

  const [uploadFileData, setUploadFileData] = useState([]);
  console.log("uploadFileData => ", uploadFileData);

  const placeHolderData = uploadFileData?.placeholder;
  console.log("placeHolderData => ", placeHolderData);
  const [fileData, setFileData] = useState([]);
  // console.log("fileData => ", fileData);
  const [columns, setColumns] = useState([]); // dynamic columns

  const [RoutesData, setRoutesData] = useState([]);
  const [senderData, setSenderData] = useState([]);
  const [senderID, setSenderID] = useState("");
  const [templateData, setTemplateData] = useState([]);

  // i used useMemo because onchange of tracking_url. campaign_name will get empty.
  // If anything in the dependency array changes,
  // the memoized value (initialValues) is recalculated —
  // and Formik may reinitialize the form if enableReinitialize is true.
  // const initialValues = useMemo(
  //   () => ({
  //     route_name: "",
  //     senderid: "",
  //     template_ID: "",
  //     placeholder: "",
  //     to: "",
  //     message: "",
  //     file: null,
  //     campaign_name: "",
  //     unicode_type: messageType[0],
  //     tracking_url: false, // always false on new form
  //     original_url: "",
  //   }),
  //   [messageType]
  // );

  const initialValues = {
    route_name: "",
    senderid: "",
    template_ID: "",
    placeholder: "",
    to: "",
    message: "",
    file: null,
    campaign_name: "",
    unicode_type: messageType[0],
    tracking_url: false, // always false on new form
    original_url: "",
  };

  const validationSchema = object().shape({
    route_name: string().required("Route Name is required"),
    senderid: string().required("Sender ID is required"),
    template_ID: string().required("Template is required"),
    message: string().required("Message is required"),
    to: string().notRequired(),
    placeholder: string().required("Placeholder is required"),
    file: mixed()
      .required("Only CSV, Excel, files are required.")
      .test(
        "fileType",
        "Only CSV, Excel, files are allowed.",
        function (value) {
          if (value && value instanceof File) {
            const validTypes = [
              "text/csv", // .csv
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
              "application/vnd.ms-excel", // optional: .xls (older format)
            ];
            return validTypes.includes(value.type);
          }
          return true;
        }
      )
      .test("fileSize", "File size must be less than 2 MB", function (value) {
        if (value && value instanceof File) {
          return value.size <= 2097152;
        }
        return true;
      }),
    campaign_name: string().required("Campaign Name is required"),
    unicode_type: string().required("Message Type is required"),
    tracking_url: boolean()
      .oneOf([true], "Tracking must be enabled to proceed.")
      .required("Tracking URL is required"),
  });

  const handlePreviewClick = (message, allData) => {
    console.log("message lol => ", message);
    console.log("allData => ", allData);
    // setEnableAddForm(text);

    const payload = {
      template: message || "",
      rows: allData || [],
    };

    postRequest(
      `generate-dynamic-message-preview`,
      payload,
      function (response) {
        console.log("responsemessages  => ", response);
        if (!response?.data?.errors) {
          setPreviewData(response?.data?.messages);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
          setPreviewData([]);
        }
      }
    );
  };

  const handleUploadFile = (formData, setFieldValue) => {
    postDocumentRequest(`upload-file`, formData, (response) => {
      if (!response?.data?.errors && response?.status === 200) {
        showSnackBar("success", "File uploaded successfully.");

        console.log("response file => ", response);
        setUploadFileData(response?.data);
        setFieldValue("to", response?.data?.to);

        const preview = response?.data?.preview;
        if (Array.isArray(preview) && preview.length > 1) {
          const [headerRow, ...dataRows] = preview;
          setColumns(headerRow);
          setFileData(dataRows);
        } else {
          setColumns([]);
          setFileData([]);
        }
      } else {
        const errors = response?.data?.errors || {};
        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else {
          Object.entries(errors).forEach(([field, messages]) => {
            showSnackBar("error", `${field}: ${messages.join(", ")}`);
          });
        }
      }
    });
  };

  const handleSubmit = async (payload) => {
    // Create a safe copy for API submission
    const payloadForAPI = { ...payload };

    // Clean up the payload copy
    if (payloadForAPI?.file == null) {
      delete payloadForAPI.file;
    }

    if (!payloadForAPI?.group_IDs || payloadForAPI.group_IDs.length === 0) {
      delete payloadForAPI.group_IDs;
    }

    // Only remove tracking_url in payloadForAPI, not in original
    if (typeof payloadForAPI?.tracking_url === "boolean") {
      delete payloadForAPI.tracking_url;
    }

    // Convert file to base64 if needed
    const getOriginalUrl = async () => {
      if (originalUrlData?.support_url && originalUrlData.support_url !== "") {
        return originalUrlData.support_url;
      } else if (originalUrlData?.file instanceof File) {
        // convert to base64
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(originalUrlData.file);
          reader.onload = () => resolve(reader.result); // base64 string
          reader.onerror = (error) => reject(error);
        });
      }
      return "";
    };

    try {
      const original_url = await getOriginalUrl();

      postRequest(
        `send-messages`,
        {
          ...payloadForAPI,
          route_name: String(payloadForAPI?.route_name) || "",
          senderid: payloadForAPI?.senderid || "",
          template_ID: String(payloadForAPI?.template_ID) || "",
          message: payloadForAPI?.message || "",
          campaign_name: payloadForAPI?.campaign_name || "",
          unicode_type: payloadForAPI?.unicode_type === "Unicode" ? 1 : 0,
          original_url,
        },
        (response) => {
          if (!response?.data?.errors && response?.status === 200) {
            setRefreshTable(true);
            showSnackBar("success", response.data.message);

            setBulkSmsData((prev) => [...prev, payloadForAPI]);
            // closeModal();
          } else {
            const errors = response?.data?.errors || {};
            if (typeof errors === "string") {
              showSnackBar("error", errors);
            } else if (typeof errors === "object") {
              const mappedErrors = Object.entries(errors).map(
                ([field, errorMessages]) => ({
                  field,
                  message: errorMessages.join(", "),
                })
              );
              mappedErrors.forEach(({ field, message }) => {
                showSnackBar("error", `${field}: ${message}`);
              });
            }
          }
        }
      );
    } catch (err) {
      console.error("Error while processing file for original_url:", err);
      showSnackBar("error", "Failed to read the uploaded file.");
    }
  };

  useEffect(() => {
    if (hasFetchedRoutes.current) return;
    fetchGetDropDownData(`fetch-routes`, setRoutesData, showSnackBar);
    hasFetchedRoutes.current = true;
  }, []);

  useEffect(() => {
    // if (!user?.id) return;
    if (!user?.id || hasFetchedSender.current) return;
    fetchGetDropDownData(`fetch-sender-id`, setSenderData, showSnackBar);
    hasFetchedSender.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (!senderID) return;
    const payload = { sender_ID: senderID };
    fetchPostDropDownData(
      `fetch-template-details`,
      payload,
      setTemplateData,
      showSnackBar
    );
  }, [senderID]);

  // Calculates character and SMS segment counts
  const calculateSMSCounts = (message = "", messageType) => {
    const messageLength = message.length;

    // Nothing typed → nothing to count
    if (messageLength === 0) {
      return { charCount: 0, smsCount: 0 };
    }

    // Segment size: 70 for Unicode, 160 otherwise (standard GSM‑7)
    const segmentSize = messageType === "Unicode" ? 70 : 160;

    // Always at least 1 segment once something is typed
    const smsCount = Math.ceil(messageLength / segmentSize);

    return { charCount: messageLength, smsCount };
  };

  const removePlaceholdersFromMessage = (placeholders = [], message = "") => {
    let cleanedMessage = message;

    placeholders.forEach((placeholder) => {
      const regex = new RegExp(`\\{${placeholder}\\}`, "g"); // match {name}, {city}, etc.
      cleanedMessage = cleanedMessage.replace(regex, "");
    });

    return cleanedMessage.trim();
  };

  const insertAtCursorPosition = (
    textareaRef,
    valueToInsert,
    currentValue,
    setValue
  ) => {
    const textarea = textareaRef.current;

    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;

    const newValue =
      currentValue.substring(0, start) +
      valueToInsert +
      currentValue.substring(end);

    setValue(newValue);

    // Set cursor position after inserted text
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd =
        start + valueToInsert.length;
    }, 0);

    // Optionally clear the selected placeholder
    // setFieldValue("placeholder", "");
  };

  return (
    <Box px={2}>
      {/* <Typography variant="h5">
        {isEdit ? "Edit Sender Details" : "Create Sender Details"}
      </Typography> */}
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          console.log("form values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          // Update character and SMS counts whenever message or unicode_type changes
          useEffect(() => {
            const { charCount: newCharCount, smsCount: newSmsCount } =
              calculateSMSCounts(values.message, values.unicode_type);
            setCharCount(newCharCount);
            setSmsCount(newSmsCount);
          }, [values.message, values.unicode_type]);

          useEffect(() => {
            if (values?.template_ID && templateData?.length > 0) {
              const selectedTemplate = templateData.find(
                (template) => template.template_ID === values.template_ID
              );

              if (selectedTemplate) {
                setFieldValue("message", selectedTemplate.template_data);
              }
            }
          }, [values.template_ID, templateData]);

          return (
            <>
              <Box sx={{ width: "32.4%", mb: 3 }}>
                {/* Upload File Field */}
                {values?.file === null ? (
                  <Box>
                    <Button
                      name="file"
                      id="file"
                      variant="outlined"
                      fullWidth
                      startIcon={<CloudUploadIcon />}
                      // onClick={() => documentFileRef.current.click()}
                      onClick={() => {
                        documentFileRef.current.click();
                        // Mark the field as touched when clicking the upload button
                        // setFieldTouched('file', true);
                      }}
                      // disabled={values?.support_url !== ""}
                      sx={{
                        color: "#1976d2",
                        borderColor:
                          errors?.file && touched?.file
                            ? "error.main"
                            : "#1976d2",
                        borderRadius: "10rem",
                        "&:hover": {
                          color: "#FFFFFF",
                          backgroundColor: "#1976d2",
                        },
                      }}
                      onBlur={handleBlur}
                    >
                      Upload File *
                      <VisuallyHiddenInput type="file" />
                    </Button>
                    <input
                      ref={documentFileRef}
                      accept=".csv, .xlsx"
                      type="file"
                      name="file"
                      id="file"
                      style={{ display: "none" }}
                      //   onChange={(e) => {
                      //     const file = e.target.files[0];
                      //     // console.log('file => ', file);
                      //     //   const validTypes = ["image/jpeg", "image/png"];
                      //     const validTypes = [
                      //       "text/csv", // .csv
                      //       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
                      //     ];
                      //     const isFileValid = validTypes.includes(file.type);
                      //     if (file && isFileValid) {
                      //       setFieldValue("file", file);
                      //       showSnackBar("success", "File Uploaded Successfully");
                      //       // setFieldTouched('file', true);
                      //     } else if (file.size > 2097152) {
                      //       // 2 MB limit
                      //       setFieldError(
                      //         "file",
                      //         "File size must be less than 2 MB"
                      //       );
                      //       e.target.value = ""; // Reset the input
                      //     } else {
                      //       setFieldValue("file", null);
                      //       showSnackBar("error", "Invalid File Format");
                      //     }
                      //   }}
                      onChange={(e) => {
                        const file = e.target.files[0];
                        const validTypes = [
                          "text/csv",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        ];
                        const isFileValid =
                          file && validTypes.includes(file.type);

                        if (isFileValid) {
                          setFieldValue("file", file);
                          showSnackBar("success", "File Uploaded Successfully");

                          const formData = new FormData();
                          formData.append("file", file);

                          console.log("formData => ", formData);
                          // setFieldValue("to", "");

                          handleUploadFile(formData, setFieldValue); // ✅ send only FormData
                        } else if (file?.size > 2097152) {
                          setFieldError(
                            "file",
                            "File size must be less than 2 MB"
                          );
                          e.target.value = "";
                        } else {
                          setFieldValue("file", null);
                          showSnackBar("error", "Invalid File Format");
                        }
                      }}
                      onBlur={handleBlur}
                    />
                  </Box>
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        maxWidth: "fit-content",
                      }}
                    >
                      Uploaded File:&nbsp;&nbsp;
                      {typeof values.file === "object"
                        ? values.file?.name
                        : rowData?.file}
                    </Typography>

                    <IconButton
                      // onClick={() => {
                      //   setFieldValue("file", null);
                      //   setUploadFileData([]);
                      //   setFieldValue("to", "");
                      //   setFieldValue("placeholder", "");
                      // }}
                      onClick={() => {
                        setFieldValue("file", null);
                        setFieldValue("to", "");
                        setFieldValue("placeholder", "");

                        const cleanedMessage = removePlaceholdersFromMessage(
                          uploadFileData?.placeholder || [],
                          values.message
                        );

                        setFieldValue("message", cleanedMessage);

                        setUploadFileData([]); // also clear placeholderData and preview
                      }}
                    >
                      <CloseIcon />
                    </IconButton>
                  </Box>
                )}
                {errors?.file && touched?.file && (
                  <FormHelperText error>{errors?.file}</FormHelperText>
                )}
              </Box>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {values?.file && (
                  <Grid size={{ xs: 12 }}>
                    {/* Show API table response here */}
                    {columns.length > 0 && fileData.length > 0 && (
                      // <Box sx={{ mt: 2, maxHeight: 300, overflow: "auto" }}>
                      //   <TableContainer
                      //     component={Paper}
                      //     sx={{ maxHeight: 300 }}
                      //   >
                      //     <Table stickyHeader size="small">
                      //       <TableHead>
                      //         <TableRow>
                      //           {columns.map((col, index) => (
                      //             <TableCell
                      //               key={index}
                      //               sx={{
                      //                 backgroundColor: "#f5f5f5",
                      //                 fontWeight: "bold",
                      //               }}
                      //             >
                      //               {col}
                      //             </TableCell>
                      //           ))}
                      //         </TableRow>
                      //       </TableHead>
                      //       <TableBody>
                      //         {fileData.map((row, i) => (
                      //           <TableRow key={i}>
                      //             {row.map((cell, j) => (
                      //               <TableCell key={j}>{cell || "-"}</TableCell>
                      //             ))}
                      //           </TableRow>
                      //         ))}
                      //       </TableBody>
                      //     </Table>
                      //   </TableContainer>
                      // </Box>
                      <DynamicTable
                        title="Uploaded File Details"
                        data={fileData}
                        columns={columns}
                      />
                    )}
                  </Grid>
                )}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="route_name"
                    id="route_name"
                    label="Select Route *"
                    multiple={false}
                    options={RoutesData || []}
                    getOptionLabel={(option) => option?.route_name || ""}
                    value={
                      RoutesData?.find(
                        (type) => type?.route_name === values?.route_name
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.route_name === value?.route_name
                    }
                    onChange={(e, value) => {
                      setFieldValue("route_name", value?.route_name || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Box flex={1}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="senderid"
                        id="senderid"
                        label="Select Sender ID *"
                        multiple={false}
                        options={senderData || []}
                        getOptionLabel={(option) => option?.sender_ID || ""}
                        value={
                          senderData?.find(
                            (type) => type?.id === values?.senderid
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) => {
                          setFieldValue("template_ID", "");

                          const sendID = value?.id || "";
                          if (sendID) {
                            setFieldValue("senderid", sendID);
                            setSenderID(sendID);
                          } else {
                            setFieldValue("senderid", "");
                            setFieldValue("template_ID", "");
                          }
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Box>

                    <Button
                      onClick={() => setEnableAddForm("sendModal")}
                      variant="contained"
                      sx={{
                        backgroundColor: "#1976d2",
                        "&:hover": {
                          backgroundColor: "#4DA8DA",
                        },
                        color: "#ffffff",
                        textTransform: "none",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        minWidth: "40px",
                        height: "40px",
                        padding: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Box flex={1}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="template_ID"
                        id="template_ID"
                        label="Select Template ID *"
                        multiple={false}
                        options={templateData || []}
                        getOptionLabel={(option) => option?.template_name || ""}
                        value={
                          templateData?.find(
                            (type) => type?.template_ID === values?.template_ID
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.template_ID === value?.template_ID
                        }
                        onChange={(e, value) => {
                          setFieldValue(
                            "template_ID",
                            value?.template_ID || ""
                          );
                        }}
                        disabled={!values?.senderid}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Box>

                    <Button
                      onClick={() => setEnableAddForm("temModal")}
                      variant="contained"
                      sx={{
                        backgroundColor: "#1976d2",
                        "&:hover": {
                          backgroundColor: "#4DA8DA",
                        },
                        color: "#ffffff",
                        textTransform: "none",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        minWidth: "40px",
                        height: "40px",
                        padding: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="unicode_type"
                    id="unicode_type"
                    label="SMS Type *"
                    multiple={false}
                    disableClearable={true}
                    options={messageType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      messageType?.find(
                        (type) => type === values?.unicode_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("unicode_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="to"
                    id="to"
                    label="To"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                    disabled
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="placeholder"
                    id="placeholder"
                    label="Insert Placeholder *"
                    multiple={false}
                    disableClearable={true}
                    options={placeHolderData || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      placeHolderData?.find(
                        (type) => type === values?.placeholder
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    // onChange={(e, value) => {
                    //   setFieldValue("placeholder", value || "");
                    // }}
                    onChange={(e, value) => {
                      if (!value) return;
                      setFieldValue("placeholder", value || ""); // plz remove if you used this one -  setFieldValue("placeholder", "");

                      const formattedPlaceholder = `{${value}}`;

                      insertAtCursorPosition(
                        messageRef,
                        formattedPlaceholder,
                        values.message,
                        (newVal) => setFieldValue("message", newVal)
                      );

                      // Optionally clear the selected placeholder
                      // setFieldValue("placeholder", "");
                    }}
                    disabled={!placeHolderData}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      mb: 1,
                    }}
                  >
                    <Typography
                      variant="body1"
                      component="label"
                      htmlFor="message"
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      SMS Message
                      <Typography
                        component="span"
                        sx={{ color: "red", ml: 0.5 }}
                      >
                        *
                      </Typography>
                    </Typography>
                  </Box>

                  <TextareaAutosize
                    ref={messageRef}
                    name="message"
                    id="message"
                    aria-label="message"
                    minRows={3}
                    placeholder="Type Message Here"
                    value={values.message}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                    // disabled={true}
                  />
                  {errors?.message && touched?.message && (
                    <FormHelperText error>{errors?.message}</FormHelperText>
                  )}

                  {/* Character and SMS Count Boxes */}
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 2,
                      mt: 1.5,
                      color: "#1976d2",
                      fontWeight: "bold",
                      fontSize: "14px",
                    }}
                  >
                    <Box
                      sx={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "8px 12px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                        },
                      }}
                    >
                      <Typography variant="body2">
                        Characters: {charCount}
                      </Typography>
                    </Box>

                    <Box
                      sx={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "8px 12px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                        },
                      }}
                    >
                      <Typography variant="body2">
                        SMS Count: {smsCount}
                      </Typography>
                    </Box>
                  </Box>
                  {/* Message Preview Button */}
                  <Box
                    sx={{
                      display: "flex",
                      //   justifyContent: "center",
                      mt: 1,
                    }}
                  >
                    <Button
                      type="button"
                      variant="outlined"
                      onClick={() => {
                        setEnableAddForm("previewModal");
                        handlePreviewClick(
                          values.message,
                          uploadFileData.all_data
                        );
                      }}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "7px 16px 7px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        color: "#1976d2",
                        fontSize: "14px",
                        textTransform: "none",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                          borderColor: "#1976d2",
                        },
                      }}
                      disabled={!values.message || !uploadFileData.all_data}
                    >
                      Message Preview
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="campaign_name"
                    id="campaign_name"
                    label="Campaign Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                    // disabled={values?.method === "Groups" ? false : true}
                  />
                </Grid>

                <Grid
                  size={{ xs: 12, sm: 8, md: 4 }}
                  sx={{ display: "flex", alignItems: "center", mb: 30 }}
                >
                  <Typography
                    sx={{
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "grey",
                    }}
                  >
                    Tracking URL
                  </Typography>
                  <Switch
                    id="tracking_url"
                    name="tracking_url"
                    label="Tracking URL"
                    // checked={values.tracking_url}
                    checked={isTrackingEnabled}
                    onChange={(e) => {
                      setFieldValue("tracking_url", e.target.checked);
                      if (e.target.checked) {
                        setEnableAddForm("trackingUrlModal");
                        setIsTrackingEnabled(e.target.checked);
                      } else {
                        setEnableAddForm(null);
                        setIsTrackingEnabled(false);
                      }
                    }}
                    // onChange={(e) => {
                    //   setFieldTouched("tracking_url", true);
                    //   setFieldValue("tracking_url", e.target.checked);
                    //   setEnableAddForm(
                    //     e.target.checked ? "trackingUrlModal" : null
                    //   );
                    // }}
                    sx={{ ml: 1 }}
                    slotProps={{ "aria-label": "controlled" }}
                  />
                  {errors?.tracking_url && touched?.tracking_url && (
                    <FormHelperText error>
                      Tracking must be enabled to proceed.
                    </FormHelperText>
                  )}
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2} gap={2}>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Send SMS
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
                <Button
                  variant="outlined"
                  onClick={() => setEnableAddForm("sheduleSmsModal")}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                  disabled={bulkSmsData?.length === 0}
                >
                  Shedule SMS
                </Button>
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddDynamicSmsForm;
