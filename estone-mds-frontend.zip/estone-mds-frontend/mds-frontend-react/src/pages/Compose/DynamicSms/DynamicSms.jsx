import React, { useEffect, useState } from "react";
import { Box, Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../../utils/common";
import SnackbarAlert from "../../../components/SnackBarMessage/SnackbarAlert";
import ModalComponent from "../../../components/ModalComponent/ModalComponent";
import TrackingUrlForm from "../../Compose/BulkSms/TrackingUrlForm/TrackingUrlForm";
import AddEditSenderDetails from "../../SenderDetails/AddEditSenderDetails/AddEditSenderDetails";
import AddEditTemplateDetails from "../../templateDetails/AddEditTemplateDetails/AddEditTemplateDetails";
import { useSelector } from "react-redux";
import SheduleSmsForm from "../../Compose/BulkSms/SheduleSmsForm/SheduleSmsForm";
import AddDynamicSmsForm from "./AddDynamicSmsForm/AddDynamicSmsForm";
import DynamicTable from "../../../components/DynamicTable/DynamicTable";

const DynamicSms = () => {
  const [bulkSmsData, setBulkSmsData] = useState([]);
  const [originalUrlData, setOriginalUrlData] = useState({
    file: null,
    support_url: "",
  });
  const [previewData, setPreviewData] = useState([]);
  console.log("previewData => ", previewData);
  const user = useSelector((state) => state?.auth?.user);
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [isTrackingEnabled, setIsTrackingEnabled] = useState(false);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [selectedRowData, setSelectedRowData] = useState({});
  const [refreshTable, setRefreshTable] = useState(false);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      setSelectedRowData([]);
    }
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      {/* Header with title and add button */}
      <Grid
        container
        display="flex"
        justifyContent="space-between"
        flexDirection="row"
      >
        <Grid display="flex" justifyContent="flex-start">
          <Typography
            variant="h5"
            noWrap
            sx={{
              paddingLeft: "15px",
              fontWeight: 700,
            }}
          >
            Dynamic SMS
          </Typography>
        </Grid>
      </Grid>
      <AddDynamicSmsForm
        rowData={selectedRowData}
        setSelectedRowData={setSelectedRowData}
        closeModal={closeModal}
        showSnackBar={showSnackBar}
        setRefreshTable={setRefreshTable}
        setEnableAddForm={setEnableAddForm}
        originalUrlData={originalUrlData}
        isTrackingEnabled={isTrackingEnabled}
        setIsTrackingEnabled={setIsTrackingEnabled}
        setBulkSmsData={setBulkSmsData}
        bulkSmsData={bulkSmsData}
        setPreviewData={setPreviewData}
      />
      <ModalComponent
        style={style}
        closeModal={closeModal}
        enableAddForm={enableAddForm}
      >
        {enableAddForm && enableAddForm === "trackingUrlModal" && (
          <TrackingUrlForm
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
            originalUrlData={originalUrlData}
            setOriginalUrlData={setOriginalUrlData}
            // setIsTrackingEnabled={setIsTrackingEnabled}
          />
        )}
        {enableAddForm && enableAddForm === "sendModal" && (
          <AddEditSenderDetails
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
        {enableAddForm && enableAddForm === "temModal" && (
          <AddEditTemplateDetails
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
        {enableAddForm && enableAddForm === "sheduleSmsModal" && (
          <SheduleSmsForm
            rowData={selectedRowData}
            setSelectedRowData={setSelectedRowData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            setRefreshTable={setRefreshTable}
          />
        )}
        {enableAddForm && enableAddForm === "previewModal" && (
          // <DynamicMsgPreviewTable
          //   previewData={previewData}
          //   closeModal={closeModal}
          //   showSnackBar={showSnackBar}
          // />
          <DynamicTable title="Message Preview" data={previewData} />
        )}
      </ModalComponent>
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default DynamicSms;
