import React, { useEffect, useMemo, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  FormHelperText,
  Switch,
  IconButton,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { array, boolean, mixed, object, string } from "yup";
import {
  fetchGetDropDownData,
  fetchPostDropDownData,
  messageType,
  method,
  transformMultipleIdForEdit,
  validationRegex,
} from "../../../../utils/common";
import { postRequest } from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import CheckboxInputAutocompleteField from "../../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

const AddBulkSmsForm = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
  setEnableAddForm,
  originalUrlData,
  isTrackingEnabled,
  setIsTrackingEnabled,
  bulkSmsData,
  setBulkSmsData,
}) => {
  // console.log("bulkSmsData => ", bulkSmsData);
  // console.log("originalUrlData => ", originalUrlData);
  // console.log("isTrackingEnabled => ", isTrackingEnabled);

  const [charCount, setCharCount] = useState(0);
  const [smsCount, setSmsCount] = useState(0);

  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const user = useSelector((state) => state?.auth?.user);

  // const dispatch = useDispatch();
  const hasFetchedRoutes = useRef(false);
  const hasFetchedSender = useRef(false);
  const hasFetchedGroup = useRef(false);

  const [groupAutocompleteOpen, setGroupAutocompleteOpen] = useState(false);

  const [RoutesData, setRoutesData] = useState([]);
  const [senderData, setSenderData] = useState([]);
  const [senderID, setSenderID] = useState("");

  const [groupUserData, setGroupUserData] = useState([]);
  const [templateData, setTemplateData] = useState([]);

  //   const isEdit = rowData && Object.keys(rowData).length > 0;

  //   const initialValues = isEdit
  //     ? {
  //         ...rowData,
  //         // ...(shouldIncludeUserId && {
  //         //   user_ID: rowData.user_ID || "",
  //         // }),
  //         route_name: rowData.route_name || "",
  //         senderid: rowData.senderid || "",
  //         template_ID: rowData.template_ID || "",
  //         method: rowData.method || "", // message format dropdown.
  //         numbers: rowData.numbers || "", // for numbers method
  //         group_IDs: transformMultipleIdForEdit(rowData?.group_IDs), // for group method
  //         csv_file: rowData.csv_file || "", // if message format dropdown. > select > csv option
  //         campaign_name: rowData.campaign_name || "",
  //         message_type: rowData.message_type || "",
  //         // unicode_type: rowData.unicode_type || "",   // message type option send to option in payload with this parameter.
  //         // original_url: rowData.original_url || "",  // this will used for Tracking URl for url and upload file for both use same parameter.
  //       }
  //     : {
  //         // ...(shouldIncludeUserId && {
  //         //   user_ID: "",
  //         // }),
  //         route_name: "",
  //         senderid: "",
  //         template_ID: "",
  //         method: rowData.method || "", // message format dropdown.
  //         numbers: "", // for numbers method
  //         group_IDs: [], // for group method
  //         csv_file: rowData.csv_file || "", // if message format dropdown. > select > csv option
  //         campaign_name: rowData.campaign_name || "",
  //         message_type: rowData.message_type || "",
  //         // unicode_type: rowData.unicode_type || "", // message type option send to option in payload with this parameter.
  //         // original_url: rowData.original_url || "",  // this will used for Tracking URl for url and upload file for both use same parameter.
  //       };

  // const initialValues = {
  //   route_name: "",
  //   senderid: "",
  //   template_ID: "",
  //   message: "",
  //   method: method[0], // message format dropdown.
  //   numbers: "", // for numbers method
  //   group_IDs: [], // for group method
  //   csv_file: null, // if message format dropdown. > select > csv option
  //   campaign_name: "",
  //   // message_type: messageType[0],
  //   unicode_type: messageType[0], // message type option send to option in payload with this parameter.
  //   tracking_url: isTrackingEnabled,
  //   // tracking_url: enableTrackForm !== null,
  //   original_url: "", // this will used for Tracking URl for url and upload file for both use same parameter.
  // };

  // i used useMemo because onchange of tracking_url. campaign_name will get empty.
  // If anything in the dependency array changes,
  // the memoized value (initialValues) is recalculated —
  // and Formik may reinitialize the form if enableReinitialize is true.
  const initialValues = useMemo(
    () => ({
      route_name: "",
      senderid: "",
      template_ID: "",
      message: "",
      method: method[0],
      numbers: "",
      group_IDs: [],
      csv_file: null,
      campaign_name: "",
      unicode_type: messageType[0],
      tracking_url: false, // always false on new form
      original_url: "",
    }),
    [method, messageType]
  );

  const validationSchema = object().shape({
    route_name: string().required("Route Name is required"),
    senderid: string().required("Sender ID is required"),
    template_ID: string().required("Template is required"),
    message: string().required("Message is required"),
    method: string().required("Message Format is required"),
    // numbers: string().when("method", {
    //   is: "Numbers",
    //   then: (schema) => schema.required("Numbers is required"),
    //   otherwise: (schema) => schema.notRequired(),
    // }),
    numbers: string()
      .required("Numbers are required")
      .test(
        "valid-numbers",
        "All numbers must be at least 8 digits and Enter Numbers separated by comma or press enter",
        (value) => {
          if (!value) return false;

          const numberRegex = /^\d{8,}$/;
          return value
            .split(/[\n,]+/) // split by newline or comma
            .map((num) => num.trim()) // remove surrounding spaces
            .filter((num) => num.length > 0) // skip empty entries
            .every((num) => numberRegex.test(num)); // check each number
        }
      ),
    // group_IDs: array()
    //   .of(
    //     object().shape({
    //       id: mixed().required("Group ID is required"),
    //     })
    //   )
    //   .min(1, "At least one Group ID is required")
    //   .required("Group ID is required"),
    group_IDs: array().when("method", {
      is: "Groups",
      then: (schema) =>
        schema
          .of(
            object().shape({
              id: mixed().required("Group ID is required"),
            })
          )
          .min(1, "At least one Group ID is required")
          .required("Group ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    // csv_file: mixed()
    //   .required("Only image files (CSV, XLSX, or TXT files) are required.")
    //   .test(
    //     "fileType",
    //     "Only CSV, XLSX, or TXT files are allowed.",
    //     function (value) {
    //       if (value && value instanceof File) {
    //         const validTypes = [
    //           "text/csv",
    //           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    //           "text/plain",
    //         ];
    //         return validTypes.includes(value.type);
    //       }
    //       return true;
    //     }
    //   )
    //   .test("fileSize", "File size must be less than 2 MB", function (value) {
    //     if (value && value instanceof File) {
    //       return value.size <= 2097152;
    //     }
    //     return true;
    //   }),
    csv_file: mixed().when("method", {
      is: "CSV",
      then: (schema) =>
        schema
          .required("CSV file is required")
          .test(
            "fileType",
            "Only CSV, XLSX, or TXT files are allowed.",
            function (value) {
              if (value && value instanceof File) {
                const validTypes = [
                  "text/csv",
                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  "text/plain",
                ];
                return validTypes.includes(value.type);
              }
              return true;
            }
          )
          .test(
            "fileSize",
            "File size must be less than 2 MB",
            function (value) {
              if (value && value instanceof File) {
                return value.size <= 2 * 1024 * 1024; // 2MB
              }
              return true;
            }
          ),
      otherwise: (schema) => schema.notRequired(),
    }),
    campaign_name: string().required("Campaign Name is required"),
    unicode_type: string().required("Message Type is required"),
    tracking_url: boolean()
      .oneOf([true], "Tracking must be enabled to proceed.")
      .required("Tracking URL is required"),
    // tracking_url: string().required("Tracking URL is required"),
    // tracking_url: boolean().oneOf([true], "Tracking must be enabled."),
  });

  // const handleSubmit = (payload) => {

  //   setBulkSmsData((prev) => [...prev, payload]);

  //   if (payload?.csv_file == null) {
  //     delete payload.csv_file;
  //   }

  //   if (!payload?.group_IDs || payload.group_IDs.length === 0) {
  //     delete payload.group_IDs;
  //   }

  //   // if i uncomment (tracking_url) this then problem occurs in send sms button.
  //   // because when method Numbers > numbers > already set number > then you remove any one and then write.
  //   // send sms button not get enabled,

  //   if (typeof payload?.tracking_url === "boolean") {
  //     delete payload.tracking_url;
  //   }

  //   postRequest(
  //     `send-messages`,
  //     {
  //       ...payload,
  //       route_name: String(payload?.route_name) || "",
  //       senderid: payload?.senderid || "",
  //       template_ID: String(payload?.template_ID) || "",
  //       message: payload?.message || "",
  //       method: payload?.method || "",
  //       numbers: payload?.numbers?.replace(/\n/g, "").trim() || "",
  //       campaign_name: payload?.campaign_name || "",
  //       unicode_type: payload?.unicode_type === "Unicode" ? 1 : 0,
  //       original_url:
  //         originalUrlData?.support_url && originalUrlData?.support_url !== ""
  //           ? originalUrlData.support_url
  //           : originalUrlData?.file || null,

  //       // original_url: payload?.original_url || null,
  //     },
  //     (response) => {
  //       if (!response?.data?.errors && response?.status === 200) {
  //         setRefreshTable(true);
  //         showSnackBar("success", response.data.message);
  //         // closeModal();
  //       } else {
  //         const errors = response?.data?.errors || {};
  //         if (typeof errors === "string") {
  //           showSnackBar("error", errors);
  //         } else if (typeof errors === "object") {
  //           const mappedErrors = Object.entries(errors).map(
  //             ([field, errorMessages]) => ({
  //               field,
  //               message: errorMessages.join(", "),
  //             })
  //           );
  //           mappedErrors.forEach(({ field, message }) => {
  //             showSnackBar("error", `${field}: ${message}`);
  //           });
  //         }
  //       }
  //     }
  //   );

  //   // closeModal();
  // };

  const normalizeNumbers = (input = "") => {
    return input
      .split(/[\n, ]+/) // split by newline, comma, or space
      .map((num) => num.trim()) // trim each part
      .filter((num) => num !== "") // remove empty entries
      .join(","); // join back with commas
  };
  // const handleSubmit = (payload) => {

  //   // Keep original payload for state tracking (don't mutate it)
  //   // setBulkSmsData((prev) => [...prev, payload]);

  //   // Create a safe copy for API submission
  //   const payloadForAPI = { ...payload };

  //   // Clean up the payload copy
  //   if (payloadForAPI?.csv_file == null) {
  //     delete payloadForAPI.csv_file;
  //   }

  //   if (!payloadForAPI?.group_IDs || payloadForAPI.group_IDs.length === 0) {
  //     delete payloadForAPI.group_IDs;
  //   }

  //   // Only remove tracking_url in payloadForAPI, not in original
  //   if (typeof payloadForAPI?.tracking_url === "boolean") {
  //     delete payloadForAPI.tracking_url;
  //   }

  //   postRequest(
  //     `send-messages`,
  //     {
  //       ...payloadForAPI,
  //       route_name: String(payloadForAPI?.route_name) || "",
  //       senderid: payloadForAPI?.senderid || "",
  //       template_ID: String(payloadForAPI?.template_ID) || "",
  //       message: payloadForAPI?.message || "",
  //       method: payloadForAPI?.method || "",
  //       // numbers: payloadForAPI?.numbers?.replace(/\n/g, "").trim() || "",
  //       numbers: normalizeNumbers(payloadForAPI?.numbers) || "",
  //       campaign_name: payloadForAPI?.campaign_name || "",
  //       unicode_type: payloadForAPI?.unicode_type === "Unicode" ? 1 : 0,
  //       original_url:
  //         originalUrlData?.support_url && originalUrlData?.support_url !== ""
  //           ? originalUrlData.support_url
  //           : originalUrlData?.file,
  //     },
  //     (response) => {
  //       if (!response?.data?.errors && response?.status === 200) {
  //         setRefreshTable(true);
  //         showSnackBar("success", response.data.message);

  //         setBulkSmsData((prev) => [...prev, payloadForAPI]);
  //         // closeModal();
  //       } else {
  //         const errors = response?.data?.errors || {};
  //         if (typeof errors === "string") {
  //           showSnackBar("error", errors);
  //         } else if (typeof errors === "object") {
  //           const mappedErrors = Object.entries(errors).map(
  //             ([field, errorMessages]) => ({
  //               field,
  //               message: errorMessages.join(", "),
  //             })
  //           );
  //           mappedErrors.forEach(({ field, message }) => {
  //             showSnackBar("error", `${field}: ${message}`);
  //           });
  //         }
  //       }
  //     }
  //   );

  //   // closeModal();
  // };

  const handleSubmit = async (payload) => {
    // Create a safe copy for API submission
    const payloadForAPI = { ...payload };

    // Clean up the payload copy
    if (payloadForAPI?.csv_file == null) {
      delete payloadForAPI.csv_file;
    }

    if (!payloadForAPI?.group_IDs || payloadForAPI.group_IDs.length === 0) {
      delete payloadForAPI.group_IDs;
    }

    // Only remove tracking_url in payloadForAPI, not in original
    if (typeof payloadForAPI?.tracking_url === "boolean") {
      delete payloadForAPI.tracking_url;
    }

    // Convert file to base64 if needed
    const getOriginalUrl = async () => {
      if (originalUrlData?.support_url && originalUrlData.support_url !== "") {
        return originalUrlData.support_url;
      } else if (originalUrlData?.file instanceof File) {
        // convert to base64
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.readAsDataURL(originalUrlData.file);
          reader.onload = () => resolve(reader.result); // base64 string
          reader.onerror = (error) => reject(error);
        });
      }
      return "";
    };

    try {
      const original_url = await getOriginalUrl();

      postRequest(
        `send-messages`,
        {
          ...payloadForAPI,
          route_name: String(payloadForAPI?.route_name) || "",
          senderid: payloadForAPI?.senderid || "",
          template_ID: String(payloadForAPI?.template_ID) || "",
          message: payloadForAPI?.message || "",
          method: payloadForAPI?.method || "",
          numbers: normalizeNumbers(payloadForAPI?.numbers) || "",
          campaign_name: payloadForAPI?.campaign_name || "",
          unicode_type: payloadForAPI?.unicode_type === "Unicode" ? 1 : 0,
          original_url,
        },
        (response) => {
          if (!response?.data?.errors && response?.status === 200) {
            setRefreshTable(true);
            showSnackBar("success", response.data.message);

            setBulkSmsData((prev) => [...prev, payloadForAPI]);
            // closeModal();
          } else {
            const errors = response?.data?.errors || {};
            if (typeof errors === "string") {
              showSnackBar("error", errors);
            } else if (typeof errors === "object") {
              const mappedErrors = Object.entries(errors).map(
                ([field, errorMessages]) => ({
                  field,
                  message: errorMessages.join(", "),
                })
              );
              mappedErrors.forEach(({ field, message }) => {
                showSnackBar("error", `${field}: ${message}`);
              });
            }
          }
        }
      );
    } catch (err) {
      console.error("Error while processing file for original_url:", err);
      showSnackBar("error", "Failed to read the uploaded file.");
    }
  };

  useEffect(() => {
    if (hasFetchedRoutes.current) return;
    fetchGetDropDownData(`fetch-routes`, setRoutesData, showSnackBar);
    hasFetchedRoutes.current = true;
  }, []);

  useEffect(() => {
    // if (!user?.id) return;
    if (!user?.id || hasFetchedSender.current) return;
    fetchGetDropDownData(`fetch-sender-id`, setSenderData, showSnackBar);
    hasFetchedSender.current = true;
  }, [user?.id]);

  useEffect(() => {
    if (hasFetchedGroup.current) return;
    fetchGetDropDownData(`fetch-group-details`, setGroupUserData, showSnackBar);
    hasFetchedGroup.current = true;
  }, []);

  useEffect(() => {
    if (!senderID) return;
    const payload = { sender_ID: senderID };
    fetchPostDropDownData(
      `fetch-template-details`,
      payload,
      setTemplateData,
      showSnackBar
    );
  }, [senderID]);

  const getValidMobileNumbersCount = (input) => {
    if (!input) return 0;

    const mobileRegex = /^\d{8,}$/;

    return input
      .split(/[\n,]+/) // split on newline OR comma
      .map((num) => num.trim()) // remove extra spaces
      .filter((num) => mobileRegex.test(num)).length; // validate
  };

  // Calculates character and SMS segment counts
  const calculateSMSCounts = (message = "", messageType) => {
    const messageLength = message.length;

    // Nothing typed → nothing to count
    if (messageLength === 0) {
      return { charCount: 0, smsCount: 0 };
    }

    // Segment size: 70 for Unicode, 160 otherwise (standard GSM‑7)
    const segmentSize = messageType === "Unicode" ? 70 : 160;

    // Always at least 1 segment once something is typed
    const smsCount = Math.ceil(messageLength / segmentSize);

    return { charCount: messageLength, smsCount };
  };

  return (
    <Box px={2}>
      {/* <Typography variant="h5">
        {isEdit ? "Edit Sender Details" : "Create Sender Details"}
      </Typography> */}
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("form values => ", values);
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          // Update character and SMS counts whenever message or unicode_type changes
          useEffect(() => {
            const { charCount: newCharCount, smsCount: newSmsCount } =
              calculateSMSCounts(values.message, values.unicode_type);
            setCharCount(newCharCount);
            setSmsCount(newSmsCount);
          }, [values.message, values.unicode_type]);

          useEffect(() => {
            if (values?.template_ID && templateData?.length > 0) {
              const selectedTemplate = templateData.find(
                (template) => template.template_ID === values.template_ID
              );

              if (selectedTemplate) {
                setFieldValue("message", selectedTemplate.template_data);
              }
            }
          }, [values.template_ID, templateData]);

          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="route_name"
                    id="route_name"
                    label="Select Route *"
                    multiple={false}
                    options={RoutesData || []}
                    getOptionLabel={(option) => option?.route_name || ""}
                    value={
                      RoutesData?.find(
                        (type) => type?.route_name === values?.route_name
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.route_name === value?.route_name
                    }
                    onChange={(e, value) => {
                      setFieldValue("route_name", value?.route_name || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Box flex={1}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="senderid"
                        id="senderid"
                        label="Select Sender ID *"
                        multiple={false}
                        options={senderData || []}
                        getOptionLabel={(option) => option?.sender_ID || ""}
                        value={
                          senderData?.find(
                            (type) => type?.id === values?.senderid
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.id === value?.id
                        }
                        onChange={(e, value) => {
                          setFieldValue("template_ID", "");

                          const sendID = value?.id || "";
                          if (sendID) {
                            setFieldValue("senderid", sendID);
                            setSenderID(sendID);
                          } else {
                            setFieldValue("senderid", "");
                            setFieldValue("template_ID", "");
                          }
                        }}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Box>

                    <Button
                      onClick={() => setEnableAddForm("sendModal")}
                      variant="contained"
                      sx={{
                        backgroundColor: "#1976d2",
                        "&:hover": {
                          backgroundColor: "#4DA8DA",
                        },
                        color: "#ffffff",
                        textTransform: "none",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        minWidth: "40px",
                        height: "40px",
                        padding: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box display="flex" alignItems="center" gap={1}>
                    <Box flex={1}>
                      <IconAutocompleteField
                        icon={PersonIcon}
                        name="template_ID"
                        id="template_ID"
                        label="Select Template ID *"
                        multiple={false}
                        options={templateData || []}
                        getOptionLabel={(option) => option?.template_name || ""}
                        value={
                          templateData?.find(
                            (type) => type?.template_ID === values?.template_ID
                          ) || null
                        }
                        isOptionEqualToValue={(option, value) =>
                          option?.template_ID === value?.template_ID
                        }
                        onChange={(e, value) => {
                          setFieldValue(
                            "template_ID",
                            value?.template_ID || ""
                          );
                        }}
                        disabled={!values?.senderid}
                        errors={errors}
                        touched={touched}
                        handleBlur={handleBlur}
                      />
                    </Box>

                    <Button
                      onClick={() => setEnableAddForm("temModal")}
                      variant="contained"
                      sx={{
                        backgroundColor: "#1976d2",
                        "&:hover": {
                          backgroundColor: "#4DA8DA",
                        },
                        color: "#ffffff",
                        textTransform: "none",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        borderRadius: "8px",
                        minWidth: "40px",
                        height: "40px",
                        padding: 0,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <AddIcon />
                    </Button>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="method"
                    id="method"
                    label="Message Format *"
                    multiple={false}
                    options={method || []}
                    disableClearable={true}
                    getOptionLabel={(option) => option || ""}
                    value={
                      method?.find((type) => type === values?.method) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("method", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                {/* Numbers Field */}
                {values?.method === "Numbers" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        mb: 1,
                      }}
                    >
                      <Typography
                        variant="body1"
                        component="label"
                        htmlFor="numbers"
                        sx={{ display: "flex", alignItems: "center" }}
                      >
                        Numbers
                        <Typography
                          component="span"
                          sx={{ color: "red", ml: 0.5 }}
                        >
                          *
                        </Typography>
                      </Typography>
                    </Box>

                    <TextareaAutosize
                      name="numbers"
                      id="numbers"
                      aria-label="numbers"
                      minRows={3}
                      placeholder="Type Numbers Separated by New Line"
                      value={values.numbers}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      style={{
                        width: "100%",
                        maxWidth: "800px",
                        height: "auto",
                        padding: "8px",
                      }}
                    />
                    {errors?.numbers && touched?.numbers && (
                      <FormHelperText error>{errors?.numbers}</FormHelperText>
                    )}

                    {/* Character and SMS Count Boxes */}
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        gap: 2,
                        mt: 1.5,
                        color: "#1976d2",
                        fontWeight: "bold",
                        fontSize: "14px",
                      }}
                    >
                      <Box
                        sx={{
                          // flex: 1,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: "8px 12px",
                          border: "1px solid #1976d2",
                          borderRadius: "10rem",
                          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                          transition: "all 0.3s ease",
                          "&:hover": {
                            backgroundColor: "#1976d2",
                            color: "#fff",
                          },
                        }}
                      >
                        <Typography variant="body2">
                          No's : {getValidMobileNumbersCount(values.numbers)}
                        </Typography>
                      </Box>
                    </Box>
                  </Grid>
                )}

                {/* Group ID Field */}
                {values?.method === "Groups" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <CheckboxInputAutocompleteField
                      icon={PersonIcon}
                      id="group_IDs"
                      name="group_IDs"
                      label="Select Groups: *"
                      options={groupUserData || []}
                      getOptionLabel={(option) => option?.group_name}
                      getOptionValue={(option) => option?.id} // How to get the ID value
                      getDisplayValue={(option) => option?.group_name} // What to display in checkbox list
                      value={values?.group_IDs}
                      setFieldValue={setFieldValue}
                      handleBlur={handleBlur}
                      errors={errors}
                      touched={touched}
                      autoCompleteOpen={groupAutocompleteOpen}
                      setAutoCompleteOpen={setGroupAutocompleteOpen}
                    />
                  </Grid>
                )}

                {/* Upload File Field */}
                {values?.method === "CSV" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    {values?.csv_file === null ? (
                      <Box>
                        <Button
                          name="csv_file"
                          id="csv_file"
                          variant="outlined"
                          fullWidth
                          startIcon={<CloudUploadIcon />}
                          // onClick={() => documentFileRef.current.click()}
                          onClick={() => {
                            documentFileRef.current.click();
                            // Mark the field as touched when clicking the upload button
                            // setFieldTouched('csv_file', true);
                          }}
                          sx={{
                            color: "#1976d2",
                            borderColor:
                              errors?.csv_file && touched?.csv_file
                                ? "error.main"
                                : "#1976d2",
                            borderRadius: "10rem",
                            "&:hover": {
                              color: "#FFFFFF",
                              backgroundColor: "#1976d2",
                            },
                          }}
                          onBlur={handleBlur}
                        >
                          Upload File *
                          <VisuallyHiddenInput type="file" />
                        </Button>
                        <input
                          ref={documentFileRef}
                          accept=".csv, .xlsx, .txt"
                          // accept=".doc,.docx,.pdf"
                          type="file"
                          name="csv_file"
                          id="csv_file"
                          style={{ display: "none" }}
                          onChange={(e) => {
                            const file = e.target.files[0];
                            //   const validTypes = ["image/jpeg", "image/png"];
                            const validTypes = [
                              "text/csv", // .csv
                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
                              "text/plain", // .txt
                            ];
                            const isFileValid = validTypes.includes(file.type);
                            if (file && isFileValid) {
                              setFieldValue("csv_file", file);
                              showSnackBar(
                                "success",
                                "File Uploaded Successfully"
                              );
                              // setFieldTouched('csv_file', true);
                            } else if (file.size > 2097152) {
                              // 2 MB limit
                              setFieldError(
                                "csv_file",
                                "File size must be less than 2 MB"
                              );
                              e.target.value = ""; // Reset the input
                            } else {
                              setFieldValue("csv_file", null);
                              showSnackBar("error", "Invalid File Format");
                            }
                          }}
                          onBlur={handleBlur}
                        />
                      </Box>
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <Typography
                          sx={{
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            maxWidth: "fit-content",
                          }}
                        >
                          Uploaded File:&nbsp;&nbsp;
                          {typeof values.csv_file === "object"
                            ? values.csv_file?.name
                            : rowData?.csv_file}
                        </Typography>

                        <IconButton
                          onClick={() => setFieldValue("csv_file", null)}
                        >
                          <CloseIcon />
                        </IconButton>
                      </Box>
                    )}
                    {errors?.csv_file && touched?.csv_file && (
                      <FormHelperText error>{errors?.csv_file}</FormHelperText>
                    )}
                  </Grid>
                )}

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      mb: 1,
                    }}
                  >
                    <Typography
                      variant="body1"
                      component="label"
                      htmlFor="message"
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      Message
                      <Typography
                        component="span"
                        sx={{ color: "red", ml: 0.5 }}
                      >
                        *
                      </Typography>
                    </Typography>
                  </Box>

                  <TextareaAutosize
                    name="message"
                    id="message"
                    aria-label="message"
                    minRows={3}
                    placeholder="Type Message Here"
                    value={values.message}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                    // disabled={true}
                  />
                  {errors?.message && touched?.message && (
                    <FormHelperText error>{errors?.message}</FormHelperText>
                  )}

                  {/* Character and SMS Count Boxes */}
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      gap: 2,
                      mt: 1.5,
                      color: "#1976d2",
                      fontWeight: "bold",
                      fontSize: "14px",
                    }}
                  >
                    <Box
                      sx={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "8px 12px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                        },
                      }}
                    >
                      <Typography variant="body2">
                        Characters: {charCount}
                      </Typography>
                    </Box>

                    <Box
                      sx={{
                        flex: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        padding: "8px 12px",
                        border: "1px solid #1976d2",
                        borderRadius: "10rem",
                        boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                        transition: "all 0.3s ease",
                        "&:hover": {
                          backgroundColor: "#1976d2",
                          color: "#fff",
                        },
                      }}
                    >
                      <Typography variant="body2">
                        SMS Count: {smsCount}
                      </Typography>
                    </Box>
                  </Box>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="campaign_name"
                    id="campaign_name"
                    label="Campaign Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                    // disabled={values?.method === "Groups" ? false : true}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="unicode_type"
                    id="unicode_type"
                    label="Message Type *"
                    multiple={false}
                    disableClearable={true}
                    options={messageType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      messageType?.find(
                        (type) => type === values?.unicode_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("unicode_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid
                  size={{ xs: 12, sm: 8, md: 4 }}
                  sx={{ display: "flex", alignItems: "center" }}
                >
                  <Typography
                    sx={{
                      fontSize: "14px",
                      fontWeight: "600",
                      color: "grey",
                    }}
                  >
                    Tracking URL
                  </Typography>
                  <Switch
                    id="tracking_url"
                    name="tracking_url"
                    label="Tracking URL"
                    // checked={values.tracking_url}
                    checked={isTrackingEnabled}
                    onChange={(e) => {
                      setFieldValue("tracking_url", e.target.checked);
                      if (e.target.checked) {
                        setEnableAddForm("trackingUrlModal");
                        setIsTrackingEnabled(e.target.checked);
                      } else {
                        setEnableAddForm(null);
                        setIsTrackingEnabled(false);
                      }
                    }}
                    // onChange={(e) => {
                    //   setFieldTouched("tracking_url", true);
                    //   setFieldValue("tracking_url", e.target.checked);
                    //   setEnableAddForm(
                    //     e.target.checked ? "trackingUrlModal" : null
                    //   );
                    // }}
                    sx={{ ml: 1 }}
                    slotProps={{ "aria-label": "controlled" }}
                  />
                  {errors?.tracking_url && touched?.tracking_url && (
                    <FormHelperText error>
                      Tracking must be enabled to proceed.
                    </FormHelperText>
                  )}
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2} gap={2}>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Send SMS
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
                <Button
                  variant="outlined"
                  onClick={() => setEnableAddForm("sheduleSmsModal")}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                  disabled={bulkSmsData?.length === 0}
                >
                  Shedule SMS
                </Button>
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddBulkSmsForm;
