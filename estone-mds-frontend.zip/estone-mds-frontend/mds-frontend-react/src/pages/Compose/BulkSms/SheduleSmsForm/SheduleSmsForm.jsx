import React, { useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
} from "@mui/material";
import { object, string } from "yup";
import {
  postDocumentRequest,
  postRequest,
} from "../../../../helpers/http.helper";
import { validationRegex } from "../../../../utils/common";
import PersonIcon from "@mui/icons-material/Person";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import dayjs from "dayjs";
import CustomDatePicker from "../../../../components/CustomDatePicker/CustomDatePicker";
import IconInputField from "../../../../components/IconInputField/IconInputField";

const SheduleSmsForm = ({
  showSnackBar,
  closeModal,
  enableAddForm,
  bulkSmsData,
  setBulkSmsData,
}) => {
  const [openSheduleDateOne, setOpenSheduleDateOne] = useState(false);
  const [openSheduleDateTwo, setOpenSheduleDateTwo] = useState(false);
  const [openSheduleDateThree, setOpenSheduleDateThree] = useState(false);
  const [openSheduleDateFour, setOpenSheduleDateFour] = useState(false);

  const initialValues = {
    sheduleDateOne: "",
    sheduleDateTwo: "",
    sheduleDateThree: "",
    sheduleDateFour: "",
    numbersCount_One: "",
    numbersCount_Two: "",
    numbersCount_Three: "",
    numbersCount_Four: "",
  };

  const validationSchema = object().shape({
    numbersCount_One: string().when("sheduleDateOne", {
      is: (date) => {
        return date && dayjs(date).isValid();
      },
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .matches(/^\d+$/, "Only numeric digits are allowed")
          .required("Count is Required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    numbersCount_Two: string().when("sheduleDateTwo", {
      is: (date) => date && dayjs(date).isValid(),
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .matches(/^\d+$/, "Only numeric digits are allowed")
          .required("Count is Required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    numbersCount_Three: string().when("sheduleDateThree", {
      is: (date) => date && dayjs(date).isValid(),
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .matches(/^\d+$/, "Only numeric digits are allowed")
          .required("Count is Required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    numbersCount_Four: string().when("sheduleDateFour", {
      is: (date) => date && dayjs(date).isValid(),
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .matches(/^\d+$/, "Only numeric digits are allowed")
          .required("Count is Required"),
      otherwise: (schema) => schema.notRequired(),
    }),
  });

  const handleSubmit = (values) => {
    const schedule_date = [];
    const numbers_count = [];

    const scheduleMapping = [
      { date: "sheduleDateOne", count: "numbersCount_One" },
      { date: "sheduleDateTwo", count: "numbersCount_Two" },
      { date: "sheduleDateThree", count: "numbersCount_Three" },
      { date: "sheduleDateFour", count: "numbersCount_Four" },
    ];

    scheduleMapping.forEach(({ date, count }) => {
      const dateValue = values[date];
      const countValue = values[count];

      if (dateValue && countValue) {
        // Ensure dateValue is a Dayjs object before formatting
        const formattedDate = dayjs(dateValue).format("YYYY-MM-DD HH:mm:ss");
        schedule_date.push(formattedDate);
        numbers_count.push(Number(countValue));
      }
    });

    const editPayload = {
      ...bulkSmsData?.[0],
      schedule_date,
      numbers_count,
    };

    let Url = "";
    if (enableAddForm === "SheduleRcsSmsModal") {
      Url = `rcs-schedule-send-messages`;
    } else if (enableAddForm === "dynamicRcsSheduleModal") {
      Url = `rcs-schedule-send-dynamic-messages`;
    } else {
      Url = `schedule-send-messages`;
    }

    const requestMethod = bulkSmsData?.[0].csv_file
      ? postDocumentRequest
      : postRequest;

    requestMethod(Url, editPayload, (response) => {
      if (!response?.data?.errors && response?.status === 200) {
        showSnackBar("success", response.data.message);
        setBulkSmsData([]);
        closeModal();
      } else {
        const errors = response?.data?.errors || {};

        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, errorMessages]) => {
              return {
                field,
                message: errorMessages.join(", "),
              };
            }
          );

          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
      }
    });
  };

  const handleDateChange = async (
    fieldName,
    countFieldName,
    value,
    setFieldTouched,
    setFieldValue,
    validateField
  ) => {
    setFieldValue(fieldName, value);

    if (value && dayjs(value).isValid()) {
      setFieldTouched(countFieldName, true);
      setTimeout(() => {
        validateField(countFieldName);
      }, 0);
    } else {
      setFieldValue(countFieldName, "");
      setFieldTouched(countFieldName, false);
      // It's also good practice to clear validation errors if the date is cleared
      validateField(countFieldName); // Re-validate to clear the error
    }
    // Also, mark the date field as touched when its value changes
    setFieldTouched(fieldName, true);
  };

  return (
    <Box px={2}>
      <Typography variant="h5">Schedule For Later</Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        validateOnChange={true}
        validateOnBlur={true}
      >
        {({
          setFieldValue,
          setFieldTouched,
          validateField,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur, // Make sure to destructure handleBlur
          isSubmitting,
        }) => {
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* Schedule 1 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateOne"
                        name="sheduleDateOne"
                        label="Schedule 1 Date"
                        value={
                          values.sheduleDateOne
                            ? dayjs(values.sheduleDateOne)
                            : null
                        }
                        disablePast={true}
                        format="DD/MM/YYYY HH:mm"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateOne}
                        onClose={() => setOpenSheduleDateOne(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateOne",
                            "numbersCount_One",
                            value,
                            setFieldTouched,
                            setFieldValue,
                            validateField
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateOne(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateOne(true);
                            },
                            size: "small",
                            readOnly: true, // Keep this as true for date pickers to prevent manual typing
                            onBlur: handleBlur, // Pass Formik's handleBlur here
                            error:
                              touched.sheduleDateOne &&
                              Boolean(errors.sheduleDateOne),
                            helperText: touched.sheduleDateOne
                              ? errors.sheduleDateOne
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 8, md: 4 }} sx={{ mt: "10px" }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="numbersCount_One"
                      id="numbersCount_One"
                      label={
                        values?.sheduleDateOne
                          ? "Numbers Count One *"
                          : "Numbers Count One"
                      }
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={!values?.sheduleDateOne} // Simplified conditional for disabled
                    />
                  </Grid>
                </Grid>

                {/* Schedule 2 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateTwo"
                        name="sheduleDateTwo"
                        label="Schedule 2 Date"
                        value={
                          values.sheduleDateTwo
                            ? dayjs(values.sheduleDateTwo)
                            : null
                        }
                        disablePast={true}
                        format="DD/MM/YYYY HH:mm"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateTwo}
                        onClose={() => setOpenSheduleDateTwo(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateTwo",
                            "numbersCount_Two",
                            value,
                            setFieldTouched,
                            setFieldValue,
                            validateField
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateTwo(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateTwo(true);
                            },
                            size: "small",
                            readOnly: true,
                            onBlur: handleBlur,
                            error:
                              touched.sheduleDateTwo &&
                              Boolean(errors.sheduleDateTwo),
                            helperText: touched.sheduleDateTwo
                              ? errors.sheduleDateTwo
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: "10px" }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="numbersCount_Two"
                      id="numbersCount_Two"
                      label={
                        values?.sheduleDateTwo
                          ? "Numbers Count Two *"
                          : "Numbers Count Two"
                      }
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={!values?.sheduleDateTwo}
                    />
                  </Grid>
                </Grid>

                {/* Schedule 3 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateThree"
                        name="sheduleDateThree"
                        label="Schedule 3 Date"
                        value={
                          values.sheduleDateThree
                            ? dayjs(values.sheduleDateThree)
                            : null
                        }
                        disablePast={true}
                        format="DD/MM/YYYY HH:mm"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateThree}
                        onClose={() => setOpenSheduleDateThree(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateThree",
                            "numbersCount_Three",
                            value,
                            setFieldTouched,
                            setFieldValue,
                            validateField
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateThree(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateThree(true);
                            },
                            size: "small",
                            readOnly: true,
                            onBlur: handleBlur,
                            error:
                              touched.sheduleDateThree &&
                              Boolean(errors.sheduleDateThree),
                            helperText: touched.sheduleDateThree
                              ? errors.sheduleDateThree
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: "10px" }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="numbersCount_Three"
                      id="numbersCount_Three"
                      label={
                        values?.sheduleDateThree
                          ? "Numbers Count Three *"
                          : "Numbers Count Three"
                      }
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={!values?.sheduleDateThree}
                    />
                  </Grid>
                </Grid>

                {/* Schedule 4 - Date and Time */}
                <Grid
                  display="flex"
                  alignItems="flex-start"
                  size={{ xs: 12 }}
                  gap={2}
                >
                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: 1 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <CustomDatePicker
                        icon={PersonIcon}
                        id="sheduleDateFour"
                        name="sheduleDateFour"
                        label="Schedule 4 Date"
                        value={
                          values.sheduleDateFour
                            ? dayjs(values.sheduleDateFour)
                            : null
                        }
                        disablePast={true}
                        format="DD/MM/YYYY HH:mm"
                        adapter={AdapterDayjs}
                        sx={{ width: "100%" }}
                        open={openSheduleDateFour}
                        onClose={() => setOpenSheduleDateFour(false)}
                        onChange={(value) => {
                          handleDateChange(
                            "sheduleDateFour",
                            "numbersCount_Four",
                            value,
                            setFieldTouched,
                            setFieldValue,
                            validateField
                          );
                        }}
                        slotProps={{
                          openPickerButton: {
                            tabIndex: -1,
                            disabled: true,
                          },
                          textField: {
                            onClick: () => setOpenSheduleDateFour(true),
                            onKeyDown: (e) => {
                              if (
                                e.code.startsWith("Digit") ||
                                e.code === "Enter"
                              )
                                setOpenSheduleDateFour(true);
                            },
                            size: "small",
                            readOnly: true,
                            onBlur: handleBlur,
                            error:
                              touched.sheduleDateFour &&
                              Boolean(errors.sheduleDateFour),
                            helperText: touched.sheduleDateFour
                              ? errors.sheduleDateFour
                              : "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>

                  <Grid size={{ xs: 12, sm: 6, md: 4 }} sx={{ mt: "10px" }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="numbersCount_Four"
                      id="numbersCount_Four"
                      label={
                        values?.sheduleDateFour
                          ? "Numbers Count Four *"
                          : "Numbers Count Four"
                      }
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={!values?.sheduleDateFour}
                    />
                  </Grid>
                </Grid>
              </Grid>

              <Typography
                sx={{
                  mt: "1rem",
                  mb: "1rem",
                  fontSize: "0.875rem",
                  color: "#7F55B1",
                  fontWeight: "bold",
                }}
              >
                Note : Filling each schedule date will divide the whole campaign
                in parts based on date filled up. e.g : if you fill two dates
                and campaing size is 1lac then whole campaign will divide in two
                campaigns with filled up date 50k/50k.
              </Typography>

              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default SheduleSmsForm;
