import React from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  IconButton,
  FormHelperText,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
} from "@mui/material";
import { mixed, object, string } from "yup";
import { postDocumentRequest } from "../../../../helpers/http.helper";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import { validationRegex } from "../../../../utils/common";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";

const TrackingUrlForm = ({
  setRefreshTable,
  rowData,
  showSnackBar,
  closeModal,
  originalUrlData,
  setOriginalUrlData,
  // setIsTrackingEnabled
}) => {
  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  //   const isEdit = rowData && Object.keys(rowData).length > 0;

  //   console.log("values isEdit => ", isEdit);

  //   const initialValues = isEdit
  //     ? {
  //         ...rowData,
  //         company_name: rowData?.company_name || "",
  //         website_address: rowData?.website_address || "",
  //         company_tagline: rowData?.company_tagline || "",
  //         support_url: rowData?.support_url || "",
  //         support_mobile: rowData?.support_mobile || "",
  //         support_email: rowData?.support_email || "",
  //         company_logo_path: rowData?.company_logo_path || null,
  //       }
  //     : {
  //         company_name: "",
  //         website_address: "",
  //         company_tagline: "",
  //         support_url: "",
  //         support_mobile: "",
  //         support_email: "",
  //         company_logo_path: null,
  //       };

  const initialValues = {
    support_url: originalUrlData?.support_url || "",
    file: originalUrlData?.file || null,
    uploadType: "originalUrl", // "originalUrl" or "uploadImage"
  };

  //   const validationSchema = object().shape({
  //     support_url: string()
  //       .matches(
  //         validationRegex?.blankSpace,
  //         validationRegex?.blankSpacesMessage,
  //         validationRegex.url,
  //         "Invalid URL format"
  //       )
  //       .required("URL is required"),
  //     file: mixed()
  //       .required("Only image files (CSV, XLSX, or TXT files) are required.")
  //       .test(
  //         "fileType",
  //         "Only CSV, XLSX, or TXT files are allowed.",
  //         function (value) {
  //           if (value && value instanceof File) {
  //             const validTypes = [
  //               "text/csv",
  //               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //               "text/plain",
  //             ];
  //             return validTypes.includes(value.type);
  //           }
  //           return true;
  //         }
  //       )
  //       .test("fileSize", "File size must be less than 2 MB", function (value) {
  //         if (value && value instanceof File) {
  //           return value.size <= 2097152;
  //         }
  //         return true;
  //       }),
  //   });

  const validationSchema = object().shape({
    uploadType: string().required(),

    support_url: string().when("uploadType", {
      is: "originalUrl",
      then: (schema) =>
        schema
          .matches(
            validationRegex?.blankSpace,
            validationRegex?.blankSpacesMessage
          )
          .matches(validationRegex?.url, "Invalid URL format")
          .required("URL is required"),
      otherwise: (schema) => schema.notRequired(),
    }),

    file: mixed().when("uploadType", {
      is: "uploadImage",
      then: (schema) =>
        schema
          .required("Only files (CSV, XLSX, or TXT files) are required.")
          .test(
            "fileType",
            "Only CSV, XLSX, or TXT files are allowed.",
            function (value) {
              if (value && value instanceof File) {
                const validTypes = [
                  "text/csv",
                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  "text/plain",
                ];
                return validTypes.includes(value.type);
              }
              return false;
            }
          )
          .test(
            "fileSize",
            "File size must be less than 2 MB",
            function (value) {
              if (value && value instanceof File) {
                return value.size <= 2 * 1024 * 1024; // 2 MB
              }
              return false;
            }
          ),
      otherwise: (schema) => schema.notRequired(),
    }),
  });

  const handleSubmit = (payload) => {
    setOriginalUrlData({
      support_url: payload?.support_url,
      file: payload?.file,
    });
    showSnackBar("success", "Data saved successfully!");
    // setIsTrackingEnabled(true);
    closeModal();

    // const isUpdate = !!rowData?.id;
    // const sanitizedPayload = { ...payload };
    // const url = isUpdate ? `branding/update/${rowData.id}` : "branding/store";

    // if (isEdit && typeof sanitizedPayload.company_logo_path === "string") {
    //   delete sanitizedPayload.company_logo_path;
    // }
    // const requestFunction = isUpdate ? postDocumentRequest : postRequest;

    // postDocumentRequest(
    //   url,
    //   {
    //     ...payload,
    //     // ...(isEdit && { _method: "PUT" }),
    //   },
    //   (response) => {
    //     if (!response?.data?.errors && response?.status === 200) {
    //       setRefreshTable(true);
    //       showSnackBar("success", response.data.message);
    //       closeModal();
    //     } else {
    //       // Handling error messages
    //       const errors = response?.data?.errors || {};

    //       if (typeof errors === "string") {
    //         showSnackBar("error", errors);
    //       } else if (typeof errors === "object") {
    //         const mappedErrors = Object.entries(errors).map(
    //           ([field, errorMessages]) => {
    //             return {
    //               field,
    //               message: errorMessages.join(", "),
    //             };
    //           }
    //         );

    //         // Optionally display errors in a snack bar or UI
    //         mappedErrors.forEach(({ field, message }) => {
    //           showSnackBar("error", `${field}: ${message}`);
    //         });
    //       }
    //     }
    //   }
    // );

    // closeModal();
  };

  return (
    <Box px={2}>
      <Typography variant="h5">
        {/* {isEdit ? "Edit Branding Details" : "Add Branding Details"} */}
        URL Tracking
      </Typography>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          isSubmitting,
          handleChange,
        }) => {
          // console.log("values => ", values);
          // console.log(
          //   "values.company_logo_path.name => ",
          //   values.company_logo_path?.name
          // );
          // console.log("buttoncndn => ", dirty, isValid, errors); // false, true
          //   const currentValidationSchema = getValidationSchema(values.inputType);
          return (
            <>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {/* Radio Button Group */}
                <Grid size={{ xs: 12 }}>
                  <FormControl component="fieldset">
                    <RadioGroup
                      row
                      name="uploadType"
                      value={values.uploadType}
                      onChange={(e) =>
                        setFieldValue("uploadType", e.target.value)
                      }
                    >
                      <FormControlLabel
                        value="originalUrl"
                        control={<Radio />}
                        label="Original URL"
                      />
                      <Typography sx={{ mr: 2, mt: 1 }}>"OR"</Typography>
                      <FormControlLabel
                        value="uploadImage"
                        control={<Radio />}
                        label="Upload Image"
                      />
                    </RadioGroup>
                  </FormControl>
                </Grid>

                {values.uploadType === "originalUrl" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    <IconInputField
                      icon={PersonIcon}
                      name="support_url"
                      id="support_url"
                      label="Enter URL here *"
                      errors={errors}
                      touched={touched}
                      handleBlur={handleBlur}
                      disabled={values?.file !== null}
                    />
                  </Grid>
                )}

                {values.uploadType === "uploadImage" && (
                  <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                    {values?.file === null ? (
                      <Box>
                        <Button
                          name="file"
                          id="file"
                          variant="outlined"
                          fullWidth
                          startIcon={<CloudUploadIcon />}
                          // onClick={() => documentFileRef.current.click()}
                          onClick={() => {
                            documentFileRef.current.click();
                            // Mark the field as touched when clicking the upload button
                            // setFieldTouched('file', true);
                          }}
                          disabled={values?.support_url !== ""}
                          sx={{
                            color: "#1976d2",
                            borderColor:
                              errors?.file && touched?.file
                                ? "error.main"
                                : "#1976d2",
                            borderRadius: "10rem",
                            "&:hover": {
                              color: "#FFFFFF",
                              backgroundColor: "#1976d2",
                            },
                          }}
                          onBlur={handleBlur}
                        >
                          Upload File *
                          <VisuallyHiddenInput type="file" />
                        </Button>
                        <input
                          ref={documentFileRef}
                          accept=".csv, .xlsx, .txt"
                          // accept=".doc,.docx,.pdf"
                          type="file"
                          name="file"
                          id="file"
                          style={{ display: "none" }}
                          onChange={(e) => {
                            const file = e.target.files[0];
                            // console.log('file => ', file);
                            //   const validTypes = ["image/jpeg", "image/png"];
                            const validTypes = [
                              "text/csv", // .csv
                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
                              "text/plain", // .txt
                            ];
                            const isFileValid = validTypes.includes(file.type);
                            if (file && isFileValid) {
                              setFieldValue("file", file);
                              showSnackBar(
                                "success",
                                "File Uploaded Successfully"
                              );
                              // setFieldTouched('file', true);
                            } else if (file.size > 2097152) {
                              // 2 MB limit
                              setFieldError(
                                "file",
                                "File size must be less than 2 MB"
                              );
                              e.target.value = ""; // Reset the input
                            } else {
                              setFieldValue("file", null);
                              showSnackBar("error", "Invalid File Format");
                            }
                          }}
                          onBlur={handleBlur}
                        />
                      </Box>
                    ) : (
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                        }}
                      >
                        <Typography
                          sx={{
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            maxWidth: "fit-content",
                          }}
                        >
                          Uploaded File:&nbsp;&nbsp;
                          {typeof values.file === "object"
                            ? values.file?.name
                            : rowData?.file}
                        </Typography>

                        <IconButton onClick={() => setFieldValue("file", null)}>
                          <CloseIcon />
                        </IconButton>
                      </Box>
                    )}
                    {errors?.file && touched?.file && (
                      <FormHelperText error>{errors?.file}</FormHelperText>
                    )}
                  </Grid>
                )}
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={closeModal}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                >
                  Close
                </Button>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values)}
                  disabled={!dirty || !isValid}
                >
                  Save
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default TrackingUrlForm;
