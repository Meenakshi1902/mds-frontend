import React, { useState } from "react";
import { Box, Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../../utils/common";
import SnackbarAlert from "../../../components/SnackBarMessage/SnackbarAlert";
import ModalComponent from "../../../components/ModalComponent/ModalComponent";
import { useSelector } from "react-redux";
import SheduleSmsForm from "../BulkSms/SheduleSmsForm/SheduleSmsForm";
import AddDynamicRcsForm from "./AddDynamicRcsForm/AddDynamicRcsForm";
import DynamicTable from "../../../components/DynamicTable/DynamicTable";

const DynamicRcsDetails = () => {
  //const [bulkSmsData, setBulkSmsData] = useState([]);
  const [dynamicRsSmsData, setDynamicRsSmsData] = useState([]);
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);
  const [previewData, setPreviewData] = useState([]);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      setSelectedRowData([]);
    }
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      {/* Header with title and add button */}
      <Grid
        container
        display="flex"
        justifyContent="space-between"
        flexDirection="row"
      >
        <Grid display="flex" justifyContent="flex-start">
          <Typography
            variant="h5"
            noWrap
            sx={{
              paddingLeft: "15px",
              fontWeight: 700,
            }}
          >
            Dynamic RCS Details
          </Typography>
        </Grid>
      </Grid>
      <AddDynamicRcsForm
        showSnackBar={showSnackBar}
        setEnableAddForm={setEnableAddForm}
        setDynamicRsSmsData={setDynamicRsSmsData}
        dynamicRsSmsData={dynamicRsSmsData}
        setPreviewData={setPreviewData}
        previewData={previewData}
      />

      <ModalComponent
        style={style}
        closeModal={closeModal}
        enableAddForm={enableAddForm}
      >
        {enableAddForm && enableAddForm === "dynamicRcsSheduleModal" && (
          <SheduleSmsForm
            bulkSmsData={dynamicRsSmsData}
            setBulkSmsData={setDynamicRsSmsData}
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            enableAddForm={enableAddForm}
          />
        )}
        {enableAddForm && enableAddForm === "previewModal" && (
          <DynamicTable title="Message Preview" data={previewData} />
        )}
      </ModalComponent>
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default DynamicRcsDetails;
