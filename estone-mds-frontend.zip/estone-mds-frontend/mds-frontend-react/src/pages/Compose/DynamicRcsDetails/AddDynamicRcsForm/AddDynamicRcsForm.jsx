import React, { useCallback, useEffect, useRef, useState } from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  FormHelperText,
  IconButton,
  Stack,
} from "@mui/material";
import { mixed, object, string } from "yup";
import {
  botType,
  fetchGetDropDownData,
  fetchPostDropDownData,
  templateType,
  templateTypeData,
} from "../../../../utils/common";
import {
  postDocumentRequest,
  postRequest,
} from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import DynamicTable from "../../../../components/DynamicTable/DynamicTable";

const AddDynamicRcsForm = ({
  showSnackBar,
  setEnableAddForm,
  setPreviewData,
  dynamicRsSmsData,
  setDynamicRsSmsData,
  previewData,
}) => {
  const documentFileRef = React.useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const messageRef = useRef(null);
  const [uploadFileData, setUploadFileData] = useState([]);
  const placeHolderData = uploadFileData?.placeholder;
  const [fileData, setFileData] = useState([]);
  const [columns, setColumns] = useState([]); // dynamic columns
  const [templateData, setTemplateData] = useState([]);
  const [botText, setBotText] = useState("");

  const initialValues = {
    template_type: "",
    bot_type: "",
    template_name: "",
    placeholder: "",
    message: "",
    campaign_name: "",
    file: null,
  };

  const validationSchema = object().shape({
    template_name: string().required("Template is required"),
    message: string().required("Message is required"),
    placeholder: string().required("Placeholder is required"),
    file: mixed()
      .required("Only CSV, Excel, files are required.")
      .test(
        "fileType",
        "Only CSV, Excel, files are allowed.",
        function (value) {
          if (value && value instanceof File) {
            const validTypes = [
              "text/csv", // .csv
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
              "application/vnd.ms-excel", // optional: .xls (older format)
            ];
            return validTypes.includes(value.type);
          }
          return true;
        }
      )
      .test("fileSize", "File size must be less than 2 MB", function (value) {
        if (value && value instanceof File) {
          return value.size <= 2097152;
        }
        return true;
      }),
    campaign_name: string().required("Campaign Name is required"),
  });

  const handlePreviewClick = (message, allData) => {
    const payload = {
      template: message || "",
      rows: allData || [],
    };

    postRequest(
      `generate-dynamic-message-preview`,
      payload,
      function (response) {
        if (!response?.data?.errors) {
          setPreviewData(response?.data?.messages);
        } else {
          // Handling error messages
          const errors = response?.data?.errors || {};

          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => {
                return {
                  field,
                  message: errorMessages.join(", "),
                };
              }
            );

            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
          setPreviewData([]);
        }
      }
    );
  };

  const handleUploadFile = (formData) => {
    postDocumentRequest(`upload-file`, formData, (response) => {
      if (!response?.data?.errors && response?.status === 200) {
        showSnackBar("success", "File uploaded successfully.");

        setUploadFileData(response?.data);

        const preview = response?.data?.preview;
        if (Array.isArray(preview) && preview.length > 1) {
          const [headerRow, ...dataRows] = preview;
          setColumns(headerRow);
          setFileData(dataRows);
        } else {
          setColumns([]);
          setFileData([]);
        }
      } else {
        const errors = response?.data?.errors || {};
        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else {
          Object.entries(errors).forEach(([field, messages]) => {
            showSnackBar("error", `${field}: ${messages.join(", ")}`);
          });
        }
      }
    });
  };

  const handleSubmit = async (payload, resetForm) => {
    // Create a safe copy for API submission

    const payloadForAPI = { ...payload };
    // Clean up the payload copy
    if (payloadForAPI?.file) {
      delete payloadForAPI.file;
    }
    if (payloadForAPI?.placeholder) {
      delete payloadForAPI.placeholder;
    }
    // Convert file to base64 if needed
    const sanitizedPayload = {
      ...payloadForAPI,
      template_type:
        payloadForAPI?.template_type === templateType?.[0]
          ? templateTypeData?.[0]
          : templateTypeData?.[1] || "",
      bot_type: payloadForAPI?.bot_type.toLowerCase() || "",
      messages: previewData || "",
      schedule_date: "",
      numbers_count: "",
    };
    try {
      postRequest(
        `rcs-send-dynamic-messages`,
        {
          ...sanitizedPayload,
        },
        (response) => {
          if (!response?.data?.errors && response?.status === 200) {
            showSnackBar("success", response.data.message);

            setDynamicRsSmsData((prev) => [...prev, sanitizedPayload]);
            resetForm();
            // closeModal();
          } else {
            const errors = response?.data?.errors || {};
            if (typeof errors === "string") {
              showSnackBar("error", errors);
            } else if (typeof errors === "object") {
              const mappedErrors = Object.entries(errors).map(
                ([field, errorMessages]) => ({
                  field,
                  message: errorMessages.join(", "),
                })
              );
              mappedErrors.forEach(({ field, message }) => {
                showSnackBar("error", `${field}: ${message}`);
              });
            }
          }
        }
      );
    } catch (err) {
      console.error("Error while processing file for original_url:", err);
      showSnackBar("error", "Failed to read the uploaded file.");
    }
  };

  useEffect(() => {
    if (!botText) return;
    const botData = botText.toLowerCase() || "";
    const payload = { bot_type: botData };
    fetchPostDropDownData(
      `fetch-rcs-template-details`,
      payload,
      setTemplateData,
      showSnackBar
    );
  }, [botText]);

  // Calculates character and SMS segment counts
  const calculateSMSCounts = (message = "", messageType) => {
    const messageLength = message.length;

    // Nothing typed → nothing to count
    if (messageLength === 0) {
      return { charCount: 0, smsCount: 0 };
    }

    // Segment size: 70 for Unicode, 160 otherwise (standard GSM‑7)
    const segmentSize = messageType === "Unicode" ? 70 : 160;

    // Always at least 1 segment once something is typed
    const smsCount = Math.ceil(messageLength / segmentSize);

    return { charCount: messageLength, smsCount };
  };

  const removePlaceholdersFromMessage = (placeholders = [], message = "") => {
    let cleanedMessage = message;

    placeholders.forEach((placeholder) => {
      const regex = new RegExp(`\\{${placeholder}\\}`, "g"); // match {name}, {city}, etc.
      cleanedMessage = cleanedMessage.replace(regex, "");
    });

    return cleanedMessage.trim();
  };

  const insertAtCursorPosition = (
    textareaRef,
    valueToInsert,
    currentValue,
    setValue
  ) => {
    const textarea = textareaRef.current;

    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;

    const newValue =
      currentValue.substring(0, start) +
      valueToInsert +
      currentValue.substring(end);

    setValue(newValue);

    // Set cursor position after inserted text
    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd =
        start + valueToInsert.length;
    }, 0);

    // Optionally clear the selected placeholder
    // setFieldValue("placeholder", "");
  };

  // Helper function for debouncing
  const debounce = (func, delay) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, delay);
    };
  };

  // Simulate an API call
  const makeApiCall = async (fieldName, value) => {
    // Replace this with your actual API call logic
    if (!value || !uploadFileData.all_data) {
      return;
    }
    try {
      handlePreviewClick(value, uploadFileData.all_data);
    } catch (error) {
      console.error("API call failed:", error);
    }
  };
  // Debounced version of the API call
  const debouncedApiCall = useCallback(
    debounce((fieldName, value) => makeApiCall(fieldName, value), 500), // 500ms debounce delay
    [uploadFileData.all_data]
  );

  return (
    <Box px={2}>
      {/* <Typography variant="h5">
        {isEdit ? "Edit Sender Details" : "Create Sender Details"}
      </Typography> */}
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={(values, { resetForm }) => {
          resetForm();
          //   setSubmitting(false); // End loading state
        }}
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          resetForm,
          isSubmitting,
          handleChange,
        }) => {
          useEffect(() => {
            if (values?.template_name && templateData?.length > 0) {
              const selectedTemplate = templateData.find(
                (template) => template.template_name === values.template_name
              );

              if (selectedTemplate) {
                setFieldValue("message", selectedTemplate.template_text);
              }
            }
          }, [values.template_name, templateData]);

          //   this useEffect hook will run when there is values in sms massegae
          useEffect(() => {
            if (values.message) {
              debouncedApiCall("message", values.message);
            }
          }, [values.message, uploadFileData]);

          return (
            <>
              <Box sx={{ width: "32.4%", mb: 3 }}>
                {/* Upload File Field */}
                {values?.file === null ? (
                  <Box>
                    <Button
                      name="file"
                      id="file"
                      variant="outlined"
                      fullWidth
                      startIcon={<CloudUploadIcon />}
                      // onClick={() => documentFileRef.current.click()}
                      onClick={() => {
                        documentFileRef.current.click();
                        // Mark the field as touched when clicking the upload button
                        // setFieldTouched('file', true);
                      }}
                      // disabled={values?.support_url !== ""}
                      sx={{
                        color: "#1976d2",
                        borderColor:
                          errors?.file && touched?.file
                            ? "error.main"
                            : "#1976d2",
                        borderRadius: "10rem",
                        "&:hover": {
                          color: "#FFFFFF",
                          backgroundColor: "#1976d2",
                        },
                      }}
                      onBlur={handleBlur}
                    >
                      Upload File *
                      <VisuallyHiddenInput type="file" />
                    </Button>
                    <input
                      ref={documentFileRef}
                      accept=".csv, .xlsx"
                      type="file"
                      name="file"
                      id="file"
                      style={{ display: "none" }}
                      //   onChange={(e) => {
                      //     const file = e.target.files[0];
                      //     // console.log('file => ', file);
                      //     //   const validTypes = ["image/jpeg", "image/png"];
                      //     const validTypes = [
                      //       "text/csv", // .csv
                      //       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
                      //     ];
                      //     const isFileValid = validTypes.includes(file.type);
                      //     if (file && isFileValid) {
                      //       setFieldValue("file", file);
                      //       showSnackBar("success", "File Uploaded Successfully");
                      //       // setFieldTouched('file', true);
                      //     } else if (file.size > 2097152) {
                      //       // 2 MB limit
                      //       setFieldError(
                      //         "file",
                      //         "File size must be less than 2 MB"
                      //       );
                      //       e.target.value = ""; // Reset the input
                      //     } else {
                      //       setFieldValue("file", null);
                      //       showSnackBar("error", "Invalid File Format");
                      //     }
                      //   }}
                      onChange={(e) => {
                        const file = e.target.files[0];
                        const validTypes = [
                          "text/csv",
                          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        ];
                        const isFileValid =
                          file && validTypes.includes(file.type);

                        if (isFileValid) {
                          setFieldValue("file", file);
                          showSnackBar("success", "File Uploaded Successfully");

                          const formData = new FormData();
                          formData.append("file", file);

                          // setFieldValue("to", "");

                          handleUploadFile(formData); // ✅ send only FormData
                        } else if (file?.size > 2097152) {
                          setFieldError(
                            "file",
                            "File size must be less than 2 MB"
                          );
                          e.target.value = "";
                        } else {
                          setFieldValue("file", null);
                          showSnackBar("error", "Invalid File Format");
                        }
                      }}
                      onBlur={handleBlur}
                    />
                  </Box>
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        maxWidth: "fit-content",
                      }}
                    >
                      Uploaded File:&nbsp;&nbsp;
                      {typeof values.file === "object"
                        ? values.file?.name
                        : null}
                    </Typography>

                    <IconButton
                      onClick={() => {
                        setFieldValue("file", null);
                        setFieldValue("placeholder", "");
                        const cleanedMessage = removePlaceholdersFromMessage(
                          uploadFileData?.placeholder || [],
                          values.message
                        );

                        setFieldValue("message", cleanedMessage);

                        setUploadFileData([]); // also clear placeholderData and preview
                      }}
                    >
                      <CloseIcon />
                    </IconButton>
                  </Box>
                )}

                {errors?.file && touched?.file && (
                  <FormHelperText error>{errors?.file}</FormHelperText>
                )}
              </Box>
              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                {values?.file && (
                  <Grid size={{ xs: 12 }}>
                    {/* Show API table response here */}
                    {columns.length > 0 && fileData.length > 0 && (
                      <DynamicTable
                        title="Uploaded File Details"
                        data={fileData}
                        columns={columns}
                      />
                    )}
                  </Grid>
                )}
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="template_type"
                    id="template_type"
                    label="Message Type *"
                    multiple={false}
                    // disableClearable={true}
                    options={templateType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      templateType?.find(
                        (type) => type === values?.template_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("template_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 3.7 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="bot_type"
                    id="bot_type"
                    label="Select Bot Type *"
                    multiple={false}
                    // disableClearable={true}
                    options={botType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      botType?.find((type) => type === values?.bot_type) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("template_name", "");
                      setFieldValue("bot_type", value || "");

                      if (value) {
                        setBotText(value);
                      }
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="template_name"
                    id="template_name"
                    label="Select Template *"
                    multiple={false}
                    options={templateData || []}
                    getOptionLabel={(option) => option?.template_name || ""}
                    value={
                      templateData?.find(
                        (type) => type?.template_name === values?.template_name
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.template_name === value?.template_name
                    }
                    onChange={(e, value) => {
                      setFieldValue(
                        "template_name",
                        value?.template_name || ""
                      );
                    }}
                    disabled={!values?.bot_type}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="placeholder"
                    id="placeholder"
                    label="Insert Placeholder *"
                    multiple={false}
                    disableClearable={true}
                    options={placeHolderData || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      placeHolderData?.find(
                        (type) => type === values?.placeholder
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    // onChange={(e, value) => {
                    //   setFieldValue("placeholder", value || "");
                    // }}
                    onChange={(e, value) => {
                      if (!value) return;
                      setFieldValue("placeholder", value || ""); // plz remove if you used this one -  setFieldValue("placeholder", "");

                      const formattedPlaceholder = `{${value}}`;

                      insertAtCursorPosition(
                        messageRef,
                        formattedPlaceholder,
                        values.message,
                        (newVal) => setFieldValue("message", newVal)
                      );

                      // Optionally clear the selected placeholder
                      // setFieldValue("placeholder", "");
                    }}
                    disabled={!placeHolderData}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Stack>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        mb: 1,
                      }}
                    >
                      <Typography
                        variant="body1"
                        component="label"
                        htmlFor="message"
                        sx={{ display: "flex", alignItems: "center" }}
                      >
                        SMS Message
                        <Typography
                          component="span"
                          sx={{ color: "red", ml: 0.5 }}
                        >
                          *
                        </Typography>
                      </Typography>
                    </Box>

                    <TextareaAutosize
                      ref={messageRef}
                      name="message"
                      id="message"
                      aria-label="message"
                      minRows={3}
                      placeholder="Type Message Here"
                      value={!values?.template_name ? "" : values.message}
                      disabled={!values?.template_name}
                      //   onChange={handleChange}
                      onChange={(e) => {
                        handleChange(e); // Let Formik handle the change
                        debouncedApiCall(e.target.name, e.target.value); // Trigger API call with debounce
                      }}
                      onBlur={handleBlur}
                      style={{
                        width: "100%",
                        maxWidth: "800px",
                        height: "auto",
                        padding: "8px",
                      }}
                      // disabled={true}
                    />
                    {errors?.message && touched?.message && (
                      <FormHelperText error>{errors?.message}</FormHelperText>
                    )}
                    {/* Message Preview Button */}
                    <Box
                      sx={{
                        display: "flex",
                        //   justifyContent: "center",
                        mt: 1,
                      }}
                    >
                      <Button
                        type="button"
                        variant="outlined"
                        onClick={() => {
                          setEnableAddForm("previewModal");
                          handlePreviewClick(
                            values.message,
                            uploadFileData.all_data
                          );
                        }}
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: "7px 16px 7px",
                          border: "1px solid #1976d2",
                          borderRadius: "10rem",
                          boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                          transition: "all 0.3s ease",
                          color: "#1976d2",
                          fontSize: "14px",
                          textTransform: "none",
                          "&:hover": {
                            backgroundColor: "#1976d2",
                            color: "#fff",
                            borderColor: "#1976d2",
                          },
                        }}
                        disabled={
                          !values.message ||
                          !uploadFileData.all_data ||
                          !values?.template_name
                        }
                      >
                        Message Preview
                      </Button>
                    </Box>
                  </Stack>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="campaign_name"
                    id="campaign_name"
                    label="Campaign Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                    // disabled={values?.method === "Groups" ? false : true}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2} gap={2}>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA", // soft purple background
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values, resetForm)}
                  disabled={!dirty || !isValid}
                >
                  Send SMS
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
                <Button
                  variant="outlined"
                  onClick={() => {
                    setEnableAddForm("dynamicRcsSheduleModal");
                  }}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9", // soft yellow background
                    },
                  }}
                  disabled={dynamicRsSmsData?.length === 0}
                >
                  Shedule SMS
                </Button>
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddDynamicRcsForm;
