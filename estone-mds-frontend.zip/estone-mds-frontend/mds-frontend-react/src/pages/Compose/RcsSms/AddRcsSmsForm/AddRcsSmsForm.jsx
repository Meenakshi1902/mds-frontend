import React, {
  useEffect,
  useMemo,
  useRef,
  useState,
  useCallback,
  forwardRef,
  useImperativeHandle,
} from "react";
import { Formik } from "formik";
import {
  Grid,
  Box,
  Button,
  Divider,
  Typography,
  CircularProgress,
  TextareaAutosize,
  FormHelperText,
  IconButton,
  Stack,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
} from "@mui/material";
import { array, mixed, object, string } from "yup";
import {
  botType,
  fetchGetDropDownData,
  fetchPostDropDownData,
  method,
  templateType,
  templateTypeData,
} from "../../../../utils/common";
import {
  postDocumentRequest,
  postRequest,
} from "../../../../helpers/http.helper";
import { useSelector } from "react-redux";
import PersonIcon from "@mui/icons-material/Person";
import IconInputField from "../../../../components/IconInputField/IconInputField";
import IconAutocompleteField from "../../../../components/IconAutocompleteField/IconAutocompleteField";
import CheckboxInputAutocompleteField from "../../../../components/CheckboxInputAutocompleteField/CheckboxInputAutocompleteField";
import {
  CloudUpload as CloudUploadIcon,
  Close as CloseIcon,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import VariableFields from "../VariableFields/VariableFields";

const AddRcsSmsForm = ({
  showSnackBar,
  setEnableAddForm,
  bulkRcsSmsData,
  setBulkRcsSmsData,
}) => {
  const documentFileRef = React.useRef();
  const formikRef = useRef();

  const VisuallyHiddenInput = styled("input")({
    clip: "rect(0 0 0 0)",
    clipPath: "inset(50%)",
    height: 1,
    overflow: "hidden",
    position: "absolute",
    bottom: 0,
    left: 0,
    whiteSpace: "nowrap",
    width: 1,
  });

  const hasFetchedGroup = useRef(false);
  const debounceTimeout = useRef(null);

  const [groupAutocompleteOpen, setGroupAutocompleteOpen] = useState(false);
  const [groupUserData, setGroupUserData] = useState([]);
  const [templateData, setTemplateData] = useState([]);
  const [botText, setBotText] = useState("");
  const [formikValidDirtyData, setFormikValidDirtyData] = useState(false);
  const [variableListData, setVariableListData] = useState([]);
  const variableListBackup = useRef([]);
  const originalTemplate = useRef("");
  const [formData, setFormData] = useState({});
  const [formValues, setFormValues] = useState({});

  function useDebounce(callback, delay = 500) {
    const timer = useRef(null);

    const debouncedFunction = useCallback(
      (...args) => {
        if (timer.current) clearTimeout(timer.current);
        timer.current = setTimeout(() => {
          callback(...args);
        }, delay);
      },
      [callback, delay]
    );

    return debouncedFunction;
  }

  const initialValues = useMemo(
    () => ({
      template_type: "",
      bot_type: "",
      template_name: "",
      message: "",
      method: method[0],
      numbers: "",
      group_IDs: [],
      csv_file: null,
      campaign_name: "",
    }),
    [method]
  );

  const handleFetchVariable = (msg) => {
    const payload = { message: msg || "" };

    postRequest(`fetch-variables`, payload, function (response) {
      if (!response?.data?.errors) {
        const fetchedVariables = response?.data?.data || [];
        setVariableListData(fetchedVariables);

        if (
          variableListBackup.current.length === 0 &&
          fetchedVariables.length > 0
        ) {
          variableListBackup.current = fetchedVariables;
        }
      } else {
        const errors = response?.data?.errors || {};
        if (typeof errors === "string") {
          showSnackBar("error", errors);
        } else if (typeof errors === "object") {
          const mappedErrors = Object.entries(errors).map(
            ([field, messages]) => ({
              field,
              message: messages.join(", "),
            })
          );
          mappedErrors.forEach(({ field, message }) => {
            showSnackBar("error", `${field}: ${message}`);
          });
        }
      }
    });
  };

  const interpolateMessageWithVariables = (template, data) => {
    if (!template) return "";
    return template.replace(/[{[](\w+)[}\]]/g, (_, key) => {
      const matchedKey = Object.keys(data).find(
        (k) => k.toLowerCase() === key.toLowerCase()
      );
      return matchedKey ? data[matchedKey] : `{${key}}`;
    });
  };

  const debouncedUpdateMessage = useDebounce(() => {
    if (formikRef.current?.setFieldValue) {
      const updated = interpolateMessageWithVariables(
        originalTemplate.current,
        formData
      );
      formikRef.current.setFieldValue("message", updated);
    }
  }, 400);

  // Move all useEffects outside of Formik
  useEffect(() => {
    if (hasFetchedGroup.current) return;
    fetchGetDropDownData(`fetch-group-details`, setGroupUserData, showSnackBar);
    hasFetchedGroup.current = true;
  }, []);

  useEffect(() => {
    if (!botText) return;
    const botData = botText.toLowerCase() || "";
    const payload = { bot_type: botData };
    fetchPostDropDownData(
      `fetch-rcs-template-details`,
      payload,
      setTemplateData,
      showSnackBar
    );
  }, [botText]);

  // Watch formData changes
  useEffect(() => {
    debouncedUpdateMessage();
  }, [formData, debouncedUpdateMessage]);

  // Populate message based on template_name
  useEffect(() => {
    if (formValues?.template_name && templateData?.length > 0) {
      const selectedTemplate = templateData.find(
        (template) => template.template_name === formValues.template_name
      );

      if (selectedTemplate && formikRef.current?.setFieldValue) {
        const newTemplateText = selectedTemplate.template_text;
        formikRef.current.setFieldValue("message", newTemplateText);
        originalTemplate.current = newTemplateText;
      }
    } else if (!formValues?.template_name && formikRef.current?.setFieldValue) {
      setVariableListData([]);
      variableListBackup.current = [];
      setFormData({});
      originalTemplate.current = "";
      formikRef.current.setFieldValue("message", "");
    }
  }, [formValues.template_name, templateData]);

  // Additional effect to clear message when both bot_type and template_name are empty
  useEffect(() => {
    if (
      !formValues?.bot_type &&
      !formValues?.template_name &&
      formikRef.current?.setFieldValue
    ) {
      setVariableListData([]);
      variableListBackup.current = [];
      setFormData({});
      originalTemplate.current = "";
      formikRef.current.setFieldValue("message", "");
    }
  }, [formValues.bot_type, formValues.template_name]);

  // Modified debounce effect with bot_type and template_name checks
  useEffect(() => {
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    if (
      formValues?.message &&
      formValues?.bot_type &&
      formValues?.template_name
    ) {
      debounceTimeout.current = setTimeout(() => {
        handleFetchVariable(formValues.message);
      }, 500);
    } else if (!formValues?.message && formikRef.current?.setFieldValue) {
      setVariableListData([]);
      setFormData({});
      variableListBackup.current = [];

      if (formValues.message !== "") {
        formikRef.current.setFieldValue("message", "");
      }
    }

    return () => {
      if (debounceTimeout.current) {
        clearTimeout(debounceTimeout.current);
      }
    };
  }, [formValues.message, formValues.bot_type, formValues.template_name]);

  const validationSchema = object().shape({
    template_type: string().required("Message Type is required"),
    bot_type: string().required("Bot Type is required"),
    template_name: string().required("Template is required"),
    message: string().required("Message is required"),
    method: string().required("Message Format is required"),
    numbers: string().when("method", {
      is: "Numbers",
      then: (schema) => schema.required("Numbers is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    group_IDs: array().when("method", {
      is: "Groups",
      then: (schema) =>
        schema
          .of(
            object().shape({
              id: mixed().required("Group ID is required"),
            })
          )
          .min(1, "At least one Group ID is required")
          .required("Group ID is required"),
      otherwise: (schema) => schema.notRequired(),
    }),
    csv_file: mixed().when("method", {
      is: "CSV",
      then: (schema) =>
        schema
          .required("CSV file is required")
          .test(
            "fileType",
            "Only CSV, XLSX, or TXT files are allowed.",
            function (value) {
              if (value && value instanceof File) {
                const validTypes = [
                  "text/csv",
                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                  "text/plain",
                ];
                return validTypes.includes(value.type);
              }
              return true;
            }
          )
          .test(
            "fileSize",
            "File size must be less than 2 MB",
            function (value) {
              if (value && value instanceof File) {
                return value.size <= 2 * 1024 * 1024;
              }
              return true;
            }
          ),
      otherwise: (schema) => schema.notRequired(),
    }),
    campaign_name: string().required("Campaign Name is required"),
  });

  const normalizeNumbers = (input = "") => {
    return input
      .split(/[\n, ]+/)
      .map((num) => num.trim())
      .filter((num) => num !== "")
      .join(",");
  };

  const handleSubmit = async (payload, resetForm) => {
    const payloadForAPI = { ...payload };

    if (payloadForAPI?.method === "Numbers") {
      payloadForAPI.numbers = normalizeNumbers(payloadForAPI?.numbers) || "";
      delete payloadForAPI.group_IDs;
      delete payloadForAPI.csv_file;
    } else if (payloadForAPI?.method === "Groups") {
      payloadForAPI.group_IDs =
        payloadForAPI?.group_IDs?.map((group) => group.id) || [];
      delete payloadForAPI.numbers;
      delete payloadForAPI.csv_file;
    } else if (payloadForAPI?.method === "CSV") {
      payloadForAPI.csv_file = payloadForAPI?.csv_file || "";
      delete payloadForAPI.numbers;
      delete payloadForAPI.group_IDs;
    } else {
      delete payloadForAPI.numbers;
      delete payloadForAPI.group_IDs;
      delete payloadForAPI.csv_file;
    }

    const sanitizedPayload = {
      ...payloadForAPI,
      template_type:
        payloadForAPI?.template_type === templateType[0]
          ? templateTypeData[0]
          : templateTypeData[1],
      bot_type: payloadForAPI?.bot_type?.toLowerCase() || "",
      template_name: String(payloadForAPI?.template_name || ""),
      message: payloadForAPI?.message || "",
      method: payloadForAPI?.method || "",
      campaign_name: payloadForAPI?.campaign_name || "",
    };

    const requestMethod = payloadForAPI?.csv_file
      ? postDocumentRequest
      : postRequest;

    try {
      requestMethod(`rcs-send-messages`, sanitizedPayload, (response) => {
        if (!response?.data?.errors && response?.status === 200) {
          showSnackBar("success", response.data.message);
          setBulkRcsSmsData((prev) => [...prev, sanitizedPayload]);
          resetForm();
        } else {
          const errors = response?.data?.errors || {};
          if (typeof errors === "string") {
            showSnackBar("error", errors);
          } else if (typeof errors === "object") {
            const mappedErrors = Object.entries(errors).map(
              ([field, errorMessages]) => ({
                field,
                message: errorMessages.join(", "),
              })
            );
            mappedErrors.forEach(({ field, message }) => {
              showSnackBar("error", `${field}: ${message}`);
            });
          }
        }
      });
    } catch (err) {
      console.error("Error while processing file for original_url:", err);
      showSnackBar("error", "Failed to read the uploaded file.");
    }
  };

  const getValidMobileNumbersCount = (input) => {
    if (!input) return 0;

    const mobileRegex = /^\d{8,}$/;

    return input
      .split(/[\n,]+/)
      .map((num) => num.trim())
      .filter((num) => mobileRegex.test(num)).length;
  };

  // Create a wrapper component to expose Formik methods
  const FormikWrapper = forwardRef((props, ref) => {
    useImperativeHandle(ref, () => ({
      setFieldValue: props.setFieldValue,
      values: props.values,
    }));

    // Update formValues whenever Formik values change
    useEffect(() => {
      setFormValues(props.values);
    }, [props.values]);

    return null;
  });

  return (
    <Box px={2}>
      <Divider sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }} />
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
      >
        {({
          setFieldValue,
          errors,
          touched,
          values,
          dirty,
          isValid,
          handleBlur,
          resetForm,
          isSubmitting,
          handleChange,
        }) => {
          return (
            <>
              <FormikWrapper
                ref={formikRef}
                setFieldValue={setFieldValue}
                values={values}
              />

              <Grid
                container
                rowSpacing={2}
                cellSpacing={2}
                columnSpacing={{ xs: 1, sm: 2, md: 2 }}
              >
                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="template_type"
                    id="template_type"
                    label="Message Type *"
                    multiple={false}
                    options={templateType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      templateType?.find(
                        (type) => type === values?.template_type
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("template_type", value || "");
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 3.7 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="bot_type"
                    id="bot_type"
                    label="Select Bot Type *"
                    multiple={false}
                    options={botType || []}
                    getOptionLabel={(option) => option || ""}
                    value={
                      botType?.find((type) => type === values?.bot_type) || null
                    }
                    isOptionEqualToValue={(option, value) => option === value}
                    onChange={(e, value) => {
                      setFieldValue("message", "");
                      setFieldValue("template_name", "");
                      setFieldValue("bot_type", value || "");

                      if (value) {
                        setBotText(value);
                      }
                    }}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconAutocompleteField
                    icon={PersonIcon}
                    name="template_name"
                    id="template_name"
                    label="Select Template *"
                    multiple={false}
                    options={templateData || []}
                    getOptionLabel={(option) => option?.template_name || ""}
                    value={
                      templateData?.find(
                        (type) => type?.template_name === values?.template_name
                      ) || null
                    }
                    isOptionEqualToValue={(option, value) =>
                      option?.template_name === value?.template_name
                    }
                    onChange={(e, value) => {
                      setFieldValue("message", "");
                      setFormData({});
                      variableListBackup.current = [];
                      setFieldValue(
                        "template_name",
                        value?.template_name || ""
                      );
                    }}
                    disabled={!values?.bot_type}
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Stack>
                    <Typography sx={{ fontWeight: "bold" }}>
                      Message Format
                    </Typography>
                    <FormControl component="fieldset">
                      <RadioGroup
                        row
                        name="method"
                        value={values.method}
                        onChange={(e) =>
                          setFieldValue("method", e.target.value)
                        }
                      >
                        <FormControlLabel
                          value="Numbers"
                          control={<Radio />}
                          label="Numbers"
                        />
                        <FormControlLabel
                          value="Groups"
                          control={<Radio />}
                          label="Groups"
                        />
                        <FormControlLabel
                          value="CSV"
                          control={<Radio />}
                          label="CSV"
                        />
                      </RadioGroup>
                    </FormControl>

                    {values?.method === "Numbers" && (
                      <>
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            mb: 1,
                          }}
                        >
                          <Typography
                            variant="body1"
                            component="label"
                            htmlFor="numbers"
                            sx={{ display: "flex", alignItems: "center" }}
                          >
                            Numbers
                            <Typography
                              component="span"
                              sx={{ color: "red", ml: 0.5 }}
                            >
                              *
                            </Typography>
                          </Typography>
                        </Box>

                        <TextareaAutosize
                          name="numbers"
                          id="numbers"
                          aria-label="numbers"
                          minRows={3}
                          placeholder="Type Numbers Separated by New Line"
                          value={values.numbers}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          style={{
                            width: "100%",
                            maxWidth: "800px",
                            height: "auto",
                            padding: "8px",
                          }}
                        />
                        {errors?.numbers && touched?.numbers && (
                          <FormHelperText error>
                            {errors?.numbers}
                          </FormHelperText>
                        )}

                        <Box
                          sx={{
                            display: "flex",
                            justifyContent: "space-between",
                            gap: 2,
                            mt: 1.5,
                            color: "#1976d2",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              padding: "8px 12px",
                              border: "1px solid #1976d2",
                              borderRadius: "10rem",
                              boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
                              transition: "all 0.3s ease",
                              "&:hover": {
                                backgroundColor: "#1976d2",
                                color: "#fff",
                              },
                            }}
                          >
                            <Typography variant="body2">
                              No's :{" "}
                              {getValidMobileNumbersCount(values.numbers)}
                            </Typography>
                          </Box>
                        </Box>
                      </>
                    )}

                    {values?.method === "Groups" && (
                      <>
                        <CheckboxInputAutocompleteField
                          icon={PersonIcon}
                          id="group_IDs"
                          name="group_IDs"
                          label="Select Groups: *"
                          options={groupUserData || []}
                          getOptionLabel={(option) => option?.group_name}
                          getOptionValue={(option) => option?.id}
                          getDisplayValue={(option) => option?.group_name}
                          value={values?.group_IDs}
                          setFieldValue={setFieldValue}
                          handleBlur={handleBlur}
                          errors={errors}
                          touched={touched}
                          autoCompleteOpen={groupAutocompleteOpen}
                          setAutoCompleteOpen={setGroupAutocompleteOpen}
                        />
                      </>
                    )}

                    {values?.method === "CSV" && (
                      <>
                        {values?.csv_file === null ? (
                          <Box>
                            <Button
                              name="csv_file"
                              id="csv_file"
                              variant="outlined"
                              fullWidth
                              startIcon={<CloudUploadIcon />}
                              onClick={() => {
                                documentFileRef.current.click();
                              }}
                              sx={{
                                color: "#1976d2",
                                borderColor:
                                  errors?.csv_file && touched?.csv_file
                                    ? "error.main"
                                    : "#1976d2",
                                borderRadius: "10rem",
                                "&:hover": {
                                  color: "#FFFFFF",
                                  backgroundColor: "#1976d2",
                                },
                              }}
                              onBlur={handleBlur}
                            >
                              Upload File *
                              <VisuallyHiddenInput type="file" />
                            </Button>
                            <input
                              ref={documentFileRef}
                              accept=".csv, .xlsx, .txt"
                              type="file"
                              name="csv_file"
                              id="csv_file"
                              style={{ display: "none" }}
                              onChange={(e) => {
                                const file = e.target.files[0];
                                const validTypes = [
                                  "text/csv",
                                  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                  "text/plain",
                                ];
                                const isFileValid = validTypes.includes(
                                  file.type
                                );
                                if (file && isFileValid) {
                                  setFieldValue("csv_file", file);
                                  showSnackBar(
                                    "success",
                                    "File Uploaded Successfully"
                                  );
                                } else if (file.size > 2097152) {
                                  setFieldError(
                                    "csv_file",
                                    "File size must be less than 2 MB"
                                  );
                                  e.target.value = "";
                                } else {
                                  setFieldValue("csv_file", null);
                                  showSnackBar("error", "Invalid File Format");
                                }
                              }}
                              onBlur={handleBlur}
                            />
                          </Box>
                        ) : (
                          <Box
                            sx={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                            }}
                          >
                            <Typography
                              sx={{
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                maxWidth: "fit-content",
                              }}
                            >
                              Uploaded File:&nbsp;&nbsp;
                              {typeof values.csv_file === "object"
                                ? values.csv_file?.name
                                : null}
                            </Typography>

                            <IconButton
                              onClick={() => setFieldValue("csv_file", null)}
                            >
                              <CloseIcon />
                            </IconButton>
                          </Box>
                        )}
                        {errors?.csv_file && touched?.csv_file && (
                          <FormHelperText error>
                            {errors?.csv_file}
                          </FormHelperText>
                        )}
                      </>
                    )}
                  </Stack>
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <VariableFields
                    variableListData={
                      variableListData.length > 0
                        ? variableListData
                        : variableListBackup.current
                    }
                    setFormikValidDirtyData={setFormikValidDirtyData}
                    formData={formData}
                    setFormData={setFormData}
                  />
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      mb: 1,
                    }}
                  >
                    <Typography
                      variant="body1"
                      component="label"
                      htmlFor="message"
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      Message
                      <Typography
                        component="span"
                        sx={{ color: "red", ml: 0.5 }}
                      >
                        *
                      </Typography>
                    </Typography>
                  </Box>

                  <TextareaAutosize
                    name="message"
                    id="message"
                    aria-label="message"
                    minRows={3}
                    placeholder="Type Message Here"
                    value={values.message}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    style={{
                      width: "100%",
                      maxWidth: "800px",
                      height: "auto",
                      padding: "8px",
                    }}
                    disabled
                  />
                  {errors?.message && touched?.message && (
                    <FormHelperText error>{errors?.message}</FormHelperText>
                  )}
                </Grid>

                <Grid size={{ xs: 12, sm: 8, md: 4 }}>
                  <IconInputField
                    icon={PersonIcon}
                    name="campaign_name"
                    id="campaign_name"
                    label="Campaign Name *"
                    errors={errors}
                    touched={touched}
                    handleBlur={handleBlur}
                  />
                </Grid>
              </Grid>
              <Divider
                sx={{ marginBlockStart: "1rem", marginBlockEnd: "1rem" }}
              />
              <Box display="flex" justifyContent="flex-end" mt={2} gap={2}>
                <Button
                  variant="outlined"
                  sx={{
                    borderColor: "#7F55B1",
                    color: "#7F55B1",
                    "&:hover": {
                      borderColor: "#7F55B1",
                      backgroundColor: "#EEE6FA",
                    },
                  }}
                  type="submit"
                  onClick={() => handleSubmit(values, resetForm)}
                  disabled={!dirty || !isValid || !formikValidDirtyData}
                >
                  Send SMS
                </Button>
                {isSubmitting && <CircularProgress size={24} />}
                <Button
                  variant="outlined"
                  onClick={() => setEnableAddForm("SheduleRcsSmsModal")}
                  sx={{
                    borderColor: "#FED16A",
                    color: "#FED16A",
                    mr: 2,
                    "&:hover": {
                      borderColor: "#FED16A",
                      backgroundColor: "#FFF5D9",
                    },
                  }}
                  disabled={bulkRcsSmsData?.length === 0}
                >
                  Shedule SMS
                </Button>
              </Box>
            </>
          );
        }}
      </Formik>
    </Box>
  );
};

export default AddRcsSmsForm;
