import React, { useEffect, useState } from "react";
import { Box, Grid, Typography } from "@mui/material";
import { defaultSnackBarState } from "../../../utils/common";
import SnackbarAlert from "../../../components/SnackBarMessage/SnackbarAlert";
import ModalComponent from "../../../components/ModalComponent/ModalComponent";
import { useSelector } from "react-redux";
import SheduleSmsForm from "../BulkSms/SheduleSmsForm/SheduleSmsForm";
import AddRcsSmsForm from "./AddRcsSmsForm/AddRcsSmsForm";

const RcsSms = () => {
  const [bulkRcsSmsData, setBulkRcsSmsData] = useState([]);
  const [enableAddForm, setEnableAddForm] = useState(null);
  const [snackbarState, setSnackbarState] = useState(defaultSnackBarState);

  const closeModal = (event, reason) => {
    if (reason !== "backdropClick") {
      setEnableAddForm(null);
      // setSelectedRowData([]);
    }
  };

  const showSnackBar = (type, message) => {
    setSnackbarState({
      show: true,
      type: type,
      message: message,
      vertical: "bottom",
      horizontal: "center",
    });
    hideSnackBar();
  };

  const hideSnackBar = () => {
    setTimeout(() => {
      setSnackbarState(defaultSnackBarState);
    }, 3000);
  };

  const style = {
    position: "absolute",
    top: "20%",
    left: "58%",
    transform: "translate(-50%, -20%)",
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
    width: "80%",
  };

  return (
    <>
      {/* Header with title and add button */}
      <Grid
        container
        display="flex"
        justifyContent="space-between"
        flexDirection="row"
      >
        <Grid display="flex" justifyContent="flex-start">
          <Typography
            variant="h5"
            noWrap
            sx={{
              paddingLeft: "15px",
              fontWeight: 700,
            }}
          >
            Rcs SMS Details
          </Typography>
        </Grid>
      </Grid>
      <AddRcsSmsForm
        closeModal={closeModal}
        showSnackBar={showSnackBar}
        setEnableAddForm={setEnableAddForm}
        setBulkRcsSmsData={setBulkRcsSmsData}
        bulkRcsSmsData={bulkRcsSmsData}
      />

      <ModalComponent
        style={style}
        closeModal={closeModal}
        enableAddForm={enableAddForm}
      >
        {enableAddForm && enableAddForm === "SheduleRcsSmsModal" && (
          <SheduleSmsForm
            closeModal={closeModal}
            showSnackBar={showSnackBar}
            enableAddForm={enableAddForm}
            bulkSmsData={bulkRcsSmsData}
            setBulkSmsData={setBulkRcsSmsData}
          />
        )}
      </ModalComponent>
      {snackbarState?.show && (
        <SnackbarAlert
          open={snackbarState?.show}
          message={snackbarState?.message}
          severity={snackbarState?.type}
          vertical={snackbarState?.vertical}
          horizontal={snackbarState?.horizontal}
        />
      )}
    </>
  );
};

export default RcsSms;
