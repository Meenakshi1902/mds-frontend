import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Typography,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Paper,
  TextField,
} from "@mui/material";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";

const VariableFields = ({
  variableListData,
  formData,
  setFormData,
  setFormikValidDirtyData,
}) => {
  const prevValidationResult = useRef(null);

  // Create initial values from formData or default to empty
  const initialValues = variableListData.reduce((acc, field) => {
    acc[field] = formData[field] || "";
    return acc;
  }, {});

  // Create validation schema dynamically
  const validationSchema =
    variableListData.length > 0
      ? Yup.object(
          variableListData.reduce((acc, field) => {
            acc[field] = Yup.string().required(`${field} required`);
            return acc;
          }, {})
        )
      : Yup.object();

  // Handle validation logic outside of Formik render
  useEffect(() => {
    const hasVariables = variableListData.length > 0;

    let isFormValid;

    if (!hasVariables) {
      // No variables = always valid
      isFormValid = true;
    } else {
      // Check if all variable fields are filled
      const allFieldsFilled = variableListData.every((field) => {
        const fieldValue = formData[field];
        return fieldValue && fieldValue.trim() !== "";
      });

      // Check if any field has actual content
      const anyFieldHasContent = variableListData.some((field) => {
        const fieldValue = formData[field];
        return fieldValue && fieldValue.trim() !== "";
      });

      isFormValid = allFieldsFilled && anyFieldHasContent;
    }

    // Only update if the validation result has changed
    if (prevValidationResult.current !== isFormValid) {
      prevValidationResult.current = isFormValid;
      setFormikValidDirtyData(isFormValid);
    }
  }, [formData, variableListData]);

  return (
    <Box px={2}>
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        enableReinitialize
        onSubmit={() => {}}
      >
        {({ errors, touched, setFieldValue }) => {
          return (
            <Form>
              <Box sx={{ maxWidth: 500 }}>
                <Typography
                  variant="subtitle1"
                  sx={{ fontWeight: 600, mb: 0.5 }}
                >
                  Variable Values
                </Typography>

                <Box
                  sx={{
                    minHeight: 100,
                    maxHeight: 120,
                    overflowY: "auto",
                  }}
                >
                  <TableContainer component={Paper} variant="outlined">
                    <Table size="small">
                      <TableBody>
                        {variableListData.length > 0 ? (
                          variableListData.map((variable, idx) => (
                            <TableRow key={idx}>
                              <TableCell sx={{ width: "30%", fontWeight: 500 }}>
                                {variable}
                              </TableCell>
                              <TableCell>
                                <Field name={variable}>
                                  {({ field }) => (
                                    <TextField
                                      {...field}
                                      fullWidth
                                      size="small"
                                      variant="outlined"
                                      value={formData[variable] || ""}
                                      placeholder={`Enter ${variable}`}
                                      onChange={(e) => {
                                        const val = e.target.value;
                                        setFormData((prev) => ({
                                          ...prev,
                                          [variable]: val,
                                        }));
                                        setFieldValue(variable, val);
                                      }}
                                      onBlur={(e) => {
                                        field.onBlur(e);
                                      }}
                                      error={
                                        touched[variable] &&
                                        Boolean(errors[variable])
                                      }
                                      helperText={
                                        touched[variable] && errors[variable]
                                      }
                                    />
                                  )}
                                </Field>
                              </TableCell>
                            </TableRow>
                          ))
                        ) : (
                          <TableRow>
                            <TableCell colSpan={2} align="center">
                              <Typography
                                variant="body2"
                                color="text.secondary"
                              >
                                No variables available.
                              </Typography>
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              </Box>
            </Form>
          );
        }}
      </Formik>
    </Box>
  );
};

export default VariableFields;
