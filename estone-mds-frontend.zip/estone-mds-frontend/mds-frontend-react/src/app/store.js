import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../features/auth/authSlice';
import dropDownReducer from '../features/dropdown/dropDownSlice'

export const store = configureStore({
  reducer: {
    auth: authReducer,
    dropdown: dropDownReducer,
  },
});