import * as React from "react";
import { styled, useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Collapse from "@mui/material/Collapse";
import Tooltip from "@mui/material/Tooltip";
import {
  BarChart,
  Language,
  Layers,
  Send,
  Settings,
  Dashboard as DashboardIcon,
} from "@mui/icons-material";
import mdslogo from "../assets/logos/mdslogo.png";
import { Outlet, useLocation, useNavigate } from "react-router";
import AccountMenu from "../components/navigations/NavBar";
import { Grid } from "@mui/material";
import { UserProvider } from "../context/UserContext/UserContext";

// SideBar Data
const menuItems = [
  {
    text: "Dashboard",
    label: "Dashboard",
    icon: <DashboardIcon sx={{ color: "#fff" }} />,
    to: "dashboard",
  },
  {
    text: "Compose",
    icon: <Send sx={{ color: "#fff" }} />,
    children: [
      {
        text: "Bulk SMS",
        // label: "#Bulk SMS",
        label: "In Progress, Plz Don't Test",
        to: "compose/bulksms",
      },
      {
        text: "Dynamic SMS",
        label: "Dynamic SMS",
        to: "compose/dynamicsms",
      },
      {
        text: "RCS SMS",
        label: "RCS SMS",
        to: "compose/rcs-sms",
      },
      {
        text: "Dynamic RCS",
        label: "Dynamic RCS",
        to: "compose/dynamic-rcs",
      },
      // {
      //   text: "International SMS",
      //   label: "International SMS",
      //   to: "/compose/internationalsms",
      // },
      // { text: "Split SMS", label: "Split SMS", to: "/compose/splitsms" },
    ],
  },
  // {
  //   text: "SMS Reports",
  //   icon: <BarChart sx={{ color: "#fff" }} />,
  //   children: [
  //     { text: "Report A", label: "Report Details", to: "/smsreports/a" },
  //     { text: "Report B", label: "Report Details", to: "/smsreports/b" },
  //     { text: "Report C", label: "Report Details", to: "/smsreports/c" },
  //     { text: "Report D", label: "Report Details", to: "/smsreports/d" },
  //   ],
  // },
  // {
  //   text: "VAS",
  //   icon: <Layers sx={{ color: "#fff" }} />,
  //   children: [
  //     { text: "VAS A", label: "Vas Details", to: "/vas/a" },
  //     {
  //       text: "VAS B",
  //       label: "Vas Details",
  //       to: "/vas/b",
  //     },
  //     {
  //       text: "VAS C",
  //       label: "Vas Details",
  //       to: "/vas/c",
  //     },
  //     {
  //       text: "VAS D",
  //       label: "Vas Details",
  //       to: "/vas/d",
  //     },
  //   ],
  // },
  // {
  //   text: "HTTP DLT",
  //   label: "HTTP Details",
  //   icon: <Language sx={{ color: "#fff" }} />,
  //   to: "/httpdlt",
  // },
  {
    text: "Manage DLT",
    icon: <Settings sx={{ color: "#fff" }} />,
    children: [
      {
        text: "Manage Sender ID",
        label: "Sender Details",
        to: "managedlt/manage-senderdetails",
      },
      {
        text: "Upload Templates",
        label: "Template Details",
        to: "managedlt/manage-templates",
      },
      {
        text: "Upload Multimedia",
        label: "Multimedia Details",
        to: "managedlt/manage-multimedia",
      },
    ],
  },
  {
    text: "Manage RCS",
    icon: <Settings sx={{ color: "#fff" }} />,
    children: [
      // {
      //   text: "Access Token",
      //   label: "Access Token",
      //   to: "/managercs/manage-accesstoken",
      // },
      {
        text: "RCS Template",
        label: "RCS Template",
        to: "managedlt/manage-rcstemplate",
      },
    ],
  },
  {
    text: "Utility",
    icon: <Settings sx={{ color: "#fff" }} />,
    children: [
      {
        text: "Add Remove Credits",
        label: "Add / Remove Credits",
        to: "managedlt/manage-addremovecredits",
      },
      {
        text: "Recharge History",
        label: "Recharge History",
        to: "managedlt/manage-rechargehistory",
      },
      {
        text: "Number Block",
        label: "Number Block",
        to: "managedlt/numberblock",
      },
    ],
  },
  {
    text: "User Details",
    icon: <Settings sx={{ color: "#fff" }} />,
    children: [
      {
        text: "Manage User",
        label: "Manage User Details",
        to: "userdetails/manage-user",
      },
      {
        text: "Branding",
        label: "Branding Details",
        to: "userdetails/manage-branding",
      },
      {
        text: "Account Manager",
        label: "Account Manager Details",
        to: "userdetails/manage-accountmanager",
      },
    ],
  },
  {
    text: "Manage Gateway",
    icon: <Settings sx={{ color: "#fff" }} />,
    children: [
      {
        text: "SMS Gateway",
        label: "SMS Gateway Details",
        to: "managegateway/smsgateway",
      },
      {
        text: "Voice Gateway",
        label: "Voice Gateway Details",
        to: "managegateway/voicegateway",
      },
      {
        text: "RCS Gateway/Plan",
        label: "RCS Gateway/Plan Details",
        to: "managegateway/rcsgateway",
      },
      {
        text: "Error Code",
        label: "SMPP Error Code Details",
        to: "managegateway/errorgateway",
      },
    ],
  },
  {
    text: "Manage Routing",
    icon: <Settings sx={{ color: "#fff" }} />,
    children: [
      {
        text: "Create Plan",
        label: "Plan Details",
        to: "managerouting/plan",
      },
      {
        text: "Manage Route",
        label: "Manage Route Details",
        to: "managerouting/route",
      },
      {
        text: "Routing Plan",
        label: "Routing Plan Details",
        to: "managerouting/routingplan",
      },
      {
        text: "Sender Routing",
        label: "Sender Routing Details",
        to: "managerouting/senderrouting",
      },
    ],
  },
  {
    text: "AddressBook",
    label: "Group Details",
    icon: <DashboardIcon sx={{ color: "#fff" }} />,
    to: "addressbook",
  },
  {
    text: "UpdateDLR",
    label: "DLR Details",
    icon: <DashboardIcon sx={{ color: "#fff" }} />,
    to: "updatedlr",
  },
];

const drawerWidth = 260;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
}));

// const AppBar = styled(MuiAppBar, {
//   shouldForwardProp: (prop) => prop !== "open",
// })(({ theme }) => ({
//   zIndex: theme.zIndex.drawer + 1,
//   transition: theme.transitions.create(["width", "margin"], {
//     easing: theme.transitions.easing.sharp,
//     duration: theme.transitions.duration.leavingScreen,
//   }),
//   variants: [
//     {
//       props: ({ open }) => open,
//       style: {
//         marginLeft: drawerWidth,
//         width: `calc(100% - ${drawerWidth}px)`,
//         transition: theme.transitions.create(["width", "margin"], {
//           easing: theme.transitions.easing.sharp,
//           duration: theme.transitions.duration.enteringScreen,
//         }),
//       },
//     },
//   ],
// }));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  backgroundColor: "white", // <-- change background to white
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  variants: [
    {
      props: ({ open }) => open,
      style: {
        ...openedMixin(theme),
        "& .MuiDrawer-paper": {
          ...openedMixin(theme),
          // backgroundColor: "#1976d2",
          backgroundColor: "#2c7be5",
        },
      },
    },
    {
      props: ({ open }) => !open,
      style: {
        ...closedMixin(theme),
        "& .MuiDrawer-paper": {
          ...closedMixin(theme),
          // backgroundColor: "#1976d2",
          backgroundColor: "#2c7be5",
        },
      },
    },
  ],
}));

const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
  ({ theme }) => ({
    flexGrow: 1,
    padding: theme.spacing(1),
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    marginLeft: `calc(${theme.spacing(1)} + 1px)`,
    [theme.breakpoints.up("sm")]: {
      marginLeft: `calc(${theme.spacing(1)} + 1px)`,
    },
    variants: [
      {
        props: ({ open }) => open,
        style: {
          transition: theme.transitions.create("margin", {
            easing: theme.transitions.easing.easeOut,
            duration: theme.transitions.duration.enteringScreen,
          }),
          marginLeft: drawerWidth,
          // Scroll logic
          width: "100%",
          overflowX: "auto", // Enable horizontal scroll
          overflowY: "auto", // Optional: add vertical scroll if needed
          maxWidth: "100vw", // prevent overflow beyond screen
        },
      },
    ],
  })
);

export default function ProtectedLayout() {
  const theme = useTheme();
  const navigate = useNavigate();
  const location = useLocation();

  // console.log("location", location);
  const path = location.pathname.split("/").filter(Boolean).pop();
  // console.log(path); // "e.g., manage-senderdetails"

  const [open, setOpen] = React.useState(true);
  const [expandedItems, setExpandedItems] = React.useState({});

  const getLabelFromMenu = (menuItems, to) => {
    for (const item of menuItems) {
      if (item.to) {
        // Match direct path
        const lastSegment = item.to.split("/").filter(Boolean).pop();
        if (lastSegment === to) {
          return item.label;
        }
      }
      if (item.children) {
        // Match from children
        for (const child of item.children) {
          const childSegment = child.to.split("/").filter(Boolean).pop();
          if (childSegment === to) {
            return child.label;
          }
        }
      }
    }
    return ""; // default if no match
  };

  const label = getLabelFromMenu(menuItems, path);

  // const handleDrawerOpen = () => {
  //   setOpen(true);
  // };

  // const handleDrawerClose = () => {
  //   setOpen(false);
  //   // Close all expanded items when drawer closes
  //   setExpandedItems({});
  // };

  const handleMenuItemClick = (item) => {
    if (item.children) {
      if (!open) {
        // If drawer is closed and item has children, open drawer first
        setOpen(true);
        setExpandedItems((prev) => ({
          ...prev,
          [item.text]: true,
        }));
      } else {
        // Toggle expansion for items with children
        setExpandedItems((prev) => ({
          ...prev,
          [item.text]: !prev[item.text],
        }));
      }
    } else if (item.to) {
      // Navigate to the path for items without children
      // navigate(item.to);
      navigate(`/${item.to}`);
    }
  };

  const handleSubItemClick = (to) => {
    // navigate(to);
    navigate(`/${to}`);
  };

  const isActive = (to) => {
    // return location.pathname === to;
    return location.pathname === `/${to}`;
  };

  // when refresh the page selected option will be highlighted
  React.useEffect(() => {
    // Find the parent item of the current route
    const expanded = {};

    menuItems.forEach((item) => {
      if (
        item.children &&
        // item.children.some((child) => child.to === location.pathname)
        item.children.some((child) => `/${child.to}` === location.pathname)
      ) {
        expanded[item.text] = true;
      }
    });

    setExpandedItems(expanded);
  }, [location.pathname]);

  const renderMenuItem = (item, index) => {
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems[item.text] || false;

    return (
      <React.Fragment key={item.text}>
        <ListItem disablePadding sx={{ display: "block" }}>
          <Tooltip title={!open ? item.text : ""} placement="right">
            <ListItemButton
              onClick={() => handleMenuItemClick(item)}
              sx={[
                {
                  minHeight: 48,
                  px: 2.5,
                  backgroundColor: isActive(item.to)
                    ? "rgba(255, 255, 255, 0.1)"
                    : "transparent",
                  "&:hover": {
                    backgroundColor: "rgba(255, 255, 255, 0.05)",
                  },
                },
                open
                  ? {
                      justifyContent: "initial",
                    }
                  : {
                      justifyContent: "center",
                    },
              ]}
            >
              <ListItemIcon
                sx={[
                  {
                    minWidth: 0,
                    justifyContent: "center",
                  },
                  open
                    ? {
                        mr: 3,
                      }
                    : {
                        mr: "auto",
                      },
                ]}
              >
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.text}
                sx={[
                  {
                    color: "#fff",
                  },
                  open
                    ? {
                        opacity: 1,
                      }
                    : {
                        opacity: 0,
                      },
                ]}
              />
              {hasChildren && open && (
                <Box sx={{ color: "#fff" }}>
                  {isExpanded ? <ExpandLess /> : <ExpandMore />}
                </Box>
              )}
            </ListItemButton>
          </Tooltip>
        </ListItem>

        {hasChildren && open && (
          <Collapse in={isExpanded} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              {item.children.map((child) => (
                <ListItem
                  key={child.text}
                  disablePadding
                  sx={{ display: "block" }}
                >
                  <ListItemButton
                    onClick={() => handleSubItemClick(child.to)}
                    sx={{
                      minHeight: 40,
                      pl: 4,
                      pr: 2.5,
                      backgroundColor: isActive(child.to)
                        ? "rgba(255, 255, 255, 0.1)"
                        : "transparent",
                      "&:hover": {
                        backgroundColor: "rgba(255, 255, 255, 0.05)",
                      },
                    }}
                  >
                    <ListItemText
                      primary={child.text}
                      sx={{
                        color: "#fff",
                        "& .MuiListItemText-primary": {
                          fontSize: "0.875rem",
                        },
                      }}
                    />
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          </Collapse>
        )}
      </React.Fragment>
    );
  };

  return (
    <Box id="1" sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar position="fixed" open={open} id="2">
        <Toolbar
          id="3"
          sx={{
            bgcolor: "white",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <IconButton
            color="inherit"
            aria-label="open drawer"
            onClick={() => setOpen(!open)}
            edge="start"
            sx={[
              {
                marginRight: 5,
              },
              // open && { display: "none" },
            ]}
          >
            <MenuIcon />
          </IconButton>
          {/* <Typography variant="h6" noWrap component="div"> */}
          {/* <Typography variant="h6" noWrap>
            MDS
          </Typography> */}
          <UserProvider>
            <AccountMenu />
          </UserProvider>
        </Toolbar>
      </AppBar>
      <Drawer id="4" variant="permanent" open={open}>
        {/* <DrawerHeader sx={{ backgroundColor: "#1565c0" }}>
          <IconButton onClick={handleDrawerClose} sx={{ color: "#fff" }}>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon />
            ) : (
              <ChevronLeftIcon />
            )}
          </IconButton>
        </DrawerHeader> */}
        <DrawerHeader
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center", // Optional, for vertical centering
            height: "64px", // Set height if not already defined
          }}
        >
          <img
            src={mdslogo}
            alt="logo"
            style={{
              maxWidth: "100%",
              height: "40px",
              objectFit: "contain",
            }}
          />
        </DrawerHeader>

        <Divider sx={{ backgroundColor: "rgba(255, 255, 255, 0.2)" }} />
        <List>
          {menuItems.map((item, index) => renderMenuItem(item, index))}
        </List>
      </Drawer>

      <Box
        sx={{
          flexGrow: 1,
          p: 1,
          // backgroundColor: "#F2F2F2", // grey
          // width: "100vw",
          // minHeight: "100vh", // ensures full height
        }}
      >
        {/* <Typography variant="h6" fontWeight="bold" mb={2}>
          {label}
        </Typography> */}

        <Box
          sx={{
            width: "80vw",
            height: "70vh",
            mt: 3, // replaces marginTop: "20px"
            ml: 1, // replaces ml: "20px"
            p: 1,
            borderRadius: 2,
            bgcolor: "#fff",
            boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.05)",
          }}
        >
          <Grid container spacing={2} alignItems="center">
            <Main open={open} id="5">
              <Box id="6" component="main" sx={{ flexGrow: 1, p: 1 }}>
                <Outlet />
              </Box>
            </Main>
          </Grid>
        </Box>
      </Box>

      {/* <Main open={open} id="5">
        <Box id="6" component="main" sx={{ flexGrow: 1, p: 3 }}>
          <Outlet />
        </Box>
      </Main> */}
    </Box>
  );
}
