// src/routes/menuRoutes.js
import { lazy } from "react";

const Dashboard = lazy(() => import("../pages/Dashboard/Dashboard"));
const BulkSms = lazy(() => import("../pages/Compose/BulkSms/BulkSms"));
const DynamicSms = lazy(() => import("../pages/Compose/DynamicSms/DynamicSms"));
const RcsSms = lazy(() => import("../pages/Compose/RcsSms/RcsSms"));
const SenderDetails = lazy(() =>
  import("../pages/SenderDetails/SenderDetails")
);
const TemplateDetails = lazy(() =>
  import("../pages/templateDetails/TemplateDetails")
);
const TemplateMultimediaDetails = lazy(() =>
  import("../pages/TemplateMultimediaDetails/TemplateMultimediaDetails")
);
const AddressBook = lazy(() => import("../pages/AddressBook/AddressBook"));

const UpdateDLR = lazy(() => import("../pages/UpdateDLR/UpdateDLR"));

const NumberBlock = lazy(() =>
  import("../pages/Utility/NumberBlock/NumberBlock")
);

const ManageSMSGatewayDetails = lazy(() =>
  import(
    "../pages/ManageGateway/ManageSMSGatewayDetails/ManageSMSGatewayDetails"
  )
);
const ManageVoiceGatewayDetails = lazy(() =>
  import(
    "../pages/ManageGateway/ManageVoiceGatewayDetails/ManageVoiceGatewayDetails"
  )
);
const ManageRcsGatewayDetails = lazy(() =>
  import(
    "../pages/ManageGateway/ManageRcsGatewayDetails/ManageRcsGatewayDetails"
  )
);
const ManageErrorGatewayDetails = lazy(() =>
  import(
    "../pages/ManageGateway/ManageErrorGatewayDetails/ManageErrorGatewayDetails"
  )
);

const ManagePlanDetails = lazy(() =>
  import("../pages/ManageRouting/ManagePlanDetails/ManagePlanDetails")
);
const ManageRouteDetails = lazy(() =>
  import("../pages/ManageRouting/ManageRouteDetails/ManageRouteDetails")
);
const ManageRoutingPlanDetails = lazy(() =>
  import(
    "../pages/ManageRouting/ManageRoutingPlanDetails/ManageRoutingPlanDetails"
  )
);
const ManageSenderRouting = lazy(() =>
  import("../pages/ManageRouting/ManageSenderRouting/ManageSenderRouting")
);
const UserManageDetails = lazy(() =>
  import("../pages/UserDetails/UserManageDetails/UserManageDetails")
);
const ManageBrandingDetails = lazy(() =>
  import("../pages/UserDetails/ManageBrandingDetails/ManageBrandingDetails")
);
const ManageAccountManagerDetails = lazy(() =>
  import(
    "../pages/UserDetails/ManageAccountManagerDetails/ManageAccountManagerDetails"
  )
);
const ProfileDetails = lazy(() =>
  import("../pages/ProfileDetails/ProfileDetails")
);

const SettingDetails = lazy(() =>
  import("../pages/SettingDetails/SettingDetails")
);
const RcsTemplateDetails = lazy(() =>
  import("../pages/ManageRcs/RcsTemplateDetails/RcsTemplateDetails")
);
const CreditsDetails = lazy(() =>
  import("../pages/Utility/AddRemoveCredits/CreditsDetails/CreditsDetails")
);
const RechargeHistoryDetails = lazy(() =>
  import(
    "../pages/Utility/Recharge History/RechargeHistoryDetails/RechargeHistoryDetails"
  )
);

const DynamicRcsDetails = lazy(() =>
  import("../pages/Compose/DynamicRcsDetails/DynamicRcsDetails")
);

export const menuRoutes = [
  // Profile and Accounts
  { path: "/profile", component: ProfileDetails },

  // Setting
  { path: "/setting", component: SettingDetails },

  // Dashboard
  { path: "/dashboard", component: Dashboard },

  // compose
  { path: "/compose/bulksms", component: BulkSms },
  { path: "/compose/dynamicsms", component: DynamicSms },
  { path: "compose/rcs-sms", component: RcsSms },
  { path: "compose/dynamic-rcs", component: DynamicRcsDetails },

  // Manage DLT
  { path: "/managedlt/manage-senderdetails", component: SenderDetails },
  { path: "/managedlt/manage-templates", component: TemplateDetails },
  {
    path: "/managedlt/manage-multimedia",
    component: TemplateMultimediaDetails,
  },

  // Manage RCS
  // { path: "/managercs/manage-accesstoken", component: AccessTokenDetails },
  { path: "/managedlt/manage-rcstemplate", component: RcsTemplateDetails },

  // Manage Gateway
  { path: "/managegateway/smsgateway", component: ManageSMSGatewayDetails },
  { path: "/managegateway/voicegateway", component: ManageVoiceGatewayDetails },
  { path: "/managegateway/rcsgateway", component: ManageRcsGatewayDetails },
  { path: "/managegateway/errorgateway", component: ManageErrorGatewayDetails },

  // Manage Routing
  { path: "/managerouting/plan", component: ManagePlanDetails },
  { path: "/managerouting/route", component: ManageRouteDetails },
  { path: "/managerouting/routingplan", component: ManageRoutingPlanDetails },
  { path: "/managerouting/senderrouting", component: ManageSenderRouting },

  // Address Book
  { path: "/addressbook", component: AddressBook },

  // Update DLR
  { path: "/updatedlr", component: UpdateDLR },

  // User Details
  { path: "/userdetails/manage-user", component: UserManageDetails },
  { path: "/userdetails/manage-branding", component: ManageBrandingDetails },
  {
    path: "/userdetails/manage-accountmanager",
    component: ManageAccountManagerDetails,
  },

  // Utility
  { path: "managedlt/manage-addremovecredits", component: CreditsDetails },
  {
    path: "managedlt/manage-rechargehistory",
    component: RechargeHistoryDetails,
  },
  { path: "managedlt/numberblock", component: NumberBlock },
];
