import { Navigate, Outlet, useNavigate } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { login } from "../features/auth/authSlice";
import { selectUser } from "../features/auth/authSelectors";
import Loader from "../components/Loader/Loader";
import { postRequest } from "../helpers/http.helper";
import { getTokenFromStorage } from "../utils/common";

const ProtectedRoute = () => {
  const { isLoggedIn, user } = useSelector((state) => state.auth);
  const [loading, setLoading] = useState(true); // To handle hydration from localStorage
  const dispatch = useDispatch();
  const token = getTokenFromStorage();
  const navigate = useNavigate();

  const checkUserSignAndRedirect = () => {
    if (!token) {
      setLoading(false);
      return;
    }
    const payload = { token };
    postRequest("get-user-details-by-token", payload, function (res) {
      if (res?.data) {
        dispatch(login(res?.data?.data));
      } else if (res?.data?.error) {
        navigate("/login");
      }
      setLoading(false);
    });
  };

  useEffect(() => {
    if (!token) {
      return;
    }
    checkUserSignAndRedirect();
  }, [isLoggedIn]);

  if (loading)
    return (
      <>
        <Loader />
      </>
    );

  if (!user || !token) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
