import { Autocomplete, Box, FormHelperText, TextField } from "@mui/material";

// Dynamic Autocomplete Component with Icon
const IconAutocompleteField = ({
  icon: IconComponent,
  name,
  id,
  label,
  options,
  multiple = false,
  getOptionLabel,
  value,
  isOptionEqualToValue,
  onChange,
  errors,
  touched,
  handleBlur,
  iconBgColor = "#A780FF",
  iconColor = "white",
  ...autocompleteProps
}) => {
  return (
    <Box>
      <Box
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "flex-start",
        }}
      >
        <Box
          sx={{
            backgroundColor: iconBgColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "8px",
            borderRadius: "4px 0 0 4px",
            border: "1px solid #e0e0e0",
            borderRight: "none",
            height: "40px",
            zIndex: 1,
          }}
        >
          <IconComponent sx={{ color: iconColor, fontSize: "20px" }} />
        </Box>
        <Autocomplete
          id={id}
          name={name}
          options={options}
          getOptionLabel={getOptionLabel}
          fullWidth
          size="small"
          multiple={multiple}
          value={value}
          isOptionEqualToValue={isOptionEqualToValue}
          onChange={onChange}
          sx={{
            "& .MuiOutlinedInput-root": {
              borderRadius: "0 4px 4px 0",
              "& fieldset": {
                borderLeft: "none",
              },
            },
          }}
          renderInput={(params) => (
            <TextField
              {...params}
              label={label}
              onBlur={handleBlur}
              error={!!errors?.[name] && !!touched?.[name]}
              // helperText={
              //   errors?.[name] && touched?.[name] ? errors?.[name] : ""
              // }
            />
          )}
          {...autocompleteProps}
        />
      </Box>
      {errors?.[name] && touched?.[name] && (
        <FormHelperText error>{errors?.[name]}</FormHelperText>
      )}
    </Box>
  );
};

export default IconAutocompleteField;
