import React from "react";
import { Box } from "@mui/material";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { TimePicker } from "@mui/x-date-pickers/TimePicker";
import dayjs from "dayjs";

const IconTimePickerField = ({
  icon: IconComponent,
  name,
  label,
  value,
  errors,
  touched,
  disabled = false,
  timePickersOpen,
  setTimePickersOpen,
  setFieldTouched,
  setFieldValue,
  setFieldError,
  values,
  // setErrorsForTimeFields,
  showErrIfTouched,
  iconBgColor = "#A780FF",
  iconColor = "white",
  ...timePickerProps
}) => {
  // Convert value to dayjs object for TimePicker
  const getTimeValue = () => {
    if (!value) return null;

    // If it's already a dayjs object, return it
    if (dayjs.isDayjs(value)) return value;

    // If it's a string in HH:mm format, convert it
    if (typeof value === "string") {
      // Handle both HH:mm and full datetime formats
      if (value.includes("T")) {
        return dayjs(value);
      } else if (value.match(/^\d{2}:\d{2}$/)) {
        // For HH:mm format, create a dayjs object with today's date
        return dayjs(`2000-01-01 ${value}`);
      }
    }

    return dayjs(value);
  };

  const handleTimeChange = (time) => {
    if (!time || !time.isValid()) {
      setFieldValue(name, "");
      setFieldTouched(name, true);
      return;
    }

    const formattedTime = time.format("HH:mm");
    setFieldValue(name, formattedTime);
    setFieldTouched(name, true);

    // Validate time relationships immediately
    // if (setErrorsForTimeFields) {
    //   setErrorsForTimeFields(setFieldError, {
    //     ...values,
    //     [name]: formattedTime,
    //   });
    // }
  };

  const handleTimePickerOpen = (e) => {
    e.stopPropagation();
    setTimePickersOpen((prev) => ({
      ...prev,
      [name]: true,
    }));
  };

  const handleTimePickerClose = () => {
    setTimePickersOpen((prev) => ({
      ...prev,
      [name]: false,
    }));
    // Set field as touched when picker closes
    setFieldTouched(name, true);

    // Run validation when picker closes
    // if (setErrorsForTimeFields && value) {
    //   setErrorsForTimeFields(setFieldError, values);
    // }
  };

  // Add blur handler to ensure field is marked as touched and validation runs
  const handleBlur = () => {
    setFieldTouched(name, true);

    // Run validation on blur to ensure errors persist
    // if (setErrorsForTimeFields) {
    //   setErrorsForTimeFields(setFieldError, values);
    // }
  };

  const hasError = touched[name] && errors[name];

  return (
    <Box>
      <Box sx={{ position: "relative", display: "flex", alignItems: "center" }}>
        {/* Icon Box */}
        <Box
          sx={{
            backgroundColor: iconBgColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "8px",
            marginTop: "5px",
            borderRadius: "4px 0 0 4px",
            border: "1px solid #e0e0e0",
            borderRight: "none",
            minHeight: "40px",
            zIndex: 1,
            position: "sticky",
          }}
        >
          <IconComponent
            sx={{ color: iconColor, fontSize: "20px", position: "sticky" }}
          />
        </Box>

        {/* TimePicker Container */}
        <Box sx={{ flex: 1 }}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DemoContainer components={["TimePicker"]}>
              <TimePicker
                label={label}
                value={getTimeValue()}
                open={timePickersOpen}
                onOpen={handleTimePickerOpen}
                onClose={handleTimePickerClose}
                onChange={handleTimeChange}
                ampm={false}
                disabled={disabled}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    size: "small",
                    name: name,
                    error: !!hasError,
                    helperText: hasError ? errors[name] : "",
                    // onClick: handleTimePickerOpen,
                    onClick: (e) => {
                      if (!disabled) {
                        handleTimePickerOpen(e);
                      }
                    },
                    onBlur: handleBlur, // Enhanced blur handler with validation
                    sx: {
                      "& .MuiOutlinedInput-root": {
                        borderRadius: "0 4px 4px 0",
                        "& fieldset": {
                          borderLeft: "none",
                        },
                      },
                    },
                  },
                  popper: {
                    sx: {
                      "& .MuiMultiSectionDigitalClockSection-root": {
                        width: "5rem",
                        padding: "1px",
                      },
                      "& .MuiDialogActions-root": {
                        margin: "auto",
                      },
                    },
                  },
                }}
                sx={{
                  "& .MuiInputLabel-root": {
                    fontSize: "1rem!important",
                    "&.Mui-focused": {
                      color: "#637381",
                      fontSize: "20px!important",
                      fontWeight: "600",
                    },
                  },
                  width: "100%",
                }}
                {...timePickerProps}
              />
            </DemoContainer>
          </LocalizationProvider>
        </Box>
      </Box>
    </Box>
  );
};

export default IconTimePickerField;
