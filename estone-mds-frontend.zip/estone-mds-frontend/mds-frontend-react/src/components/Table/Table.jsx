import React from "react";
import {
  MaterialReactTable,
  MRT_ActionMenuItem,
  useMaterialReactTable,
} from "material-react-table";
import {
  Box,
  Button,
  FormControl,
  MenuItem,
  OutlinedInput,
  Select,
} from "@mui/material";
// import { useLocation } from "react-router";
// import { getUrlParamFromPathnameByIndex } from "../../helpers/commonHelpers";
// import { useSelector } from "react-redux";

function Table({
  data,
  columns,
  isLoading,
  isError,
  rowSelection,
  setRowSelection,
  globalFilter,
  setGlobalFilter,
  sorting,
  setSorting,
  pagination,
  setPagination,
  rowCount,
  toolbarButtons,
  rowActionItems = [],
  states,
  children,
}) {
  // Create the column order array with selection and action columns
  const fullColumnOrder = [
    "mrt-row-select", // Selection checkbox column
    ...columns?.map((col) => col?.accessorKey), // Your defined columns
    "mrt-row-actions", // Actions column
  ];

  // MaterialReactTable configuration
  const table = useMaterialReactTable({
    columns: columns,
    data: data,
    enableStickyHeader: true,
    enableColumnActions: false,
    positionActionsColumn: "last",
    // enableRowSelection: true,
    enableGlobalFilter: true,
    showGlobalFilter: true,
    enableHiding: false,
    enableDensityToggle: false,
    enableFullScreenToggle: false,
    enableColumnFilters: false,
    getRowId: (row) => row.Id,
    initialState: {
      showColumnFilters: false,
      density: "compact",
      showGlobalFilter: true,
      columnOrder: fullColumnOrder,
    },
    displayColumnDefOptions: {
      "mrt-row-select": {
        size: 50,
        enableHiding: false,
        enableColumnActions: false,
        enableColumnFilters: false,
        enableColumnOrdering: false,
        enableResizing: false,
        enableSorting: false,
      },
      "mrt-row-actions": {
        enableHiding: false,
        enableColumnActions: false,
        enableColumnFilters: false,
        enableColumnOrdering: false,
        enableResizing: false,
        enableSorting: false,
      },
    },
    onRowSelectionChange: setRowSelection,
    manualFiltering: false,
    manualPagination: true,
    manualSorting: false,
    enableRowActions: true,
    enableSortingRemoval: true,
    muiToolbarAlertBannerProps: isError
      ? {
          color: "error",
          children: "Error loading data",
        }
      : undefined,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    // enableGlobalFilterModes: true,
    // initialState: {
    //   showGlobalFilter: true,
    // },
    positionGlobalFilter: "right",
    // muiSearchTextFieldProps: {
    //   // placeholder: `Search ${data.length} rows`,
    //   sx: { minWidth: "300px" },
    //   variant: "outlined",
    // },
    // muiSearchTextFieldProps: {
    //   variant: "outlined",
    //   size: "small", // Reduces height slightly
    //   sx: () => ({
    //     minWidth: "180px", // Width adjustment
    //     "& .MuiInputBase-root": {
    //       height: 32, // Reduce the input height
    //       fontSize: "0.8rem", // Smaller font
    //     },
    //     "& .MuiInputBase-input": {
    //       padding: "4px 8px", // Reduce inner input padding
    //     },
    //   }),
    // },
    muiPaginationProps: {
      color: "primary",
      shape: "rounded",
      showRowsPerPage: false,
      variant: "outlined",
    },
    // paginationDisplayMode: 'pages',

    muiTableContainerProps: {
      sx: () => ({
        maxHeight: "calc(100vh - 300px)",
      }),
    },
    // muiTableHeadCellProps: {
    //   sx: () => ({
    //     backgroundColor: "#f3f6f9",
    //     fontWeight: "600",
    //     fontSize: "1rem",
    //     borderRight: "1px solid rgba(224, 224, 224, 1)",
    //     borderBottomWidth: "1px",
    //     paddingTop: "0.7rem",
    //     paddingBottom: "0.7rem",
    //     textWrap: "nowrap",
    //   }),
    // },
    // muiTableBodyCellProps: {
    //   sx: () => ({
    //     borderRight: "1px solid rgba(224, 224, 224, 1)",
    //   }),
    // },

    // renderTopToolbarCustomActions
    // renderTopToolbarCustomActions: () => {
    //   return (
    //     <Box sx={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
    //       {/* {filteredButtons.map((button, index) => ( */}
    //       {toolbarButtons.map((button, index) => (
    //         <Button
    //           key={index}
    //           variant={button.variant}
    //           sx={button.sx}
    //           color={button.color}
    //           onClick={button.onClick}
    //           startIcon={button.startIcon}
    //         >
    //           {button.label}
    //         </Button>
    //       ))}
    //       {children}
    //     </Box>
    //   );
    // },

    // custome row per page at the top table

    muiTableHeadCellProps: {
      sx: {
        backgroundColor: "#f3f6f9",
        fontWeight: "600",
        fontSize: "0.919rem",
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        borderBottomWidth: "1px",
        paddingTop: "0.3rem", // adjust for compact height
        paddingBottom: "0.3rem",
        height: "36px", // consistent height
        whiteSpace: "nowrap",
      },
    },
    muiTableBodyCellProps: {
      sx: {
        borderRight: "1px solid rgba(224, 224, 224, 1)",
        paddingTop: "0rem",
        paddingBottom: "0rem",
        height: "36px", // same height as header
        fontSize: "0.875rem",
      },
    },

    // renderTopToolbarCustomActions: ({ table }) => (
    //   <Box sx={{ display: "flex", alignItems: "center", paddingLeft: 1 }}>
    //     <label style={{ marginRight: 8, fontSize: "0.875rem" }}>Show</label>
    //     <select
    //       value={table.getState().pagination.pageSize}
    //       onChange={(e) => {
    //         table.setPageSize(Number(e.target.value));
    //       }}
    //       style={{
    //         fontSize: "0.875rem",
    //         padding: "4px 4.5px",
    //         borderRadius: 4,
    //         // border: "1px solid #ccc",
    //       }}
    //     >
    //       {[5, 10, 25, 50, 100].map((pageSize) => (
    //         <option key={pageSize} value={pageSize}>
    //           {pageSize}
    //         </option>
    //       ))}
    //     </select>
    //     <label style={{ paddingLeft: 8, fontSize: "0.875rem" }}>entries</label>
    //   </Box>
    // ),

    // Option 2
    renderTopToolbarCustomActions: ({ table }) => (
      <Box sx={{ display: "flex", alignItems: "center", paddingLeft: 1 }}>
        <label style={{ marginRight: 8, fontSize: "0.875rem" }}>Show</label>

        <FormControl
          variant="standard"
          sx={{
            minWidth: 60,
            "& select": {
              padding: "4px 8px",
              fontSize: "0.875rem",
              border: "1px solid #ccc",
              borderRadius: "4px",
              appearance: "none",
              WebkitAppearance: "none",
              MozAppearance: "none",
              backgroundColor: "#fff",
              lineHeight: 1.4,
              // Add focus styles here to maintain border-radius
              "&:focus": {
                borderRadius: "4px", // Ensure border-radius is applied on focus
                outline: "none", // Optional: Remove default outline if not desired
                // borderColor: "#007bff", // Optional: Example of changing border color on focus
              },
            },
            "& .MuiInputBase-root:before, & .MuiInputBase-root:after": {
              display: "none",
            },
          }}
        >
          <Select
            native
            disableUnderline
            value={table.getState().pagination.pageSize}
            onChange={(e) => table.setPageSize(Number(e.target.value))}
            inputProps={{
              "aria-label": "Page size",
            }}
          >
            {[5, 10, 25, 50, 100].map((pageSize) => (
              <option key={pageSize} value={pageSize}>
                {pageSize}
              </option>
            ))}
          </Select>
        </FormControl>

        <label style={{ paddingLeft: 8, fontSize: "0.875rem" }}>entries</label>
      </Box>
    ),

    // renderRowActionMenuItems

    // renderRowActionMenuItems: ({ closeMenu, row, table }) => {
    //   return rowActionItems.map((item, index) => (
    //     <MRT_ActionMenuItem
    //       key={index}
    //       icon={item.icon}
    //       label={item.label}
    //       onClick={() => {
    //         closeMenu();
    //         item.onClick(row.original, row.index);
    //       }}
    //       table={table}
    //     />
    //   ));

    // renderIconRowActions

    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: "8px", alignItems: "center" }}>
        {rowActionItems.map((item, index) => (
          <Button
            key={index}
            // variant="outlined"
            sx={{
              minWidth: "36px",
              height: "36px",
              padding: 0,
              marginTop: "4px",
              marginBottom: "4px",
              // borderColor: "#A780FF", // Your desired color
              // borderColor: "#3084d7", // Your desired color
              color: "#3084d7",
              // borderRadius: "6px",
              "&:hover": {
                // borderColor: "#3084d7",
                backgroundColor: "transparent",
              },
              "&:focus": {
                outline: "none",
                // borderColor: "#3084d7",
              },
              "&:active": {
                // borderColor: "#3084d7",
              },
            }}
            onClick={() => item.onClick(row.original)}
          >
            {item.icon}
          </Button>
        ))}
      </Box>
    ),
    rowCount,
    // ...finalState,
    ...states,
    state: {
      globalFilter,
      isLoading,
      pagination,
      showAlertBanner: isError,
      sorting,
      rowSelection,
      columnOrder: fullColumnOrder,
    },
  });

  return (
    <>
      <MaterialReactTable table={table} />
    </>
  );
}

export default Table;
