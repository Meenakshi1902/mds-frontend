import { Box } from "@mui/material";
import { DateTimePicker } from "@mui/x-date-pickers";

const CustomDatePicker = ({
  icon: IconComponent,
  id,
  name,
  label,
  value,
  format,
  adapter,
  disabled = false,
  sx,
  disablePast = false,
  disableFuture = false,
  open,
  onClose,
  onChange,
  iconBgColor = "#A780FF",
  iconColor = "white",
  slotProps = {},
}) => {
  return (
    <Box>
      <Box
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Box
          sx={{
            backgroundColor: iconBgColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "8px",
            borderRadius: "4px 0 0 4px",
            border: "1px solid #e0e0e0",
            borderRight: "none",
            height: "40px",
          }}
        >
          <IconComponent sx={{ color: iconColor, fontSize: "20px" }} />
        </Box>
        <DateTimePicker
          id={id}
          name={name} // Pass the name to DateTimePicker itself
          label={label}
          value={value}
          format={format}
          adapter={adapter}
          disabled={disabled}
          ampm={false}
          sx={sx}
          disablePast={disablePast}
          disableFuture={disableFuture}
          open={open}
          onClose={onClose}
          onChange={(newValue) => {
            if (!newValue) return onChange("");

            const hasTime = newValue.hour() !== 0 || newValue.minute() !== 0;
            const updatedValue = hasTime
              ? newValue
              : newValue.hour(12).minute(0);

            onChange(updatedValue.format("YYYY-MM-DDTHH:mm:ss"));
          }}
          slotProps={{
            openPickerButton: {
              tabIndex: -1,
              disabled: true,
            },
            actionBar: {
              actions: ["clear", "cancel", "accept"],
            },
            textField: {
              ...slotProps.textField, // Spread existing slotProps.textField
              name: name, // Explicitly pass name to the textField
              id: id, // Explicitly pass id to the textField
              onClick: disabled ? null : slotProps?.textField?.onClick,
              onKeyDown: (e) => {
                if (slotProps?.textField?.onKeyDown) {
                  slotProps.textField.onKeyDown(e);
                }
                if (e.code === "Backspace") {
                  e.preventDefault();
                  onChange("");
                }
              },
              size: "small",
              // `readOnly` should be controlled. It's generally true for pickers
              // unless you want manual input. If keeping it true, ensure Formik's
              // onBlur is still firing (which it should via slotProps).
              readOnly: true, // Keep this as true to prevent direct typing
              clearable: true,
            },
          }}
        />
      </Box>
    </Box>
  );
};

export default CustomDatePicker;
