import React from "react";
import { Box, IconButton, Modal } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

function ModalComponent({ style, enableAddForm, closeModal, children }) {
  return (
    <>
      <Modal
        sx={{ overflowY: "scroll" }}
        open={enableAddForm}
        onClose={closeModal}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          {/* Close Icon Button */}
          <IconButton
            onClick={closeModal}
            sx={{
              position: "absolute",
              top: 4,
              right: 8,
              color: (theme) => theme.palette.grey[500],
            }}
          >
            <CloseIcon />
          </IconButton>

          {/* Modal Content */}
          {children}
        </Box>
      </Modal>
    </>
  );
}

export default ModalComponent;
