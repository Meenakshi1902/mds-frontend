// components/DynamicTable.jsx

import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Box,
  Typography,
} from "@mui/material";

function DynamicTable({ data, columns = [], title, height = 300 }) {
  const isArrayOfObjects =
    Array.isArray(data) &&
    typeof data[0] === "object" &&
    !Array.isArray(data[0]);

  // If array of objects, derive columns dynamically
  const derivedColumns =
    isArrayOfObjects && data.length > 0 ? Object.keys(data[0]) : columns;

  return (
    <Box sx={{ mt: 2, maxHeight: height, overflow: "auto" }}>
      <Typography variant="h6" gutterBottom>
        {title}
      </Typography>

      <TableContainer component={Paper} sx={{ maxHeight: height }}>
        <Table stickyHeader size="small">
          <TableHead>
            <TableRow>
              {derivedColumns.map((col, index) => (
                <TableCell
                  key={index}
                  sx={{
                    backgroundColor: "#f5f5f5",
                    fontWeight: "bold",
                  }}
                >
                  {col.replace(/_/g, " ").toUpperCase()}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {data.map((row, i) => (
              <TableRow key={i}>
                {isArrayOfObjects
                  ? derivedColumns.map((col) => (
                      <TableCell key={col}>
                        {typeof row[col] === "string" ||
                        typeof row[col] === "number"
                          ? row[col]
                          : JSON.stringify(row[col])}
                      </TableCell>
                    ))
                  : row.map((cell, j) => (
                      <TableCell key={j}>{cell || "-"}</TableCell>
                    ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}

export default DynamicTable;
