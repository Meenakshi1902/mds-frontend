import React from "react";
import { Box, TextField, FormHelperText } from "@mui/material";
import { Field } from "formik";

// Dynamic TextField Component with Icon
const IconInputField = ({
  icon: IconComponent,
  name,
  id,
  label,
  errors,
  touched,
  handleBlur,
  placeholder = "",
  disabled = false,
  iconBgColor = "#A780FF",
  iconColor = "white",
  ...textFieldProps
}) => {
  return (
    <Box>
      <Box
        sx={{
          position: "relative",
          display: "flex",
          alignItems: "center",
        }}
      >
        <Box
          sx={{
            backgroundColor: iconBgColor,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "8px",
            borderRadius: "4px 0 0 4px",
            border: "1px solid #e0e0e0",
            borderRight: "none",
            height: "40px",
          }}
        >
          <IconComponent sx={{ color: iconColor, fontSize: "20px" }} />
        </Box>

        <Field name={name}>
          {({ field, form, meta }) => {
            // console.log(`Field render - ${name} disabled:`, disabled);
            return (
              <TextField
                {...field}
                id={id}
                label={label}
                fullWidth
                size="small"
                placeholder={placeholder}
                disabled={disabled} // This will now work!
                error={errors?.[name] && touched?.[name]}
                onBlur={handleBlur}
                sx={{
                  "& .MuiOutlinedInput-root": {
                    borderRadius: "0 4px 4px 0",
                    "& fieldset": {
                      borderLeft: "none",
                    },
                  },
                }}
                {...textFieldProps}
              />
            );
          }}
        </Field>
      </Box>
      {errors?.[name] && touched?.[name] && (
        <FormHelperText error>{errors?.[name]}</FormHelperText>
      )}
    </Box>
  );
};

export default IconInputField;
